<style>
        body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; display: flex; flex-direction: column; height: 100vh; overflow: hidden; }
        .main-container { display: flex; flex-direction: column; flex: 1; position: relative; }
        header { display: flex; justify-content: space-between; align-items: center; padding: 10px 15px; background: rgba(0, 0, 0, 0.25); }
        #map { position: absolute; top: 0; bottom: 0; width: 100%; }
        #formPanelWrapper { position: absolute; bottom: 0; left: 0; right: 0; background: rgba(25, 25, 25, 0.85); backdrop-filter: blur(10px); border-top: 1px solid rgba(255, 255, 255, 0.2); z-index: 10; transition: max-height 0.4s ease-in-out; overflow: hidden; max-height: 75px; }
        #formPanelWrapper.expanded { max-height: 60vh; overflow-y: auto; }
        #gamesSummary { display: flex; justify-content: space-between; align-items: center; padding: 20px; box-sizing: border-box; }
        #gamesSummary span { font-size: 16px; font-weight: bold; }
        #gamesSummary a { color: #fff; background-color: #0d6efd; padding: 8px 12px; text-decoration: none; border-radius: 6px; font-size: 14px; }
        #formFields { padding: 0 20px 20px 20px; display: flex; flex-direction: column; gap: 15px; }
        label { font-weight: bold; font-size: 14px; margin-bottom: -10px; }
        input { width: 100%; padding: 12px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.3); background: rgba(255, 255, 255, 0.15); color: #fff; font-size: 16px; box-sizing: border-box; }
        #walletInfo { background: rgba(0,0,0,0.2); padding: 10px; border-radius: 8px; display: flex; justify-content: space-between; align-items: center; }
        button { padding: 12px; border: none; border-radius: 8px; font-size: 16px; font-weight: bold; cursor: pointer; background: rgba(255, 255, 255, 0.2); color: white; margin-top: 5px; }
        #createBtn { background: #28a745; }
        #closeFormBtn { background: #dc3545; }
        .mapboxgl-popup-content { background-color: rgba(40, 40, 40, 0.9); color: #fff; padding: 10px 15px; border-radius: 8px; }
        .mapboxgl-popup-anchor-bottom .mapboxgl-popup-tip { border-top-color: rgba(40, 40, 40, 0.9); }
    </style>
<body>
<header><h2>Create a New Game</h2><a href="map.html">Exit</a></header>
<div class="main-container">
<div id="map"></div>
<div id="formPanelWrapper">
<div id="gamesSummary"><span id="gameCount">Games you created (0)</span><a href="creatorsactivities.html">View details</a></div>
<div id="formFields">
<label for="gameTitle">Game Title</label><input id="gameTitle" type="text"/>
<label for="startDateTime">Start Date &amp; Time</label><input id="startDateTime" step="3600" type="datetime-local"/>
<label for="treasures">Number of Hidden Treasures</label><input id="treasures" min="1" type="number"/>
<label for="value">Total Prize Value ($)</label><input id="value" min="1" type="number"/>
<div id="locationDetails"><label>Selected Location</label><p id="locText" style="margin-top: 5px;">No location selected.</p></div>
<div id="walletInfo"><span id="walletBalance">Wallet: $0.00</span><button onclick="addToWallet()">Add Money</button></div>
<button id="createBtn">Create Game</button><button id="closeFormBtn">Cancel</button>
</div>
</div>
</div>
<script>
        let map = null, selectedCoords = null, mapMarker = null, currentUserWallet = 0, activePopup = null;
        let existingMarkers = [];
        function showForm() { document.getElementById('formPanelWrapper').classList.add('expanded'); }
        function hideForm() { document.getElementById('formPanelWrapper').classList.remove('expanded'); if(activePopup) activePopup.remove(); }
        function addToWallet() { window.location.href = 'wallet.html'; }
        function confirmLocationAndShowForm() { if(activePopup) activePopup.remove(); showForm(); }
        function updateGamesSummary(count) { document.getElementById('gameCount').textContent = `Games you created (${count})`; }
        async function getAddressForCoords(coords) {
            try {
                const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${coords[1]}&lon=${coords[0]}&format=json`);
                const data = await res.json();
                return data.display_name || 'Address not found.';
            } catch { return 'Could not fetch address.'; }
        }
        async function fetchWalletBalance(userId) {
            const { data } = await supabaseClient.from('users').select('wallet').eq('id', userId).single();
            if (data) { currentUserWallet = data.wallet; document.getElementById('walletBalance').textContent = `Wallet: $${currentUserWallet.toFixed(2)}`; }
        }
        async function createGame() {
            const { data: { user } } = await supabaseClient.auth.getUser();
            if (!user) return Swal.fire("Not logged in.");
            const title = document.getElementById('gameTitle').value.trim();
            const startTime = document.getElementById('startDateTime').value;
            const treasureCount = parseInt(document.getElementById('treasures').value);
            const totalValue = parseFloat(document.getElementById('value').value);
            if (!title || !startTime || !treasureCount || isNaN(totalValue) || !selectedCoords) { return Swal.fire("Validation Error", "Please complete all fields correctly.", "warning"); }
            if (currentUserWallet < totalValue) { return Swal.fire("Insufficient Funds", "Your wallet balance is less than the total prize value.", "error"); }
            const newGame = { creator_id: user.id, title, start_time: new Date(startTime).toISOString(), treasure_count: treasureCount, total_value: totalValue, location: `POINT(${selectedCoords.lng} ${selectedCoords.lat})`, status: 'pending' };
            const { error } = await supabaseClient.from('games').insert(newGame);
            if (error) { return Swal.fire("Database Error", `Could not save the game: ${error.message}`, "error"); }
            const newBalance = currentUserWallet - totalValue;
            await supabaseClient.from('users').update({ wallet: newBalance }).eq('id', user.id);
            await fetchWalletBalance(user.id);
            Swal.fire("Game Created!", "Your game has been saved successfully.", "success");
            hideForm();
            loadExistingGames(user.id);
        }
        async function loadExistingGames(userId) {
            existingMarkers.forEach(marker => marker.remove());
            existingMarkers = [];
            const { data, error } = await supabaseClient.rpc('get_games_by_creator', { user_id_input: userId });
            if (error || !data) {
                updateGamesSummary(0);
                console.error("Failed to load games:", error);
                return;
            }
            updateGamesSummary(data.length);
            data.forEach(game => {
                if (game.location?.type === 'Point' && game.location.coordinates) {
                    const coords = game.location.coordinates;
                    const marker = new mapboxgl.Marker({ color: 'orange' }).setLngLat(coords).addTo(map);
                    existingMarkers.push(marker);
                    marker.getElement().addEventListener('click', async (e) => {
                        e.stopPropagation();
                        if(activePopup) activePopup.remove();
                        const address = await getAddressForCoords(coords);
                        const formattedDate = new Date(game.start_time).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
                        const popupContent = `<div style="font-size: 14px; max-width: 250px;"><p style="margin: 0; font-weight: bold;">${address}</p><hr style="border-color: rgba(255,255,255,0.2); margin: 8px 0;"><p style="margin: 0;"><strong>Starts:</strong> ${formattedDate}</p><p style="margin: 0;"><strong>Treasures:</strong> ${game.treasure_count}</p><p style="margin: 0;"><strong>Value:</strong> $${game.total_value}</p></div>`;
                        activePopup = new mapboxgl.Popup({ offset: 25, anchor: 'bottom' }).setLngLat(coords).setHTML(popupContent).addTo(map);
                    });
                }
            });
        }
        window.onload = async () => {
            const { data: { session } } = await supabaseClient.auth.getSession();
            if (!session) return;
            const user = session.user;
            await fetchWalletBalance(user.id);
            mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
            map = new mapboxgl.Map({ container: 'map', style: 'mapbox://styles/mapbox/dark-v11', center: [-73.78, 41.03], zoom: 12 });
            map.on('load', () => {
                map.resize();
                loadExistingGames(user.id);
                document.getElementById('createBtn').addEventListener('click', createGame);
                document.getElementById('closeFormBtn').addEventListener('click', hideForm);
            });
            map.on('dragstart', hideForm);
            map.on('click', async (e) => {
                if (e.originalEvent.target.closest('.mapboxgl-marker')) return;
                hideForm();
                if(activePopup) activePopup.remove();
                selectedCoords = e.lngLat;
                if (mapMarker) { mapMarker.setLngLat(selectedCoords); }
                else { mapMarker = new mapboxgl.Marker({ color: '#17a2b8' }).setLngLat(selectedCoords).addTo(map); }
                const address = await getAddressForCoords([selectedCoords.lng, selectedCoords.lat]);
                document.getElementById('locText').textContent = address;
                const popupContent = `<div style="text-align: center;"><p style="font-weight: bold; margin: 0 0 10px 0;">${address}</p><button onclick="confirmLocationAndShowForm()" style="width: 100%; padding: 8px; border: none; background-color: #28a745; color: white; border-radius: 4px; cursor: pointer;">Select This Location</button></div>`;
                activePopup = new mapboxgl.Popup({ closeButton: false, offset: 25, anchor: 'bottom' }).setLngLat(selectedCoords).setHTML(popupContent).addTo(map);
            });
        };
    </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/@turf/turf@6/turf.min.js"></script>
<script src="session.js"></script>
<script type="module">
        import { faker } from 'https://cdn.skypack.dev/@faker-js/faker';
        window.getSuggestedTitle = () => {
            const adj = faker.word.adjective();
            const noun = faker.word.noun();
            return `${adj.charAt(0).toUpperCase() + adj.slice(1)} ${noun.charAt(0).toUpperCase() + noun.slice(1)}`;
        };
    </script>
<script>
        let map = null, selectedCoords = null, mapMarker = null, currentUserWallet = 0, activePopup = null;
        let existingMarkers = [];
        function showForm() { document.getElementById('formPanelWrapper').classList.add('expanded'); }
        function hideForm() { document.getElementById('formPanelWrapper').classList.remove('expanded'); if(activePopup) activePopup.remove(); }
        function addToWallet() { window.location.href = 'wallet.html'; }
        function confirmLocationAndShowForm() { if(activePopup) activePopup.remove(); showForm(); }
        function updateGamesSummary(count) { document.getElementById('gameCount').textContent = `Games you created (${count})`; }
        async function getAddressForCoords(coords) {
            try {
                const res = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${coords[1]}&lon=${coords[0]}&format=json`);
                const data = await res.json();
                return data.display_name || 'Address not found.';
            } catch { return 'Could not fetch address.'; }
        }
        async function fetchWalletBalance(userId) {
            const { data } = await supabaseClient.from('users').select('wallet').eq('id', userId).single();
            if (data) { currentUserWallet = data.wallet; document.getElementById('walletBalance').textContent = `Wallet: $${currentUserWallet.toFixed(2)}`; }
        }
        async function createGame() {
            const { data: { user } } = await supabaseClient.auth.getUser();
            if (!user) return Swal.fire("Not logged in.");
            const title = document.getElementById('gameTitle').value.trim();
            const startTime = document.getElementById('startDateTime').value;
            const treasureCount = parseInt(document.getElementById('treasures').value);
            const totalValue = parseFloat(document.getElementById('value').value);
            if (!title || !startTime || !treasureCount || isNaN(totalValue) || !selectedCoords) { return Swal.fire("Validation Error", "Please complete all fields correctly.", "warning"); }
            if (currentUserWallet < totalValue) { return Swal.fire("Insufficient Funds", "Your wallet balance is less than the total prize value.", "error"); }
            const newGame = { creator_id: user.id, title, start_time: new Date(startTime).toISOString(), treasure_count: treasureCount, total_value: totalValue, location: `POINT(${selectedCoords.lng} ${selectedCoords.lat})`, status: 'pending' };
            const { error } = await supabaseClient.from('games').insert(newGame);
            if (error) { return Swal.fire("Database Error", `Could not save the game: ${error.message}`, "error"); }
            const newBalance = currentUserWallet - totalValue;
            await supabaseClient.from('users').update({ wallet: newBalance }).eq('id', user.id);
            await fetchWalletBalance(user.id);
            Swal.fire("Game Created!", "Your game has been saved successfully.", "success");
            hideForm();
            loadExistingGames(user.id);
        }
        async function loadExistingGames(userId) {
            existingMarkers.forEach(marker => marker.remove());
            existingMarkers = [];
            const { data, error } = await supabaseClient.rpc('get_games_by_creator', { user_id_input: userId });
            if (error || !data) {
                updateGamesSummary(0);
                console.error("Failed to load games:", error);
                return;
            }
            updateGamesSummary(data.length);
            data.forEach(game => {
                if (game.location?.type === 'Point' && game.location.coordinates) {
                    const coords = game.location.coordinates;
                    const marker = new mapboxgl.Marker({ color: 'orange' }).setLngLat(coords).addTo(map);
                    existingMarkers.push(marker);
                    marker.getElement().addEventListener('click', async (e) => {
                        e.stopPropagation();
                        if(activePopup) activePopup.remove();
                        const address = await getAddressForCoords(coords);
                        const formattedDate = new Date(game.start_time).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
                        const popupContent = `<div style="font-size: 14px; max-width: 250px;"><p style="margin: 0; font-weight: bold;">${address}</p><hr style="border-color: rgba(255,255,255,0.2); margin: 8px 0;"><p style="margin: 0;"><strong>Starts:</strong> ${formattedDate}</p><p style="margin: 0;"><strong>Treasures:</strong> ${game.treasure_count}</p><p style="margin: 0;"><strong>Value:</strong> $${game.total_value}</p></div>`;
                        activePopup = new mapboxgl.Popup({ offset: 25, anchor: 'bottom' }).setLngLat(coords).setHTML(popupContent).addTo(map);
                    });
                }
            });
        }
        window.onload = async () => {
            const { data: { session } } = await supabaseClient.auth.getSession();
            if (!session) return;
            const user = session.user;
            await fetchWalletBalance(user.id);
            mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
            map = new mapboxgl.Map({ container: 'map', style: 'mapbox://styles/mapbox/dark-v11', center: [-73.78, 41.03], zoom: 12 });
            map.on('load', () => {
                map.resize();
                loadExistingGames(user.id);
                document.getElementById('createBtn').addEventListener('click', createGame);
                document.getElementById('closeFormBtn').addEventListener('click', hideForm);
            });
            map.on('dragstart', hideForm);
            map.on('click', async (e) => {
                if (e.originalEvent.target.closest('.mapboxgl-marker')) return;
                hideForm();
                if(activePopup) activePopup.remove();
                selectedCoords = e.lngLat;
                if (mapMarker) { mapMarker.setLngLat(selectedCoords); }
                else { mapMarker = new mapboxgl.Marker({ color: '#17a2b8' }).setLngLat(selectedCoords).addTo(map); }
                const address = await getAddressForCoords([selectedCoords.lng, selectedCoords.lat]);
                document.getElementById('locText').textContent = address;
                const popupContent = `<div style="text-align: center;"><p style="font-weight: bold; margin: 0 0 10px 0;">${address}</p><button onclick="confirmLocationAndShowForm()" style="width: 100%; padding: 8px; border: none; background-color: #28a745; color: white; border-radius: 4px; cursor: pointer;">Select This Location</button></div>`;
                activePopup = new mapboxgl.Popup({ closeButton: false, offset: 25, anchor: 'bottom' }).setLngLat(selectedCoords).setHTML(popupContent).addTo(map);
            });
        };
    </script>