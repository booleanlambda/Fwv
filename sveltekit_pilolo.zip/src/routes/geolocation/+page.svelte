
<body>
<h2>Iframe - Target for a Link</h2>
<input id="page" width="100vw"/>
<button id="go">Go</button>
<iframe height="500" id="iframe" src="https://192.168.1.139:8080/login.html" title="Inline Frame Example" width="100%">
</iframe>
</body>
<script>
document.getElementById("go").onclick=function(){
  alert()
//document.getElementById("iframe").src=document.getElementById("page").value
}
</script>