<style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      /* FIX: Replaced external image with a reliable CSS background */
      background-color: #1a1a2e;
      background-image:
        linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
      background-size: 30px 30px;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
    }
    .profile-card {
      position: relative;
      background: rgba(20, 20, 30, 0.75);
      backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      width: 100%;
      max-width: 420px;
    }
    .exit-link {
        position: absolute;
        top: 20px;
        left: 24px;
        color: rgba(255, 255, 255, 0.7);
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        transition: color 0.2s;
    }
    .exit-link:hover {
        color: #fff;
    }
    .exit-link i {
        margin-right: 6px;
    }
    .profile-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      text-align: left;
      margin-top: 40px; /* Make space for exit link */
      margin-bottom: 20px;
    }
    .profile-header h2 { font-size: 24px; margin: 0; }
    .profile-header p { color: rgba(255,255,255,0.8); margin: 4px 0 0; font-size: 14px; }
    .edit-profile-btn {
        background: rgba(255, 255, 255, 0.15);
        color: #fff;
        padding: 8px 12px;
        border-radius: 6px;
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        transition: background-color 0.2s;
    }
    .edit-profile-btn:hover {
        background: rgba(255, 255, 255, 0.3);
    }
    .profile-details { text-align: left; margin-top: 20px; }
    .profile-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 12px 0;
      border-bottom: 1px solid rgba(255,255,255,0.2);
    }
    .profile-label { display: flex; align-items: center; gap: 12px; color: rgba(255,255,255,0.85); }
    .profile-value { font-weight: 500; }
    a.profile-item {
        text-decoration: none;
        color: inherit;
        transition: background-color 0.2s;
        margin: 0 -24px;
        padding: 12px 24px;
    }
    a.profile-item:hover {
        background: rgba(255,255,255,0.05);
    }
    a.profile-item .profile-value::after {
        content: ' >';
        color: rgba(255,255,255,0.5);
        font-weight: bold;
        margin-left: 8px;
    }
    details { margin-top: 12px; background: rgba(0,0,0,0.1); border-radius: 8px; border: 1px solid rgba(255,255,255,0.1);}
    summary { padding: 12px 14px; cursor: pointer; list-style: none; display: flex; justify-content: space-between; align-items: center; font-weight: bold; }
    .chevron { transition: transform 0.2s; }
    details[open] .chevron { transform: rotate(90deg); }
    .game-list { padding: 0 14px 14px; color: rgba(255,255,255,0.9); font-size: 14px; line-height: 1.8; }
    .btn-row { display: grid; grid-template-columns: 1fr; gap: 10px; margin-top: 24px; }
    .btn { background: rgba(0,0,0,0.2); color: white; border: none; padding: 12px; border-radius: 8px; cursor: pointer; font-weight: bold; font-size: 16px; display: flex; align-items: center; justify-content: center; gap: 8px; text-decoration: none; transition: background-color 0.2s; }
    .btn:hover { background: rgba(0,0,0,0.4); }
    .btn-logout { background-color: #dc3545; }
  </style>
<body>
<div class="profile-card">
<a class="exit-link" href="map.html"><i class="fas fa-arrow-left"></i> Back to Map</a>
<div class="profile-header">
<div>
<h2 id="username">Loading...</h2>
<p id="email">...</p>
</div>
<a class="edit-profile-btn" href="editprofile.html"><i class="fas fa-edit"></i> Edit</a>
</div>
<div class="profile-details">
<div class="profile-item">
<span class="profile-label"><i class="fas fa-user"></i> First Name</span>
<span class="profile-value" id="firstName">...</span>
</div>
<div class="profile-item">
<span class="profile-label"><i class="fas fa-user"></i> Last Name</span>
<span class="profile-value" id="lastName">...</span>
</div>
<div class="profile-item">
<span class="profile-label"><i class="fas fa-phone"></i> Phone</span>
<span class="profile-value" id="phone">N/A</span>
</div>
<div class="profile-item">
<span class="profile-label"><i class="fas fa-globe"></i> Country</span>
<span class="profile-value" id="country">N/A</span>
</div>
<a class="profile-item" href="wallet.html">
<span class="profile-label"><i class="fas fa-wallet"></i> Wallet</span>
<span class="profile-value" id="wallet">$0.00</span>
</a>
<details>
<summary>Games Created <i class="fas fa-chevron-right chevron"></i></summary>
<div class="game-list" id="gamesCreated">Loading...</div>
</details>
<details>
<summary>Games Joined <i class="fas fa-chevron-right chevron"></i></summary>
<div class="game-list" id="gamesJoined">Loading...</div>
</details>
</div>
<div class="btn-row">
<button class="btn btn-logout" id="logoutBtn"><i class="fas fa-sign-out-alt"></i> Logout</button>
</div>
</div>
<script>
    async function populateProfileDetails(user) {
        document.getElementById("username").textContent = user.user_metadata?.username || 'User';
        document.getElementById("email").textContent = user.email || 'Not available';
        const { data: profile } = await supabaseClient.from("users").select("*").eq("id", user.id).single();
        if (profile) {
            document.getElementById("firstName").textContent = profile.first_name || 'N/A';
            document.getElementById("lastName").textContent = profile.last_name || 'N/A';
            document.getElementById("phone").textContent = profile.phone_number || 'N/A';
            document.getElementById("country").textContent = profile.country || 'N/A';
            document.getElementById("wallet").textContent = `$${(profile.wallet || 0).toFixed(2)}`;
        }
    }

    async function populateCreatedGames(userId) {
        const { data, error } = await supabaseClient.rpc('get_creator_dashboard', { user_id_input: userId });
        const listEl = document.getElementById("gamesCreated");
        if (error || !data || data.length === 0) {
            listEl.innerHTML = 'No games created yet.';
            return;
        }
        listEl.innerHTML = data.map(game => `<div>${game.title || 'Untitled'} - (${game.status})</div>`).join('');
    }

    async function populateJoinedGames(userId) {
        const { data, error } = await supabaseClient.rpc('get_player_dashboard', { user_id_input: userId });
        const listEl = document.getElementById("gamesJoined");
        if (error || !data || !data.length) {
            listEl.innerHTML = 'No games joined yet.';
            return;
        }
        listEl.innerHTML = data.map(game => `<div>${game.title || 'Untitled'}</div>`).join('');
    }

    async function initializeProfile() {
      const user = await verifySession(); 
      if (user) {
        await Promise.all([
            populateProfileDetails(user),
            populateCreatedGames(user.id),
            populateJoinedGames(user.id)
        ]);
      } else {
        document.body.innerHTML = `<div class="profile-card" style="text-align:center;"><h1>Please Log In</h1><a class="btn" href="login.html" style="display:inline-block; margin-top:10px;">Go to Login</a></div>`;
      }
    }

    document.getElementById("logoutBtn").onclick = logout
    document.addEventListener('DOMContentLoaded', initializeProfile);
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="session.js"></script>
<script>
    async function populateProfileDetails(user) {
        document.getElementById("username").textContent = user.user_metadata?.username || 'User';
        document.getElementById("email").textContent = user.email || 'Not available';
        const { data: profile } = await supabaseClient.from("users").select("*").eq("id", user.id).single();
        if (profile) {
            document.getElementById("firstName").textContent = profile.first_name || 'N/A';
            document.getElementById("lastName").textContent = profile.last_name || 'N/A';
            document.getElementById("phone").textContent = profile.phone_number || 'N/A';
            document.getElementById("country").textContent = profile.country || 'N/A';
            document.getElementById("wallet").textContent = `$${(profile.wallet || 0).toFixed(2)}`;
        }
    }

    async function populateCreatedGames(userId) {
        const { data, error } = await supabaseClient.rpc('get_creator_dashboard', { user_id_input: userId });
        const listEl = document.getElementById("gamesCreated");
        if (error || !data || data.length === 0) {
            listEl.innerHTML = 'No games created yet.';
            return;
        }
        listEl.innerHTML = data.map(game => `<div>${game.title || 'Untitled'} - (${game.status})</div>`).join('');
    }

    async function populateJoinedGames(userId) {
        const { data, error } = await supabaseClient.rpc('get_player_dashboard', { user_id_input: userId });
        const listEl = document.getElementById("gamesJoined");
        if (error || !data || !data.length) {
            listEl.innerHTML = 'No games joined yet.';
            return;
        }
        listEl.innerHTML = data.map(game => `<div>${game.title || 'Untitled'}</div>`).join('');
    }

    async function initializeProfile() {
      const user = await verifySession(); 
      if (user) {
        await Promise.all([
            populateProfileDetails(user),
            populateCreatedGames(user.id),
            populateJoinedGames(user.id)
        ]);
      } else {
        document.body.innerHTML = `<div class="profile-card" style="text-align:center;"><h1>Please Log In</h1><a class="btn" href="login.html" style="display:inline-block; margin-top:10px;">Go to Login</a></div>`;
      }
    }

    document.getElementById("logoutBtn").onclick = logout
    document.addEventListener('DOMContentLoaded', initializeProfile);
  </script>