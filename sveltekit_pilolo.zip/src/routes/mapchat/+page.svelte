
<body>
<h1>Simple Firebase Chat</h1>
<div id="messages"></div>
<hr/>
<form id="messageForm">
<input autocomplete="off" id="messageInput" placeholder="Type a message..." required="" type="text"/>
<button type="submit">Send</button>
</form>
<script type="module">
        // Import functions from the Firebase SDK
        import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
        import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";
        import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";

        // --- PASTE YOUR FIREBASE CONFIGURATION HERE ---
        const firebaseConfig = {
          apiKey: "AIzaSyCQ7lGF8CRYOZC8m94vqNSbuFFKQAhKeTE",
          authDomain: "pilolo-chat-7c443.firebaseapp.com",
          projectId: "pilolo-chat-7c443",
          storageBucket: "pilolo-chat-7c443.appspot.com",
          messagingSenderId: "328898324550",
          appId: "1:328898324550:web:d1e8f4b6869c9920ff4247"
        };

        // --- INITIALIZE FIREBASE & GET SERVICES ---
        const app = initializeApp(firebaseConfig);
        const db = getFirestore(app);
        const auth = getAuth(app);

        // --- DOM ELEMENTS ---
        const messagesContainer = document.getElementById('messages');
        const messageForm = document.getElementById('messageForm');
        const messageInput = document.getElementById('messageInput');

        // --- MAIN LOGIC ---

        // 1. Sign in the user anonymously
        signInAnonymously(auth).catch((error) => {
            console.error("Anonymous sign-in failed:", error);
        });
        
        // 2. Listen for real-time messages from Firestore
        const messagesRef = collection(db, "messages");
        const q = query(messagesRef, orderBy("createdAt", "asc"));

        onSnapshot(q, (snapshot) => {
            messagesContainer.innerHTML = ''; // Clear previous messages
            snapshot.forEach((doc) => {
                const message = doc.data();
                const messageElement = document.createElement('div');
                // Display the user ID and text
                messageElement.textContent = `[${message.uid.substring(0, 6)}]: ${message.text}`;
                messagesContainer.appendChild(messageElement);
            });
            // Auto-scroll to the bottom
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, (error) => {
             console.error("Error listening to messages: ", error);
        });

        // 3. Handle sending new messages
        messageForm.addEventListener('submit', async (e) => {
            e.preventDefault(); // Prevent form from refreshing the page

            const text = messageInput.value.trim();
            const user = auth.currentUser;

            if (text && user) {
                try {
                    await addDoc(messagesRef, {
                        text: text,
                        createdAt: serverTimestamp(),
                        uid: user.uid
                    });
                    messageInput.value = ''; // Clear the input field
                } catch (error) {
                    console.error("Error sending message: ", error);
                }
            }
        });
    </script>
</body>
<script type="module">
        // Import functions from the Firebase SDK
        import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
        import { getFirestore, collection, addDoc, query, orderBy, onSnapshot, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";
        import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";

        // --- PASTE YOUR FIREBASE CONFIGURATION HERE ---
        const firebaseConfig = {
          apiKey: "AIzaSyCQ7lGF8CRYOZC8m94vqNSbuFFKQAhKeTE",
          authDomain: "pilolo-chat-7c443.firebaseapp.com",
          projectId: "pilolo-chat-7c443",
          storageBucket: "pilolo-chat-7c443.appspot.com",
          messagingSenderId: "328898324550",
          appId: "1:328898324550:web:d1e8f4b6869c9920ff4247"
        };

        // --- INITIALIZE FIREBASE & GET SERVICES ---
        const app = initializeApp(firebaseConfig);
        const db = getFirestore(app);
        const auth = getAuth(app);

        // --- DOM ELEMENTS ---
        const messagesContainer = document.getElementById('messages');
        const messageForm = document.getElementById('messageForm');
        const messageInput = document.getElementById('messageInput');

        // --- MAIN LOGIC ---

        // 1. Sign in the user anonymously
        signInAnonymously(auth).catch((error) => {
            console.error("Anonymous sign-in failed:", error);
        });
        
        // 2. Listen for real-time messages from Firestore
        const messagesRef = collection(db, "messages");
        const q = query(messagesRef, orderBy("createdAt", "asc"));

        onSnapshot(q, (snapshot) => {
            messagesContainer.innerHTML = ''; // Clear previous messages
            snapshot.forEach((doc) => {
                const message = doc.data();
                const messageElement = document.createElement('div');
                // Display the user ID and text
                messageElement.textContent = `[${message.uid.substring(0, 6)}]: ${message.text}`;
                messagesContainer.appendChild(messageElement);
            });
            // Auto-scroll to the bottom
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }, (error) => {
             console.error("Error listening to messages: ", error);
        });

        // 3. Handle sending new messages
        messageForm.addEventListener('submit', async (e) => {
            e.preventDefault(); // Prevent form from refreshing the page

            const text = messageInput.value.trim();
            const user = auth.currentUser;

            if (text && user) {
                try {
                    await addDoc(messagesRef, {
                        text: text,
                        createdAt: serverTimestamp(),
                        uid: user.uid
                    });
                    messageInput.value = ''; // Clear the input field
                } catch (error) {
                    console.error("Error sending message: ", error);
                }
            }
        });
    </script>