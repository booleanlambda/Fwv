<style>
    :root {
      --primary-color: #5b86e5;
      --secondary-color: #36d1dc;
      --text-color: #34495e;
      --bg-color: #f9f9f9;
      --panel-color: #ffffff;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      margin: 0;
      background-color: var(--bg-color);
      color: var(--text-color);
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 25px;
      background: linear-gradient(90deg, var(--primary-color) 0%, var(--secondary-color) 100%);
      color: white;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    header h1 { margin: 0; font-size: 22px; }
    .exit-btn {
      color: #fff;
      text-decoration: none;
      font-weight: bold;
      background: rgba(255, 255, 255, 0.2);
      padding: 10px 18px;
      border-radius: 20px;
      transition: background-color 0.2s;
    }
    .exit-btn:hover { background-color: rgba(255, 255, 255, 0.3); }

    .container {
      max-width: 800px;
      margin: 30px auto;
      padding: 0 20px;
    }

    .role-selector {
      display: flex;
      border-radius: 12px;
      overflow: hidden;
      border: 1px solid #ddd;
      margin-bottom: 30px;
    }
    .role-tab {
      flex: 1;
      padding: 15px;
      text-align: center;
      background-color: #e9e9e9;
      cursor: pointer;
      font-weight: bold;
      color: #777;
      transition: background-color 0.3s, color 0.3s;
    }
    .role-tab:not(:last-child) { border-right: 1px solid #ddd; }
    .role-tab.active {
      background: var(--primary-color);
      color: white;
    }
    
    .instructions-content {
      display: none;
      opacity: 0;
      transition: opacity 0.5s ease-in-out;
    }
    .instructions-content.active {
      display: block;
      opacity: 1;
    }

    .steps-list {
      list-style: none;
      padding: 0;
      counter-reset: steps-counter;
    }
    .step-item {
      display: flex;
      align-items: flex-start;
      gap: 20px;
      padding: 25px;
      margin-bottom: 20px;
      background-color: var(--panel-color);
      border-radius: 12px;
      box-shadow: 0 4px 15px rgba(0,0,0,0.05);
      position: relative;
    }
    .step-item::before {
      counter-increment: steps-counter;
      content: counter(steps-counter);
      position: absolute;
      top: 15px;
      left: -15px;
      width: 40px;
      height: 40px;
      background: linear-gradient(90deg, var(--primary-color) 0%, var(--secondary-color) 100%);
      border-radius: 50%;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
      font-size: 18px;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .step-icon {
      flex-shrink: 0;
      width: 50px;
      height: 50px;
      stroke: var(--primary-color);
    }
    .step-text h3 {
      margin: 0 0 8px 0;
      font-size: 18px;
      color: var(--text-color);
    }
    .step-text p {
      margin: 0;
      font-size: 16px;
      line-height: 1.6;
      color: #666;
    }
  </style>
<body>
<header>
<h1>How to Play</h1>
<a class="exit-btn" href="map.html">Back to Map</a>
</header>
<div class="container">
<div class="role-selector">
<div class="role-tab active" data-role="player">For Players (Seekers)</div>
<div class="role-tab" data-role="creator">For Creators (Custodians)</div>
</div>
<div class="instructions-content active" id="player-content">
<ol class="steps-list">
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><path d="M1 6v16l7-4 8 4 7-4V2l-7 4-8-4-7 4z"></path><line x1="8" x2="8" y1="2" y2="18"></line><line x1="16" x2="16" y1="6" y2="22"></line></svg>
<div class="step-text">
<h3>1. Explore the Map</h3>
<p>Open the map to see all the active and upcoming games in your area. Each yellow dot represents a game with a hidden prize.</p>
</div>
</li>
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
<div class="step-text">
<h3>2. Get Close</h3>
<p>Physically travel to the location of the game you want to play. You must be within 100 feet of the game's center to join and dig.</p>
</div>
</li>
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="20" x2="20" y1="8" y2="14"></line><line x1="23" x2="17" y1="11" y2="11"></line></svg>
<div class="step-text">
<h3>3. Join the Game</h3>
<p>Tap the game's marker on the map and click the "Join Game" button. You are now officially a seeker in that game!</p>
</div>
</li>
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><path d="M14 9c-1.94 1.94-3.41 4.47-4.17 7.55-1.49.17-2.81.76-3.83 1.45-1.02.69-1.33 2.02-.64 3.04.69 1.02 2.02 1.33 3.04.64.4-.27.73-.62.98-1.01M17 6l3 3M22 2l-3 3"></path><path d="M9.5 12.5c4.004-1.035 6.958-3.989 7.993-7.993"></path></svg>
<div class="step-text">
<h3>4. Dig for Treasure</h3>
<p>Once the game is live, the "DIG" button will activate. Tap it to search the area. You have a limited number of digs per game!</p>
</div>
</li>
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><line x1="12" x2="12" y1="16" y2="12"></line><line x1="12" x2="12.01" y1="8" y2="8"></line></svg>
<div class="step-text">
<h3>5. Win &amp; Earn Bonuses</h3>
<p>Prizes you find are automatically added to your wallet. If you use all your digs (win or lose), you'll earn bonus digs for the next game you play!</p>
</div>
</li>
</ol>
</div>
<div class="instructions-content" id="creator-content">
<ol class="steps-list">
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="3"></circle></svg>
<div class="step-text">
<h3>1. Choose a Location</h3>
<p>Navigate to the "Create Game" page and tap anywhere on the map to set the center point for your new game.</p>
</div>
</li>
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
<div class="step-text">
<h3>2. Set the Details</h3>
<p>The form panel will appear. Give your game a title, set a start time, and decide the number of treasures and the total prize value.</p>
</div>
</li>
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><path d="M21 12V7H5a2 2 0 0 1 0-4h14v4zM3 5v14a2 2 0 0 0 2 2h16v-5h-6a2 2 0 0 1-2-2v-1a2 2 0 0 1 2-2h6V5H3z"></path></svg>
<div class="step-text">
<h3>3. Fund Your Game</h3>
<p>The total prize value for the game will be deducted from your wallet balance upon creation. Make sure you have sufficient funds!</p>
</div>
</li>
<li class="step-item">
<svg class="step-icon" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
<div class="step-text">
<h3>4. Launch!</h3>
<p>Click "Create Game". The system will verify your location and time slot. If available, your game will be scheduled and become visible to all players.</p>
</div>
</li>
</ol>
</div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const tabs = document.querySelectorAll('.role-tab');
      const contents = document.querySelectorAll('.instructions-content');

      tabs.forEach(tab => {
        tab.addEventListener('click', () => {
          // Deactivate all tabs and content
          tabs.forEach(t => t.classList.remove('active'));
          contents.forEach(c => c.classList.remove('active'));

          // Activate the clicked tab and its corresponding content
          tab.classList.add('active');
          const role = tab.getAttribute('data-role');
          document.getElementById(`${role}-content`).classList.add('active');
        });
      });
    });
  </script>
</body>
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const tabs = document.querySelectorAll('.role-tab');
      const contents = document.querySelectorAll('.instructions-content');

      tabs.forEach(tab => {
        tab.addEventListener('click', () => {
          // Deactivate all tabs and content
          tabs.forEach(t => t.classList.remove('active'));
          contents.forEach(c => c.classList.remove('active'));

          // Activate the clicked tab and its corresponding content
          tab.classList.add('active');
          const role = tab.getAttribute('data-role');
          document.getElementById(`${role}-content`).classList.add('active');
        });
      });
    });
  </script>