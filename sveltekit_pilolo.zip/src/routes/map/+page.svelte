<style>
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; overflow: hidden; }
    #map { position: absolute; top: 0; bottom: 0; width: 100%; }
    .ui-panel {
      position: absolute; z-index: 2;
      background: rgba(20, 20, 30, 0.75);
      backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
      color: white; border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    #header {
      top: 10px; left: 10px; right: 10px; padding: 8px 12px;
      border-radius: 12px; display: flex; justify-content: space-between; align-items: center;
    }
    #header h2 { margin: 0; font-size: 16px; }
    .header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .header-icon-btn {
        padding: 8px;
        background: rgba(255, 255, 255, 0.2);
        border: none;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        transition: background-color 0.2s;
    }
    .header-icon-btn:hover {
        background: rgba(255, 255, 255, 0.3);
    }
    #bottom-bar {
      bottom: 20px; left: 50%; transform: translateX(-50%); padding: 10px;
      border-radius: 50px; display: flex; align-items: center; gap: 10px;
    }
    #digButton {
      padding: 12px 24px; font-size: 18px; font-weight: bold; color: white; border: none; border-radius: 30px;
      background-color: #555; cursor: pointer; transition: background-color 0.2s;
    }
    #digButton.enabled { background-color: #ffcc00; color: #111; }
    #chatBtn { background: none; border: none; color: white; cursor: pointer; padding: 8px; }
    #distance-info {
        position: absolute; bottom: 100px; left: 50%; transform: translateX(-50%);
        background: rgba(0,0,0,0.6); color: #ffc107; padding: 8px 16px;
        border-radius: 20px; font-size: 14px; font-weight: bold; z-index: 2; display: none;
    }
    #chatBox {
      position: absolute; bottom: 90px; right: 10px; z-index: 3; width: 90%;
      max-width: 300px; height: 350px; border-radius: 16px; display: none;
      flex-direction: column; overflow: hidden;
    }
    #chatMessages { flex: 1; padding: 10px; overflow-y: auto; font-size: 14px; }
    #chatMessages div { margin-bottom: 8px; line-height: 1.4; }
    #chatMessages b { color: #ffc107; }
    .chat-timestamp { font-size: 11px; color: #888; margin-left: 8px; }
    #chatInput { display: flex; border-top: 1px solid rgba(255, 255, 255, 0.1); }
    #chatInput input { flex: 1; padding: 12px; border: none; background: transparent; color: white; }
    #chatInput button { background: #ffcc00; color: #111; border: none; padding: 0 15px; font-weight: bold; cursor: pointer; }
    .mapboxgl-popup-content {
      background: rgba(20, 20, 30, 0.85); backdrop-filter: blur(10px);
      color: white; border-radius: 12px; padding: 15px; max-width: 240px;
    }
    .game-popup h3 { margin: 0 0 5px; }
    .game-popup p { margin: 0 0 10px; font-size: 14px; color: #ccc; }
    .game-popup .game-creator { font-size: 12px; color: #ccc; margin-top: -5px; margin-bottom: 15px; }
    .game-popup .time-info { font-weight: bold; color: #ffc107; margin-bottom: 15px;}
    .game-popup button {
      width: 100%; padding: 10px; border: none; border-radius: 8px;
      font-weight: bold; color: #fff; background-color: #28a745; cursor: pointer;
    }
    .game-popup .button-group { display: flex; gap: 10px; }
    .game-popup .chat-btn { background-color: #0d6efd; }
    .game-popup .exit-btn { background-color: #dc3545; }

    /* --- Loading Screen Styles --- */
    #loader-wrapper {
        position: fixed;
        top: 0; left: 0;
        width: 100%; height: 100%;
        background-color: #12121a;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: 1000;
        transition: opacity 0.5s ease;
    }
    .loader-text {
        color: rgba(255, 255, 255, 0.8);
        font-size: 18px;
        margin-bottom: 20px;
    }
    .line-container {
      width: 150px;
    }
    .line {
        width: 100%;
        height: 2px;
        background: #ffc107;
        margin: 6px 0;
        animation: scan 1.8s ease-in-out infinite;
        transform-origin: center;
    }
    .line:nth-child(2) { animation-delay: 0.15s; }
    .line:nth-child(3) { animation-delay: 0.3s; }

    @keyframes scan {
        0%   { transform: scaleX(0); opacity: 0.5; }
        50%  { transform: scaleX(1); opacity: 1; }
        100% { transform: scaleX(0); opacity: 0.5; }
    }
  </style>
<body>
<div id="loader-wrapper">
<div class="loader-text">Initializing Map</div>
<div class="line-container">
<div class="line"></div>
<div class="line"></div>
<div class="line"></div>
</div>
</div>
<div id="map"></div>
<div class="ui-panel" id="header">
<h2 id="gameTitle">Explore Games</h2>
<div class="header-actions">
<button class="header-icon-btn" onclick="window.location.href='howto.html'" title="How to Play">
<svg fill="white" height="24" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"></path></svg>
</button>
<button class="header-icon-btn" onclick="window.location.href='creategame.html'" title="Create Game">
<svg fill="white" height="24" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"></path></svg>
</button>
<button class="header-icon-btn" onclick="window.location.href='profile.html'" title="Profile">
<svg fill="white" height="24" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2a5 5 0 110 10 5 5 0 010-10zm0 12c-3.33 0-10 1.67-10 5v3h20v-3c0-3.33-6.67-5-10-5z"></path></svg>
</button>
</div>
</div>
<div id="distance-info"></div>
<div class="ui-panel" id="bottom-bar">
<button id="digButton">DIG</button>
<button id="chatBtn" onclick="toggleChat()">
<svg fill="white" height="28" viewbox="0 0 24 24" width="28" xmlns="http://www.w3.org/2000/svg"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"></path></svg>
</button>
</div>
<div class="ui-panel" id="chatBox">
<div id="chatMessages"><div>No game selected.</div></div>
<form id="chatForm">
<div id="chatInput">
<input autocomplete="off" id="chatText" placeholder="Say something..." type="text"/>
<button type="submit">Send</button>
</div>
</form>
</div>
<script>
    let map, currentUser, playerLocation, selectedGame = null, userMarker = null, db;
    let gameMarkers = {};
    let unsubscribeFromChat = null;

    const digButton = document.getElementById('digButton');
    const distanceInfo = document.getElementById('distance-info');
    const gameTitleEl = document.getElementById('gameTitle');
    const chatBox = document.getElementById('chatBox');
    const chatMessagesEl = document.getElementById('chatMessages');
    const chatForm = document.getElementById('chatForm');
    const chatTextInput = document.getElementById('chatText');
    
    const firebaseConfig = {
        apiKey: "AIzaSyCQ7lGF8CRYOZC8m94vqNSbuFFKQAhKeTE",
        authDomain: "pilolo-chat-7c443.firebaseapp.com",
        projectId: "pilolo-chat-7c443",
        storageBucket: "pilolo-chat-7c443.appspot.com",
        messagingSenderId: "328898324550",
        appId: "1:328898324550:web:d1e8f4b6869c9920ff4247"
    };

    async function handleGameInteraction(gameId) {
      if (!currentUser) return Swal.fire('Error', 'You must be logged in.', 'error');
      if (selectedGame && selectedGame.id === gameId) return Swal.fire('Info', 'You are already in this game.', 'info');
      if (!playerLocation) return Swal.fire('Location Error', 'Could not get your current location.', 'warning');

      const { data: response, error } = await supabaseClient.rpc('join_game', {
        user_id_input: currentUser.id,
        game_id_input: gameId,
        player_lon: playerLocation[0],
        player_lat: playerLocation[1]
      });

      if (error || (response && response.startsWith('Error:'))) {
        const errorMessage = response ? response.replace('Error: ', '') : error.message;
        return Swal.fire('Could Not Join', errorMessage, 'warning');
      }
      
      const { data: game, error: gameError } = await supabaseClient.rpc('get_game_details', { game_id_input: gameId }).single();
      if (gameError || !game) {
        return Swal.fire('Error', 'Could not load game details after joining.', 'error');
      }

      if (game.game_id && !game.id) game.id = game.game_id;

      if (game.status === 'in_progress') {
        const { error: playError } = await supabaseClient.rpc('play_game_if_live', { user_id_input: currentUser.id, game_id_input: gameId });
        if (playError) {
          return Swal.fire('Join OK, but...', 'Failed to mark you as playing. Try again.', 'warning');
        }
        Swal.fire('Let’s Go!', 'Game is live — you can dig now!', 'success');
      } else {
        Swal.fire('Joined!', 'You have successfully joined the game. It will start soon.', 'success');
      }
      selectGame(game);
    }
    
    async function exitGame(isGameOver = false) {
        if (!currentUser || !selectedGame) return;
        const gameId = selectedGame.id;
        
        await supabaseClient.from('user_groups').update({ status: 'exited', is_active: false }).eq('user_id', currentUser.id).eq('game_id', gameId);
        
        const originalGameData = gameMarkers[gameId]?.gameData;
        selectedGame = null;
        gameTitleEl.textContent = 'Explore Games';

        if (typeof unsubscribeFromChat === 'function') {
            unsubscribeFromChat();
            unsubscribeFromChat = null;
        }

        chatMessagesEl.innerHTML = '<div>No game selected.</div>';
        
        if(!isGameOver) Swal.fire('Exited', 'You have left the game.', 'info');
        if (originalGameData) updateGameMarkerPopup(gameId, originalGameData);
        checkProximity();
    }
    
    function updateGameMarkerPopup(gameId, gameData) {
        const marker = gameMarkers[gameId];
        if (!marker || !gameData) return;

        let timeInfoHTML = '';
        if (gameData.status === 'pending') {
            timeInfoHTML = `<p class="time-info">Starts at: ${new Date(gameData.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>`;
        } else if (gameData.status === 'in_progress') {
            timeInfoHTML = `<p class="time-info">Live! Ends at: ${new Date(gameData.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>`;
        }
        
        const definitiveGameId = gameData.id || gameData.game_id;
        let buttonHTML = `<button onclick="handleGameInteraction('${definitiveGameId}')">Join Game</button>`;

        if (selectedGame?.id === gameId) {
             buttonHTML = `<div class="button-group"><button class="chat-btn" onclick="openChatForGame()">Chat</button><button class="exit-btn" onclick="exitGame()">Exit</button></div>`;
        }

        const popupContent = `<div class="game-popup"><h3>${gameData.title}</h3><p>Prize: $${gameData.total_value} | Treasures: ${gameData.treasure_count}</p><p class="game-creator">by ${gameData.creator_username}</p>${timeInfoHTML}${buttonHTML}</div>`;
        const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(popupContent);
        marker.setPopup(popup);
    }
    
    function openChatForGame() {
        if (!selectedGame) return;
        subscribeToChat();
        toggleChat();
    }

    function selectGame(game) {
      selectedGame = game;
      gameTitleEl.textContent = `Playing: ${game.title}`;
      updateGameMarkerPopup(game.id, game);
      subscribeToChat();
      checkProximity();
    }
    
    async function digForTreasure() {
        if (!currentUser || !playerLocation) return;
        if (!selectedGame) return Swal.fire('Cannot Dig', 'You must be playing a game to dig.', 'info');

        try {
            const { data: result, error } = await supabaseClient.rpc('dig_for_treasure', {
                user_id_input: currentUser.id, game_id_input: selectedGame.id,
                player_lon: playerLocation[0], player_lat: playerLocation[1]
            });

            if (error) return Swal.fire('Error', error.message || 'An error occurred.', 'error');
            
            const valueMatch = result.match(/\$?([\d.]+)/);
            const value = valueMatch ? valueMatch[1] : '?';
            
            if (result.startsWith("Success")) {
                handleSendMessage(`dug and found a treasure worth $${value}! 🎉`);
                Swal.fire("Congratulations!", result, "success");
            } else if (result.startsWith("You have reached your dig limit")) {
                Swal.fire("Dig Limit Reached", result, "info");
            } else {
                handleSendMessage("dug but found nothing.");
                Swal.fire("Keep Trying!", result, "warning");
            }
        } catch (err) {
            Swal.fire("Error", "An unexpected error occurred while digging.", "error");
        }
    }

    function checkProximity() {
        if (!playerLocation || !selectedGame?.location?.coordinates) {
            digButton.classList.remove('enabled');
            distanceInfo.style.display = 'none';
            return;
        }
        
        const gameCenterCoords = selectedGame.location.coordinates;
        const distanceToGameCenter = turf.distance(turf.point(playerLocation), turf.point(gameCenterCoords), { units: 'meters' });
        const isInsideGameRadius = distanceToGameCenter <= 30.5;
        digButton.classList.toggle('enabled', isInsideGameRadius);

        if (!isInsideGameRadius) {
            const distanceInFeet = Math.round(distanceToGameCenter * 3.28);
            distanceInfo.textContent = `${distanceInFeet} feet from game area`;
            distanceInfo.style.display = 'block';
        } else {
            distanceInfo.style.display = 'none';
        }
    }

    function setupPlayerLocator() {
        if (!navigator.geolocation) return Swal.fire('Geolocation Not Supported', 'Your browser does not support this feature.', 'error');
        
        map.addControl(new mapboxgl.GeolocateControl({
            positionOptions: { enableHighAccuracy: true },
            trackUserLocation: true,
            showUserHeading: true
        }));

        navigator.geolocation.watchPosition(
            (position) => {
                playerLocation = [position.coords.longitude, position.coords.latitude];
                if (!userMarker) {
                    const el = document.createElement('div');
                    el.style.cssText = `background: #00ffcc; border: 2px solid white; width: 14px; height: 14px; border-radius: 50%; box-shadow: 0 0 10px #00ffff;`;
                    userMarker = new mapboxgl.Marker(el).setLngLat(playerLocation).addTo(map);
                } else {
                    userMarker.setLngLat(playerLocation);
                }
                checkProximity();
            },
            (error) => console.error(`Geolocation Error (Code ${error.code}): ${error.message}`),
            { enableHighAccuracy: true, maximumAge: 3000, timeout: 27000 }
        );
    }
    
    function toggleChat() {
      if (!selectedGame) return Swal.fire('Info', "You must be playing a game to chat.", 'info');
      chatBox.style.display = chatBox.style.display === 'flex' ? 'none' : 'flex';
    }

    async function fetchAndDisplayGames() {
      const { data: games, error } = await supabaseClient.rpc('get_all_active_games_with_details');
      if (error) return console.error("Error fetching games:", error);
      
      const activeGameIds = new Set(games ? games.map(g => g.game_id || g.id) : []);

      if (selectedGame && !activeGameIds.has(selectedGame.id)) {
          Swal.fire('Game Over', `The game '${selectedGame.title}' has ended.`, 'info');
          exitGame(true);
          return;
      }

      Object.keys(gameMarkers).forEach(id => {
          if (!activeGameIds.has(Number(id))) {
              if (gameMarkers[id]) gameMarkers[id].remove();
              delete gameMarkers[id];
          }
      });
      
      if (!games) return;

      games.forEach(game => {
          if (game.game_id && !game.id) game.id = game.game_id;
          const gameId = game.id;
          if (!game.location?.coordinates) return;

          if (gameMarkers[gameId]) {
            gameMarkers[gameId].gameData = game;
            updateGameMarkerPopup(gameId, game);
          } else {
            const markerEl = document.createElement('div');
            markerEl.style.cssText = 'background-color: #ffc107; width: 18px; height: 18px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 8px rgba(0,0,0,0.6); cursor: pointer;';
            const marker = new mapboxgl.Marker(markerEl).setLngLat(game.location.coordinates).addTo(map);
            marker.gameData = game;
            gameMarkers[gameId] = marker;
            updateGameMarkerPopup(gameId, game);
          }
      });
    }
    
    async function handleSendMessage(e) {
      if (e && typeof e.preventDefault === 'function') e.preventDefault();
      
      const msg = (typeof e === 'string') ? e : chatTextInput.value.trim();
      if (!msg || !selectedGame || !currentUser) return;

      try {
        await db.collection('chats').doc(String(selectedGame.id)).collection('messages').add({
            text: msg,
            userId: currentUser.id,
            username: currentUser.email.split('@')[0],
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        if (typeof e !== 'string') chatTextInput.value = '';
      } catch (err) {
        console.error("Error sending message to Firestore:", err);
        Swal.fire("Chat Error", "Could not send message. Please check your connection or security rules.", "error");
      }
    }

    function displayNewMessage(message) {
      const username = message.username || 'A User';
      const timestamp = message.createdAt ? message.createdAt.toDate().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit'}) : '';
      const div = document.createElement('div');
      div.innerHTML = `<b>${username}</b>: ${message.text} <span class="chat-timestamp">${timestamp}</span>`;
      chatMessagesEl.appendChild(div);
      chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
    }

    function subscribeToChat() {
      if (typeof unsubscribeFromChat === 'function') unsubscribeFromChat();

      if (!selectedGame) {
        chatMessagesEl.innerHTML = '<div>No game selected.</div>';
        return;
      }
      chatMessagesEl.innerHTML = `<div><b>Joined chat for ${selectedGame.title}</b></div>`;
      
      const messagesQuery = db.collection('chats').doc(String(selectedGame.id)).collection('messages').orderBy('createdAt', 'asc');
      
      unsubscribeFromChat = messagesQuery.onSnapshot(querySnapshot => {
        querySnapshot.docChanges().forEach(change => {
          if (change.type === 'added') displayNewMessage(change.doc.data());
        });
      }, err => {
        console.error("Chat subscription error:", err);
      });
    }

    async function initializeAppWithLocation(center) {
        mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
        map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/navigation-night-v1?optimized=true',
            center: center,
            zoom: 10
        });

        map.on('load', async () => {
            // Remove loader when map is ready
            const loader = document.getElementById('loader-wrapper');
            if (loader) {
                loader.style.opacity = '0';
                setTimeout(() => { loader.style.display = 'none'; }, 500);
            }
       
            currentUser = await verifySession();
            if (!currentUser) {
              console.error("Could not verify user session. App cannot start.");
              return;
            }
            
            const { data: activeGameGroup } = await supabaseClient
                .from('user_groups').select('game_id').eq('user_id', currentUser.id).eq('is_active', true).single();
                
            if (activeGameGroup) {
                const { data: game } = await supabaseClient.rpc('get_game_details', { game_id_input: activeGameGroup.game_id }).single();
                if(game) {
                    if (game.game_id && !game.id) game.id = game.game_id;
                    selectGame(game);
                }
            }
            
            setupPlayerLocator();
            fetchAndDisplayGames();
            setInterval(fetchAndDisplayGames, 30000);
        });
    }

    async function main() {
        firebase.initializeApp(firebaseConfig);
        db = firebase.firestore();

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const userCenter = [position.coords.longitude, position.coords.latitude];
                    initializeAppWithLocation(userCenter);
                },
                (error) => {
                    console.error("Geolocation error, using default location.", error);
                    const defaultCenter = [-73.78, 41.03];
                    initializeAppWithLocation(defaultCenter);
                }
            );
        } else {
            console.log("Geolocation not supported, using default location.");
            const defaultCenter = [-73.78, 41.03];
            initializeAppWithLocation(defaultCenter);
        }
    }

    document.addEventListener('DOMContentLoaded', main);
    digButton.addEventListener('click', digForTreasure);
    chatForm.addEventListener('submit', handleSendMessage);
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js"></script>
<script src="https://npmcdn.com/@turf/turf/turf.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="session.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-auth-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.15.0/firebase-firestore-compat.js"></script>
<script>
    let map, currentUser, playerLocation, selectedGame = null, userMarker = null, db;
    let gameMarkers = {};
    let unsubscribeFromChat = null;

    const digButton = document.getElementById('digButton');
    const distanceInfo = document.getElementById('distance-info');
    const gameTitleEl = document.getElementById('gameTitle');
    const chatBox = document.getElementById('chatBox');
    const chatMessagesEl = document.getElementById('chatMessages');
    const chatForm = document.getElementById('chatForm');
    const chatTextInput = document.getElementById('chatText');
    
    const firebaseConfig = {
        apiKey: "AIzaSyCQ7lGF8CRYOZC8m94vqNSbuFFKQAhKeTE",
        authDomain: "pilolo-chat-7c443.firebaseapp.com",
        projectId: "pilolo-chat-7c443",
        storageBucket: "pilolo-chat-7c443.appspot.com",
        messagingSenderId: "328898324550",
        appId: "1:328898324550:web:d1e8f4b6869c9920ff4247"
    };

    async function handleGameInteraction(gameId) {
      if (!currentUser) return Swal.fire('Error', 'You must be logged in.', 'error');
      if (selectedGame && selectedGame.id === gameId) return Swal.fire('Info', 'You are already in this game.', 'info');
      if (!playerLocation) return Swal.fire('Location Error', 'Could not get your current location.', 'warning');

      const { data: response, error } = await supabaseClient.rpc('join_game', {
        user_id_input: currentUser.id,
        game_id_input: gameId,
        player_lon: playerLocation[0],
        player_lat: playerLocation[1]
      });

      if (error || (response && response.startsWith('Error:'))) {
        const errorMessage = response ? response.replace('Error: ', '') : error.message;
        return Swal.fire('Could Not Join', errorMessage, 'warning');
      }
      
      const { data: game, error: gameError } = await supabaseClient.rpc('get_game_details', { game_id_input: gameId }).single();
      if (gameError || !game) {
        return Swal.fire('Error', 'Could not load game details after joining.', 'error');
      }

      if (game.game_id && !game.id) game.id = game.game_id;

      if (game.status === 'in_progress') {
        const { error: playError } = await supabaseClient.rpc('play_game_if_live', { user_id_input: currentUser.id, game_id_input: gameId });
        if (playError) {
          return Swal.fire('Join OK, but...', 'Failed to mark you as playing. Try again.', 'warning');
        }
        Swal.fire('Let’s Go!', 'Game is live — you can dig now!', 'success');
      } else {
        Swal.fire('Joined!', 'You have successfully joined the game. It will start soon.', 'success');
      }
      selectGame(game);
    }
    
    async function exitGame(isGameOver = false) {
        if (!currentUser || !selectedGame) return;
        const gameId = selectedGame.id;
        
        await supabaseClient.from('user_groups').update({ status: 'exited', is_active: false }).eq('user_id', currentUser.id).eq('game_id', gameId);
        
        const originalGameData = gameMarkers[gameId]?.gameData;
        selectedGame = null;
        gameTitleEl.textContent = 'Explore Games';

        if (typeof unsubscribeFromChat === 'function') {
            unsubscribeFromChat();
            unsubscribeFromChat = null;
        }

        chatMessagesEl.innerHTML = '<div>No game selected.</div>';
        
        if(!isGameOver) Swal.fire('Exited', 'You have left the game.', 'info');
        if (originalGameData) updateGameMarkerPopup(gameId, originalGameData);
        checkProximity();
    }
    
    function updateGameMarkerPopup(gameId, gameData) {
        const marker = gameMarkers[gameId];
        if (!marker || !gameData) return;

        let timeInfoHTML = '';
        if (gameData.status === 'pending') {
            timeInfoHTML = `<p class="time-info">Starts at: ${new Date(gameData.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>`;
        } else if (gameData.status === 'in_progress') {
            timeInfoHTML = `<p class="time-info">Live! Ends at: ${new Date(gameData.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>`;
        }
        
        const definitiveGameId = gameData.id || gameData.game_id;
        let buttonHTML = `<button onclick="handleGameInteraction('${definitiveGameId}')">Join Game</button>`;

        if (selectedGame?.id === gameId) {
             buttonHTML = `<div class="button-group"><button class="chat-btn" onclick="openChatForGame()">Chat</button><button class="exit-btn" onclick="exitGame()">Exit</button></div>`;
        }

        const popupContent = `<div class="game-popup"><h3>${gameData.title}</h3><p>Prize: $${gameData.total_value} | Treasures: ${gameData.treasure_count}</p><p class="game-creator">by ${gameData.creator_username}</p>${timeInfoHTML}${buttonHTML}</div>`;
        const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(popupContent);
        marker.setPopup(popup);
    }
    
    function openChatForGame() {
        if (!selectedGame) return;
        subscribeToChat();
        toggleChat();
    }

    function selectGame(game) {
      selectedGame = game;
      gameTitleEl.textContent = `Playing: ${game.title}`;
      updateGameMarkerPopup(game.id, game);
      subscribeToChat();
      checkProximity();
    }
    
    async function digForTreasure() {
        if (!currentUser || !playerLocation) return;
        if (!selectedGame) return Swal.fire('Cannot Dig', 'You must be playing a game to dig.', 'info');

        try {
            const { data: result, error } = await supabaseClient.rpc('dig_for_treasure', {
                user_id_input: currentUser.id, game_id_input: selectedGame.id,
                player_lon: playerLocation[0], player_lat: playerLocation[1]
            });

            if (error) return Swal.fire('Error', error.message || 'An error occurred.', 'error');
            
            const valueMatch = result.match(/\$?([\d.]+)/);
            const value = valueMatch ? valueMatch[1] : '?';
            
            if (result.startsWith("Success")) {
                handleSendMessage(`dug and found a treasure worth $${value}! 🎉`);
                Swal.fire("Congratulations!", result, "success");
            } else if (result.startsWith("You have reached your dig limit")) {
                Swal.fire("Dig Limit Reached", result, "info");
            } else {
                handleSendMessage("dug but found nothing.");
                Swal.fire("Keep Trying!", result, "warning");
            }
        } catch (err) {
            Swal.fire("Error", "An unexpected error occurred while digging.", "error");
        }
    }

    function checkProximity() {
        if (!playerLocation || !selectedGame?.location?.coordinates) {
            digButton.classList.remove('enabled');
            distanceInfo.style.display = 'none';
            return;
        }
        
        const gameCenterCoords = selectedGame.location.coordinates;
        const distanceToGameCenter = turf.distance(turf.point(playerLocation), turf.point(gameCenterCoords), { units: 'meters' });
        const isInsideGameRadius = distanceToGameCenter <= 30.5;
        digButton.classList.toggle('enabled', isInsideGameRadius);

        if (!isInsideGameRadius) {
            const distanceInFeet = Math.round(distanceToGameCenter * 3.28);
            distanceInfo.textContent = `${distanceInFeet} feet from game area`;
            distanceInfo.style.display = 'block';
        } else {
            distanceInfo.style.display = 'none';
        }
    }

    function setupPlayerLocator() {
        if (!navigator.geolocation) return Swal.fire('Geolocation Not Supported', 'Your browser does not support this feature.', 'error');
        
        map.addControl(new mapboxgl.GeolocateControl({
            positionOptions: { enableHighAccuracy: true },
            trackUserLocation: true,
            showUserHeading: true
        }));

        navigator.geolocation.watchPosition(
            (position) => {
                playerLocation = [position.coords.longitude, position.coords.latitude];
                if (!userMarker) {
                    const el = document.createElement('div');
                    el.style.cssText = `background: #00ffcc; border: 2px solid white; width: 14px; height: 14px; border-radius: 50%; box-shadow: 0 0 10px #00ffff;`;
                    userMarker = new mapboxgl.Marker(el).setLngLat(playerLocation).addTo(map);
                } else {
                    userMarker.setLngLat(playerLocation);
                }
                checkProximity();
            },
            (error) => console.error(`Geolocation Error (Code ${error.code}): ${error.message}`),
            { enableHighAccuracy: true, maximumAge: 3000, timeout: 27000 }
        );
    }
    
    function toggleChat() {
      if (!selectedGame) return Swal.fire('Info', "You must be playing a game to chat.", 'info');
      chatBox.style.display = chatBox.style.display === 'flex' ? 'none' : 'flex';
    }

    async function fetchAndDisplayGames() {
      const { data: games, error } = await supabaseClient.rpc('get_all_active_games_with_details');
      if (error) return console.error("Error fetching games:", error);
      
      const activeGameIds = new Set(games ? games.map(g => g.game_id || g.id) : []);

      if (selectedGame && !activeGameIds.has(selectedGame.id)) {
          Swal.fire('Game Over', `The game '${selectedGame.title}' has ended.`, 'info');
          exitGame(true);
          return;
      }

      Object.keys(gameMarkers).forEach(id => {
          if (!activeGameIds.has(Number(id))) {
              if (gameMarkers[id]) gameMarkers[id].remove();
              delete gameMarkers[id];
          }
      });
      
      if (!games) return;

      games.forEach(game => {
          if (game.game_id && !game.id) game.id = game.game_id;
          const gameId = game.id;
          if (!game.location?.coordinates) return;

          if (gameMarkers[gameId]) {
            gameMarkers[gameId].gameData = game;
            updateGameMarkerPopup(gameId, game);
          } else {
            const markerEl = document.createElement('div');
            markerEl.style.cssText = 'background-color: #ffc107; width: 18px; height: 18px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 8px rgba(0,0,0,0.6); cursor: pointer;';
            const marker = new mapboxgl.Marker(markerEl).setLngLat(game.location.coordinates).addTo(map);
            marker.gameData = game;
            gameMarkers[gameId] = marker;
            updateGameMarkerPopup(gameId, game);
          }
      });
    }
    
    async function handleSendMessage(e) {
      if (e && typeof e.preventDefault === 'function') e.preventDefault();
      
      const msg = (typeof e === 'string') ? e : chatTextInput.value.trim();
      if (!msg || !selectedGame || !currentUser) return;

      try {
        await db.collection('chats').doc(String(selectedGame.id)).collection('messages').add({
            text: msg,
            userId: currentUser.id,
            username: currentUser.email.split('@')[0],
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        if (typeof e !== 'string') chatTextInput.value = '';
      } catch (err) {
        console.error("Error sending message to Firestore:", err);
        Swal.fire("Chat Error", "Could not send message. Please check your connection or security rules.", "error");
      }
    }

    function displayNewMessage(message) {
      const username = message.username || 'A User';
      const timestamp = message.createdAt ? message.createdAt.toDate().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit'}) : '';
      const div = document.createElement('div');
      div.innerHTML = `<b>${username}</b>: ${message.text} <span class="chat-timestamp">${timestamp}</span>`;
      chatMessagesEl.appendChild(div);
      chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
    }

    function subscribeToChat() {
      if (typeof unsubscribeFromChat === 'function') unsubscribeFromChat();

      if (!selectedGame) {
        chatMessagesEl.innerHTML = '<div>No game selected.</div>';
        return;
      }
      chatMessagesEl.innerHTML = `<div><b>Joined chat for ${selectedGame.title}</b></div>`;
      
      const messagesQuery = db.collection('chats').doc(String(selectedGame.id)).collection('messages').orderBy('createdAt', 'asc');
      
      unsubscribeFromChat = messagesQuery.onSnapshot(querySnapshot => {
        querySnapshot.docChanges().forEach(change => {
          if (change.type === 'added') displayNewMessage(change.doc.data());
        });
      }, err => {
        console.error("Chat subscription error:", err);
      });
    }

    async function initializeAppWithLocation(center) {
        mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
        map = new mapboxgl.Map({
            container: 'map',
            style: 'mapbox://styles/mapbox/navigation-night-v1?optimized=true',
            center: center,
            zoom: 10
        });

        map.on('load', async () => {
            // Remove loader when map is ready
            const loader = document.getElementById('loader-wrapper');
            if (loader) {
                loader.style.opacity = '0';
                setTimeout(() => { loader.style.display = 'none'; }, 500);
            }
       
            currentUser = await verifySession();
            if (!currentUser) {
              console.error("Could not verify user session. App cannot start.");
              return;
            }
            
            const { data: activeGameGroup } = await supabaseClient
                .from('user_groups').select('game_id').eq('user_id', currentUser.id).eq('is_active', true).single();
                
            if (activeGameGroup) {
                const { data: game } = await supabaseClient.rpc('get_game_details', { game_id_input: activeGameGroup.game_id }).single();
                if(game) {
                    if (game.game_id && !game.id) game.id = game.game_id;
                    selectGame(game);
                }
            }
            
            setupPlayerLocator();
            fetchAndDisplayGames();
            setInterval(fetchAndDisplayGames, 30000);
        });
    }

    async function main() {
        firebase.initializeApp(firebaseConfig);
        db = firebase.firestore();

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const userCenter = [position.coords.longitude, position.coords.latitude];
                    initializeAppWithLocation(userCenter);
                },
                (error) => {
                    console.error("Geolocation error, using default location.", error);
                    const defaultCenter = [-73.78, 41.03];
                    initializeAppWithLocation(defaultCenter);
                }
            );
        } else {
            console.log("Geolocation not supported, using default location.");
            const defaultCenter = [-73.78, 41.03];
            initializeAppWithLocation(defaultCenter);
        }
    }

    document.addEventListener('DOMContentLoaded', main);
    digButton.addEventListener('click', digForTreasure);
    chatForm.addEventListener('submit', handleSendMessage);
  </script>