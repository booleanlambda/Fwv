<style>
    body {
      font-family: sans-serif;
      margin: 0;
      padding: 20px;
      background: #f5f5f5;
    }
    header {
      font-size: 24px;
      font-weight: bold;
      margin-bottom: 20px;
    }
    .section {
      background: white;
      border-radius: 12px;
      padding: 16px;
      margin-bottom: 16px;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
    }
    .label {
      font-weight: bold;
      margin-top: 10px;
    }
    ul {
      padding-left: 18px;
    }
  </style>
<body>
<header>Game Activities</header>
<div class="section">
<div><span class="label">Game Name:</span> Jungle Dash</div>
<div><span class="label">Created On:</span> 2025-07-08</div>
<div><span class="label">Location:</span> Accra, Ghana</div>
<div><span class="label">Initial Treasure Count:</span> 5</div>
<div><span class="label">Game Started On:</span> 2025-07-09 10:00 AM</div>
</div>
<div class="section">
<div class="label">Players:</div>
<ul>
<li>Kofi Mensah</li>
<li>Sarah Owusu</li>
<li>James Adjei</li>
</ul>
</div>
<div class="section">
<div class="label">Winners:</div>
<ul>
<li>Kofi Mensah - 2 treasures</li>
<li>Sarah Owusu - 1 treasure</li>
</ul>
</div>
<div class="section">
<div class="label">Treasures Found:</div>
<ul>
<li>Kofi Mensah — [x: 5.6037, y: -0.1870] — July 9, 2025, 10:32 AM</li>
<li>Sarah Owusu — [x: 5.6040, y: -0.1885] — July 9, 2025, 10:45 AM</li>
</ul>
</div>
</body>
<script src="verifysession.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js"></script>
<script src="verifysession.js"></script>