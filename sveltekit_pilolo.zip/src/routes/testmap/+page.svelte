<style>
        body { margin: 0; padding: 0; font-family: sans-serif; }
        #map { position: absolute; top: 0; bottom: 0; width: 100%; }
        
        /* Custom style for the yellow treasure markers */
        .treasure-marker {
            background-color: #ffc107; /* Yellow */
            width: 16px;
            height: 16px;
            border-radius: 50%;
            border: 2px solid white;
            box-shadow: 0 0 8px rgba(0, 0, 0, 0.5);
        }
    </style>
<body>
<div id="map"></div>
<script>
    // Your Mapbox access token
    mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';

    // Coordinates for the treasures from your database
    const treasureCoordinates = [
        { description: 'Hidden Treasure #5', latitude: 40.9740504930646, longitude: -73.7212571925378 },
        { description: 'Hidden Treasure #6', latitude: 40.9739470706319, longitude: -73.7211523552086 },
        { description: 'Hidden Treasure #7', latitude: 40.9741379873453, longitude: -73.7212316395479 },
        { description: 'Hidden Treasure #8', latitude: 40.9739604240979, longitude: -73.7211544187651 },
        { description: 'Hidden Treasure #9', latitude: 40.9739317657636, longitude: -73.7212172333478 },
        { description: 'Hidden Treasure #10', latitude: 40.9738585456899, longitude: -73.7212858875271 }
    ];

    // Initialize the map
    const map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/dark-v11', // Dark theme
        center: [-73.7212, 40.9740], // Centered on the treasure cluster
        zoom: 16
    });

    let userLocationMarker = null;

    // Wait for the map to finish loading
    map.on('load', () => {

        // Add the yellow circle markers for each treasure
        treasureCoordinates.forEach(treasure => {
            const el = document.createElement('div');
            el.className = 'treasure-marker';

            new mapboxgl.Marker(el)
                .setLngLat([treasure.longitude, treasure.latitude])
                .addTo(map);
        });

        // Check if the browser supports Geolocation
        if (navigator.geolocation) {
            // Use watchPosition to get continuous location updates
            navigator.geolocation.watchPosition(
                (position) => {
                    const userLngLat = [position.coords.longitude, position.coords.latitude];

                    // If the user marker doesn't exist, create it
                    if (!userLocationMarker) {
                        userLocationMarker = new mapboxgl.Marker({ color: '#00FFFF' }) // Cyan color for user
                            .setLngLat(userLngLat)
                            .addTo(map);
                        // Center the map on the user's location the first time
                        map.panTo(userLngLat);
                    } else {
                        // If the marker already exists, just update its position
                        userLocationMarker.setLngLat(userLngLat);
                    }
                },
                (error) => {
                    console.error("Error getting geolocation: ", error);
                    alert("Could not get your location. Please enable location services in your browser settings.");
                },
                {
                    enableHighAccuracy: true, // Use GPS if available
                    timeout: 5000,
                    maximumAge: 0
                }
            );
        } else {
            alert("Geolocation is not supported by your browser.");
        }
    });

</script>
</body>
<script src="https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js"></script>
<script>
    // Your Mapbox access token
    mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';

    // Coordinates for the treasures from your database
    const treasureCoordinates = [
        { description: 'Hidden Treasure #5', latitude: 40.9740504930646, longitude: -73.7212571925378 },
        { description: 'Hidden Treasure #6', latitude: 40.9739470706319, longitude: -73.7211523552086 },
        { description: 'Hidden Treasure #7', latitude: 40.9741379873453, longitude: -73.7212316395479 },
        { description: 'Hidden Treasure #8', latitude: 40.9739604240979, longitude: -73.7211544187651 },
        { description: 'Hidden Treasure #9', latitude: 40.9739317657636, longitude: -73.7212172333478 },
        { description: 'Hidden Treasure #10', latitude: 40.9738585456899, longitude: -73.7212858875271 }
    ];

    // Initialize the map
    const map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/dark-v11', // Dark theme
        center: [-73.7212, 40.9740], // Centered on the treasure cluster
        zoom: 16
    });

    let userLocationMarker = null;

    // Wait for the map to finish loading
    map.on('load', () => {

        // Add the yellow circle markers for each treasure
        treasureCoordinates.forEach(treasure => {
            const el = document.createElement('div');
            el.className = 'treasure-marker';

            new mapboxgl.Marker(el)
                .setLngLat([treasure.longitude, treasure.latitude])
                .addTo(map);
        });

        // Check if the browser supports Geolocation
        if (navigator.geolocation) {
            // Use watchPosition to get continuous location updates
            navigator.geolocation.watchPosition(
                (position) => {
                    const userLngLat = [position.coords.longitude, position.coords.latitude];

                    // If the user marker doesn't exist, create it
                    if (!userLocationMarker) {
                        userLocationMarker = new mapboxgl.Marker({ color: '#00FFFF' }) // Cyan color for user
                            .setLngLat(userLngLat)
                            .addTo(map);
                        // Center the map on the user's location the first time
                        map.panTo(userLngLat);
                    } else {
                        // If the marker already exists, just update its position
                        userLocationMarker.setLngLat(userLngLat);
                    }
                },
                (error) => {
                    console.error("Error getting geolocation: ", error);
                    alert("Could not get your location. Please enable location services in your browser settings.");
                },
                {
                    enableHighAccuracy: true, // Use GPS if available
                    timeout: 5000,
                    maximumAge: 0
                }
            );
        } else {
            alert("Geolocation is not supported by your browser.");
        }
    });

</script>