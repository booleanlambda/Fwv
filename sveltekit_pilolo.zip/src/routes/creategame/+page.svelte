<style>
    :root {
      --primary-accent: #667eea;
      --text-light: #f0f0f0;
      --text-muted: #999;
      --panel-bg: rgba(25, 25, 30, 0.92);
      --success-color: #28a745;
      --danger-color: #dc3545;
      --warning-color: #ffc107;
      --info-color: #17a2b8;
      --disabled-color: #555;
      --modal-bg: linear-gradient(145deg, #4349a5, #757be0);
    }

    html, body {
      margin: 0; height: 100%; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      background: #111; color: var(--text-light); overflow: hidden;
    }
    #map { position: absolute; top: 0; bottom: 0; width: 100%; }
    
    header {
      position: fixed; top: 0; left: 0; right: 0;
      display: flex; justify-content: space-between; align-items: center;
      padding: 12px 20px; background: rgba(0, 0, 0, 0.3); backdrop-filter: blur(5px);
      border-bottom: 1px solid rgba(255,255,255,0.1); z-index: 20;
    }
    .header-link {
      color: #fff; text-decoration: none; font-weight: bold; font-size: 16px;
      background: rgba(255,255,255,0.1); padding: 8px 14px; border-radius: 8px; transition: background 0.2s;
    }
    .header-link:hover { background: rgba(255,255,255,0.2); }
    .header-info { display: flex; gap: 12px; font-size: 14px; align-items: center; }

    #formPanelWrapper {
      position: absolute; bottom: 0; left: 0; right: 0;
      background: var(--panel-bg); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
      border-top: 1px solid rgba(255,255,255,0.2);
      max-height: 90px;
      overflow: hidden; transition: max-height 0.4s ease-in-out; z-index: 10;
      box-shadow: 0 -5px 25px rgba(0,0,0,0.3);
    }
    #formPanelWrapper.expanded { max-height: 85vh; overflow-y: auto; }
    
    #panelHeader { display: flex; justify-content: space-between; align-items: flex-start; padding: 15px 20px; cursor: pointer; }
    #locationInfo p { margin: 4px 0 0; font-size: 14px; color: var(--text-muted); max-width: 200px; }
    #gamesInfo { text-align: right; flex-shrink: 0; }
    #gamesInfo a { display: block; margin-top: 4px; font-size: 14px; color: var(--primary-accent); text-decoration: none; }
    #expandIcon { transition: transform 0.4s ease-in-out; }
    #formPanelWrapper.expanded #expandIcon { transform: rotate(180deg); }

    #formFields { padding: 0 20px 20px; }
    label { display: block; margin-top: 15px; margin-bottom: 5px; font-size: 14px; color: var(--text-muted); }
    input {
      padding: 12px; width: 100%; box-sizing: border-box; font-size: 16px; border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.1); color: white;
      transition: border-color 0.3s;
    }
    input::placeholder { color: #888; }
    button {
      padding: 14px; width: 100%; box-sizing: border-box; font-size: 16px; border-radius: 8px;
      cursor: pointer; margin-top: 20px; border: none; font-weight: bold; transition: background-color 0.2s, opacity 0.2s;
    }
    
    .form-actions { display: flex; gap: 10px; margin-top: 20px; }
    .form-actions button { width: 100%; margin-top: 0; }
    #createBtn { background: var(--success-color); }
    #createBtn:disabled { background: var(--disabled-color); color: #999; cursor: not-allowed; opacity: 0.7; }
    #cancelBtn { background: var(--danger-color); }
    
    /* NEW: Wallet Button Style */
    #walletBtn { background: var(--info-color); margin-top: 10px; }

    .status-message { font-size: 13px; font-weight: bold; margin-top: 8px; height: 16px; }
    .status-message.loading { color: var(--warning-color); }
    .status-message.invalid { color: var(--danger-color); }
    .status-message.valid { color: var(--success-color); }

    .mapboxgl-popup-content {
      background: rgba(0, 0, 0, 0.8) !important; color: white !important; 
      border-radius: 8px !important; padding: 8px 12px !important;
    }
    .mapboxgl-popup-anchor-bottom .mapboxgl-popup-tip { border-top-color: rgba(0, 0, 0, 0.8) !important; }
    .fixed-bubble { text-align: center; max-width: 200px; }
    .fixed-bubble strong { font-size: 14px; color: var(--warning-color); display: block; }
    .fixed-bubble p { margin: 4px 0 0; line-height: 1.4; color: #ddd; font-size: 12px; }
    
    .modal-overlay {
        display: none; position: fixed; inset: 0;
        background: rgba(0, 0, 0, 0.7);
        justify-content: center; align-items: center; z-index: 1000;
        backdrop-filter: blur(5px);
    }
    .modal {
        background: var(--modal-bg); padding: 25px; border-radius: 16px;
        width: 90%; max-width: 400px; box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    }
    .modal h2 { margin-top: 0; }
    .modal-buttons { display: flex; gap: 10px; margin-top: 20px; }
    .modal-buttons button { margin-top: 0; }
    .modal-buttons button:first-child { background: #6c757d; }
    .modal-buttons button:last-child { background: var(--success-color); }
    .input-group input { margin-top: 8px; }
    .input-group label { text-align: left; }
  </style>
<body>
<div id="map"></div>
<header>
<a class="header-link" href="map.html">← Back to Map</a>
<div class="header-info">
<span id="headerUsername"></span><span>|</span><span id="headerWallet">Wallet: $0.00</span>
</div>
</header>
<div id="formPanelWrapper">
<div id="panelHeader">
<div id="locationInfo">
<label>Selected Location</label>
<p id="locText">Click map to select a starting point</p>
</div>
<div id="gamesInfo">
<span id="gameCount">Your Active Games: 0</span>
<a href="creatorsactivities.html">Manage Games</a>
</div>
<div id="expandIcon">
<svg fill="white" height="24" viewbox="0 0 24 24" width="24"><path d="M12 8L6 14L7.41 15.41L12 10.83L16.59 15.41L18 14L12 8Z"></path></svg>
</div>
</div>
<div id="formFields">
<label for="gameTitle">Game Title</label>
<input id="gameTitle" placeholder="e.g., Central Park Hunt" type="text"/>
<label for="startDateTime">Start Date &amp; Time (Top of the hour)</label>
<input id="startDateTime" step="3600" type="datetime-local"/>
<div class="status-message" id="slotStatus">Select a location and time</div>
<label for="treasures">Number of Treasures</label>
<input id="treasures" min="1" placeholder="e.g., 10" type="number"/>
<label for="value">Total Prize Value ($)</label>
<input id="value" min="1" placeholder="e.g., 50" type="number"/>
<button id="walletBtn" type="button">Manage Wallet</button>
<div class="form-actions">
<button id="cancelBtn" type="button">Cancel</button>
<button disabled="" id="createBtn">Create Game</button>
</div>
</div>
</div>
<div class="modal-overlay" id="paymentModalOverlay">
<div class="modal">
<h2>Payment Settings</h2>
<form id="paymentForm">
<div>
<label><input checked="" name="paymentMethod" type="radio" value="paypal"/> PayPal</label>
<label><input name="paymentMethod" type="radio" value="mobile"/> Mobile Money</label>
</div>
<div class="input-group" id="paypalInputGroup">
<label>PayPal Email</label>
<input id="paypalEmail" placeholder="email@example.com" type="email"/>
<input id="paypalEmailConfirm" placeholder="Confirm email" type="email"/>
</div>
<div class="input-group" id="mobileInputGroup" style="display:none;">
<label>Mobile Number</label>
<input id="mobileNumber" placeholder="+1234567890" type="tel"/>
<input id="mobileNumberConfirm" placeholder="Confirm number" type="tel"/>
</div>
<div class="modal-buttons">
<button onclick="closeModal('paymentModalOverlay')" type="button">Cancel</button>
<button type="submit">Save</button>
</div>
</form>
</div>
</div>
<div class="modal-overlay" id="transactionModalOverlay">
<div class="modal">
<h2 id="transactionTitle">Amount</h2>
<div class="input-group">
<label for="amountInput">Amount ($)</label>
<input id="amountInput" min="1.00" placeholder="e.g., 20.00" step="0.01" type="number"/>
</div>
<div class="modal-buttons">
<button onclick="closeModal('transactionModalOverlay')" type="button">Cancel</button>
<button onclick="processTransaction()" type="button">Confirm</button>
</div>
</div>
</div>
<script>
    // const SUPABASE_URL = '...';
    // const SUPABASE_ANON_KEY = '...';
    // const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    let map, selectedCoords, mapMarker, gameMarkers = {};
    let currentWalletData = null, currentUserId = null, currentAction = null;
    
    function setDateTimeConstraints() {
      const input = document.getElementById('startDateTime');
      const minDate = new Date();
      minDate.setHours(minDate.getHours() + 1, 0, 0, 0); 
      const maxDate = new Date();
      maxDate.setDate(maxDate.getDate() + 14);
      const toLocalISOString = (date) => `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}T${date.getHours().toString().padStart(2, '0')}:00`;
      input.min = toLocalISOString(minDate);
      input.max = toLocalISOString(maxDate);
      input.value = toLocalISOString(minDate);
    }
    
    function resetForm() {
      document.getElementById('formPanelWrapper').classList.remove('expanded');
      if (mapMarker) {
        mapMarker.remove();
        mapMarker = null;
      }
      selectedCoords = null;
      document.getElementById('gameTitle').value = '';
      document.getElementById('treasures').value = '';
      document.getElementById('value').value = '';
      document.getElementById('locText').textContent = 'Click map to select a starting point';
      document.getElementById('slotStatus').textContent = 'Select a location and time';
      document.getElementById('slotStatus').className = 'status-message';
      document.getElementById('startDateTime').classList.remove('valid-slot', 'invalid-slot');
      document.getElementById('createBtn').disabled = true;
      setDateTimeConstraints();
    }

    async function updateWalletUI(userId) {
      const { data, error } = await supabaseClient.from('users').select('wallet, payment_type, paypal_username, mobile_number').eq('id', userId).single();
      if (error) { console.error('Error fetching wallet:', error); return; }
      if (data) {
        currentWalletData = data;
        document.getElementById('headerWallet').textContent = `Wallet: $${(data.wallet || 0).toFixed(2)}`;
      }
    }
    
    async function fetchUserGameCount(userId) {
        const { count, error } = await supabaseClient
            .from('games')
            .select('*', { count: 'exact', head: true })
            .eq('creator_id', userId)
            .in('status', ['pending', 'in_progress']);
        if (error) { console.error('Error fetching user game count:', error); return; }
        document.getElementById('gameCount').textContent = `Your Active Games: ${count || 0}`;
    }

    async function fetchAndDisplayGames() {
      const { data: games, error } = await supabaseClient.rpc('get_all_active_games_with_details');
      if (error) { console.error("Error fetching all games:", error); return; }

      const activeGameIds = new Set(games ? games.map(g => g.game_id) : []);

      for (const gameId in gameMarkers) {
          if (!activeGameIds.has(gameId)) {
              gameMarkers[gameId].marker.remove();
              gameMarkers[gameId].popup.remove();
              delete gameMarkers[gameId];
          }
      }
      
      if (!games) return;

      games.forEach(game => {
          if (gameMarkers[game.game_id] || !game.location?.coordinates) return;
          const markerEl = document.createElement('div');
          markerEl.style.cssText = 'background-color: #ffc107; width: 12px; height: 12px; border-radius: 50%; border: 2px solid #333;';
          const marker = new mapboxgl.Marker(markerEl).setLngLat(game.location.coordinates).addTo(map);
          const timeInfoHTML = game.status === 'pending'
              ? `Starts: ${new Date(game.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
              : `Live! Ends: ${new Date(game.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
          const popupContent = `<div class="fixed-bubble"><strong>${game.title}</strong><p>$${game.total_value} Prize | by ${game.creator_username}</p><p>${timeInfoHTML}</p></div>`;
          const popup = new mapboxgl.Popup({ closeButton: false, closeOnClick: false, anchor: 'bottom', offset: 25 }).setLngLat(game.location.coordinates).setHTML(popupContent).addTo(map);
          gameMarkers[game.game_id] = { marker, popup };
      });
    }

    async function validateSlot() {
        const timeValue = document.getElementById('startDateTime').value;
        if (!selectedCoords || !timeValue) return;
        const statusEl = document.getElementById('slotStatus'), inputEl = document.getElementById('startDateTime'), createBtn = document.getElementById('createBtn');
        statusEl.textContent = 'Checking availability...'; statusEl.className = 'status-message loading';
        inputEl.classList.remove('valid-slot', 'invalid-slot'); createBtn.disabled = true;

        const { data: result, error } = await supabaseClient.rpc('check_geo_slot', {
            start_time_input: new Date(timeValue).toISOString(),
            location_input: `POINT(${selectedCoords.lng} ${selectedCoords.lat})`
        });

        if (error) {
            statusEl.textContent = 'Error checking slot.'; statusEl.className = 'status-message invalid';
        } else if (result === 'OK') {
            statusEl.textContent = 'Slot is available!'; statusEl.className = 'status-message valid';
            inputEl.classList.add('valid-slot'); createBtn.disabled = false;
        } else {
            statusEl.textContent = result; statusEl.className = 'status-message invalid';
            inputEl.classList.add('invalid-slot');
        }
    }

    async function createGame(user) {
        const title = document.getElementById('gameTitle').value.trim();
        const startTime = document.getElementById('startDateTime').value;
        const treasureCount = parseInt(document.getElementById('treasures').value, 10);
        const totalValue = parseFloat(document.getElementById('value').value);
        
        if (!title || !startTime || !treasureCount || isNaN(totalValue) || !selectedCoords) {
            return Swal.fire("Validation Error", "Please complete all fields and select a location.", "warning");
        }
        if (currentWalletData.wallet < totalValue) {
            return Swal.fire("Insufficient Funds", "The total prize value cannot exceed your wallet balance.", "error");
        }
        
        document.getElementById('createBtn').disabled = true; document.getElementById('createBtn').textContent = 'Creating...';
        
        // FIX: Correctly subtract the game cost from the wallet
        const newWalletBalance = currentWalletData.wallet - totalValue;
        const { error: walletError } = await supabaseClient.from('users').update({ wallet: newWalletBalance }).eq('id', user.id);
        if (walletError) {
            document.getElementById('createBtn').disabled = false; document.getElementById('createBtn').textContent = 'Create Game';
            return Swal.fire("Payment Failed", "Could not deduct funds from wallet.", "error");
        }

        const { error: gameError } = await supabaseClient.rpc('create_game_with_slot_check', {
            creator_id_input: user.id, title_input: title, start_time_input: new Date(startTime).toISOString(),
            treasure_count_input: treasureCount, total_value_input: totalValue,
            latitude_input: selectedCoords.lat, longitude_input: selectedCoords.lng
        });

        if (gameError) { 
            // Refund the user if game creation fails after payment
            await supabaseClient.from('users').update({ wallet: currentWalletData.wallet }).eq('id', user.id);
            document.getElementById('createBtn').disabled = false; document.getElementById('createBtn').textContent = 'Create Game';
            return Swal.fire("Game Creation Failed", gameError.message, "error"); 
        }

        await Swal.fire("Game Created!", "Your game is scheduled.", "success");
        await updateWalletUI(user.id);
        await fetchUserGameCount(user.id);
        await fetchAndDisplayGames();
        resetForm();
        document.getElementById('createBtn').textContent = 'Create Game';
    }

    function openTransactionModal(action) {
      currentAction = action;
      document.getElementById("transactionTitle").innerText = action === 'add' ? 'Add Funds' : 'Withdraw Funds';
      document.getElementById("amountInput").value = '';
      document.getElementById("transactionModalOverlay").style.display = 'flex';
    }

    async function processTransaction() {
      const amount = parseFloat(document.getElementById("amountInput").value);
      if (isNaN(amount) || amount <= 0) return Swal.fire("Error", "Please enter a valid amount.", "error");
      
      const currentBalance = currentWalletData?.wallet ?? 0;
      const newBalance = currentAction === 'add' ? currentBalance + amount : currentBalance - amount;

      if (currentAction === 'withdraw') {
        if (amount > currentBalance) return Swal.fire("Error", "Insufficient funds.", "error");
        if (!currentWalletData.payment_type) return Swal.fire("Error", "Please set a payment method in Settings first.", "error");
        Swal.fire("Processing", "Withdrawal is being processed.", "info");
      }

      const { error } = await supabaseClient.from('users').update({ wallet: newBalance }).eq('id', currentUserId);
      if (error) return Swal.fire("Error", "Transaction failed: " + error.message, "error");

      Swal.fire("Success", "Your wallet has been updated!", "success");
      closeModal('transactionModalOverlay');
      updateWalletUI(currentUserId);
    }
    
    function openPaymentModal() {
      const type = currentWalletData?.payment_type || 'paypal';
      document.querySelector(`[name="paymentMethod"][value=${type}]`).checked = true;
      togglePaymentInput(type);
      document.getElementById('paypalEmail').value = currentWalletData?.paypal_username || '';
      document.getElementById('mobileNumber').value = currentWalletData?.mobile_number || '';
      document.getElementById('paypalEmailConfirm').value = '';
      document.getElementById('mobileNumberConfirm').value = '';
      document.getElementById("paymentModalOverlay").style.display = 'flex';
    }
    
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }
    function togglePaymentInput(method) {
      document.getElementById('paypalInputGroup').style.display = method === 'paypal' ? 'block' : 'none';
      document.getElementById('mobileInputGroup').style.display = method === 'mobile' ? 'block' : 'none';
    }

    document.addEventListener('DOMContentLoaded', async () => {
      const user = await verifySession(); 
      if (!user) return; 
      currentUserId = user.id;
      
      const { data: userData } = await supabaseClient.from('users').select('username').eq('id', currentUserId).single();
      if (userData) document.getElementById('headerUsername').textContent = userData.username;

      mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
      map = new mapboxgl.Map({ container: 'map', style: 'mapbox://styles/mapbox/dark-v11', center: [-73.78, 41.03], zoom: 11 });

      map.on('load', async () => {
          map.resize();
          await fetchAndDisplayGames();
          await fetchUserGameCount(currentUserId);
          await updateWalletUI(currentUserId);
          
          document.getElementById('createBtn').addEventListener('click', () => createGame(user));
          document.getElementById('panelHeader').addEventListener('click', () => {
              if (selectedCoords) document.getElementById('formPanelWrapper').classList.toggle('expanded');
          });
          document.getElementById('startDateTime').addEventListener('change', () => {
              let selectedDate = new Date(document.getElementById('startDateTime').value);
              if (selectedDate.getMinutes() !== 0) {
                selectedDate.setMinutes(0, 0, 0);
                const toLocalISOString = (d) => `${d.getFullYear()}-${(d.getMonth()+1).toString().padStart(2,'0')}-${d.getDate().toString().padStart(2,'0')}T${d.getHours().toString().padStart(2,'0')}:00`;
                document.getElementById('startDateTime').value = toLocalISOString(selectedDate);
              }
              validateSlot();
          });
          map.on('dragstart', () => { document.getElementById('formPanelWrapper').classList.remove('expanded'); });
          
          document.getElementById('cancelBtn').addEventListener('click', resetForm);
          document.getElementById('walletBtn').addEventListener('click', openPaymentModal); // Open settings modal
          
          document.querySelectorAll('[name="paymentMethod"]').forEach(r => r.addEventListener('change', e => togglePaymentInput(e.target.value)));
          document.getElementById("paymentForm").addEventListener('submit', async (e) => {
              e.preventDefault();
              const method = document.querySelector('[name="paymentMethod"]:checked').value;
              const email1 = document.getElementById("paypalEmail").value.trim();
              const email2 = document.getElementById("paypalEmailConfirm").value.trim();
              const mobile1 = document.getElementById("mobileNumber").value.trim();
              const mobile2 = document.getElementById("mobileNumberConfirm").value.trim();
              if (method === 'paypal' && email1 !== email2) return Swal.fire("Error", "Emails do not match.", "error");
              if (method === 'mobile' && mobile1 !== mobile2) return Swal.fire("Error", "Mobile numbers do not match.", "error");
              
              const { error } = await supabaseClient.from('users').update({
                payment_type: method,
                paypal_username: method === 'paypal' ? email1 : null,
                mobile_number: method === 'mobile' ? mobile1 : null
              }).eq('id', currentUserId);

              if (error) { Swal.fire("Error", "Failed to update: " + error.message, "error"); }
              else {
                Swal.fire("Success", "Payment method updated.", "success");
                closeModal('paymentModalOverlay');
                updateWalletUI(currentUserId);
              }
          });
      });

      map.on('click', async (e) => {
          selectedCoords = e.lngLat;
          if (mapMarker) { mapMarker.setLngLat(selectedCoords); } 
          else { mapMarker = new mapboxgl.Marker({ color: '#17a2b8', scale: 1.2 }).setLngLat(selectedCoords).addTo(map); }
          
          document.getElementById('formPanelWrapper').classList.add('expanded');
          validateSlot();
          
          const locTextElement = document.getElementById('locText');
          locTextElement.textContent = `Fetching address...`;
          try {
              const response = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${selectedCoords.lng},${selectedCoords.lat}.json?types=address&access_token=${mapboxgl.accessToken}`);
              const data = await response.json();
              if (data?.features?.length > 0) {
                  const address = data.features[0].place_name;
                  locTextElement.textContent = address;
                  const streetAddress = address.split(',')[0].trim();
                  const nameSuffixes = ['Quest', 'Hunt', 'Challenge', 'Trek', 'Mystery'];
                  document.getElementById('gameTitle').value = `${streetAddress} ${nameSuffixes[Math.floor(Math.random() * nameSuffixes.length)]}`;
              } else { throw new Error('No address found'); }
          } catch (error) {
              locTextElement.textContent = `Lng: ${selectedCoords.lng.toFixed(4)}, Lat: ${e.lngLat.lat.toFixed(4)}`;
          }
      });
      
      resetForm();
    });
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script defer="" src="session.js"></script>
<script>
    // const SUPABASE_URL = '...';
    // const SUPABASE_ANON_KEY = '...';
    // const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    let map, selectedCoords, mapMarker, gameMarkers = {};
    let currentWalletData = null, currentUserId = null, currentAction = null;
    
    function setDateTimeConstraints() {
      const input = document.getElementById('startDateTime');
      const minDate = new Date();
      minDate.setHours(minDate.getHours() + 1, 0, 0, 0); 
      const maxDate = new Date();
      maxDate.setDate(maxDate.getDate() + 14);
      const toLocalISOString = (date) => `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getDate().toString().padStart(2, '0')}T${date.getHours().toString().padStart(2, '0')}:00`;
      input.min = toLocalISOString(minDate);
      input.max = toLocalISOString(maxDate);
      input.value = toLocalISOString(minDate);
    }
    
    function resetForm() {
      document.getElementById('formPanelWrapper').classList.remove('expanded');
      if (mapMarker) {
        mapMarker.remove();
        mapMarker = null;
      }
      selectedCoords = null;
      document.getElementById('gameTitle').value = '';
      document.getElementById('treasures').value = '';
      document.getElementById('value').value = '';
      document.getElementById('locText').textContent = 'Click map to select a starting point';
      document.getElementById('slotStatus').textContent = 'Select a location and time';
      document.getElementById('slotStatus').className = 'status-message';
      document.getElementById('startDateTime').classList.remove('valid-slot', 'invalid-slot');
      document.getElementById('createBtn').disabled = true;
      setDateTimeConstraints();
    }

    async function updateWalletUI(userId) {
      const { data, error } = await supabaseClient.from('users').select('wallet, payment_type, paypal_username, mobile_number').eq('id', userId).single();
      if (error) { console.error('Error fetching wallet:', error); return; }
      if (data) {
        currentWalletData = data;
        document.getElementById('headerWallet').textContent = `Wallet: $${(data.wallet || 0).toFixed(2)}`;
      }
    }
    
    async function fetchUserGameCount(userId) {
        const { count, error } = await supabaseClient
            .from('games')
            .select('*', { count: 'exact', head: true })
            .eq('creator_id', userId)
            .in('status', ['pending', 'in_progress']);
        if (error) { console.error('Error fetching user game count:', error); return; }
        document.getElementById('gameCount').textContent = `Your Active Games: ${count || 0}`;
    }

    async function fetchAndDisplayGames() {
      const { data: games, error } = await supabaseClient.rpc('get_all_active_games_with_details');
      if (error) { console.error("Error fetching all games:", error); return; }

      const activeGameIds = new Set(games ? games.map(g => g.game_id) : []);

      for (const gameId in gameMarkers) {
          if (!activeGameIds.has(gameId)) {
              gameMarkers[gameId].marker.remove();
              gameMarkers[gameId].popup.remove();
              delete gameMarkers[gameId];
          }
      }
      
      if (!games) return;

      games.forEach(game => {
          if (gameMarkers[game.game_id] || !game.location?.coordinates) return;
          const markerEl = document.createElement('div');
          markerEl.style.cssText = 'background-color: #ffc107; width: 12px; height: 12px; border-radius: 50%; border: 2px solid #333;';
          const marker = new mapboxgl.Marker(markerEl).setLngLat(game.location.coordinates).addTo(map);
          const timeInfoHTML = game.status === 'pending'
              ? `Starts: ${new Date(game.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
              : `Live! Ends: ${new Date(game.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
          const popupContent = `<div class="fixed-bubble"><strong>${game.title}</strong><p>$${game.total_value} Prize | by ${game.creator_username}</p><p>${timeInfoHTML}</p></div>`;
          const popup = new mapboxgl.Popup({ closeButton: false, closeOnClick: false, anchor: 'bottom', offset: 25 }).setLngLat(game.location.coordinates).setHTML(popupContent).addTo(map);
          gameMarkers[game.game_id] = { marker, popup };
      });
    }

    async function validateSlot() {
        const timeValue = document.getElementById('startDateTime').value;
        if (!selectedCoords || !timeValue) return;
        const statusEl = document.getElementById('slotStatus'), inputEl = document.getElementById('startDateTime'), createBtn = document.getElementById('createBtn');
        statusEl.textContent = 'Checking availability...'; statusEl.className = 'status-message loading';
        inputEl.classList.remove('valid-slot', 'invalid-slot'); createBtn.disabled = true;

        const { data: result, error } = await supabaseClient.rpc('check_geo_slot', {
            start_time_input: new Date(timeValue).toISOString(),
            location_input: `POINT(${selectedCoords.lng} ${selectedCoords.lat})`
        });

        if (error) {
            statusEl.textContent = 'Error checking slot.'; statusEl.className = 'status-message invalid';
        } else if (result === 'OK') {
            statusEl.textContent = 'Slot is available!'; statusEl.className = 'status-message valid';
            inputEl.classList.add('valid-slot'); createBtn.disabled = false;
        } else {
            statusEl.textContent = result; statusEl.className = 'status-message invalid';
            inputEl.classList.add('invalid-slot');
        }
    }

    async function createGame(user) {
        const title = document.getElementById('gameTitle').value.trim();
        const startTime = document.getElementById('startDateTime').value;
        const treasureCount = parseInt(document.getElementById('treasures').value, 10);
        const totalValue = parseFloat(document.getElementById('value').value);
        
        if (!title || !startTime || !treasureCount || isNaN(totalValue) || !selectedCoords) {
            return Swal.fire("Validation Error", "Please complete all fields and select a location.", "warning");
        }
        if (currentWalletData.wallet < totalValue) {
            return Swal.fire("Insufficient Funds", "The total prize value cannot exceed your wallet balance.", "error");
        }
        
        document.getElementById('createBtn').disabled = true; document.getElementById('createBtn').textContent = 'Creating...';
        
        // FIX: Correctly subtract the game cost from the wallet
        const newWalletBalance = currentWalletData.wallet - totalValue;
        const { error: walletError } = await supabaseClient.from('users').update({ wallet: newWalletBalance }).eq('id', user.id);
        if (walletError) {
            document.getElementById('createBtn').disabled = false; document.getElementById('createBtn').textContent = 'Create Game';
            return Swal.fire("Payment Failed", "Could not deduct funds from wallet.", "error");
        }

        const { error: gameError } = await supabaseClient.rpc('create_game_with_slot_check', {
            creator_id_input: user.id, title_input: title, start_time_input: new Date(startTime).toISOString(),
            treasure_count_input: treasureCount, total_value_input: totalValue,
            latitude_input: selectedCoords.lat, longitude_input: selectedCoords.lng
        });

        if (gameError) { 
            // Refund the user if game creation fails after payment
            await supabaseClient.from('users').update({ wallet: currentWalletData.wallet }).eq('id', user.id);
            document.getElementById('createBtn').disabled = false; document.getElementById('createBtn').textContent = 'Create Game';
            return Swal.fire("Game Creation Failed", gameError.message, "error"); 
        }

        await Swal.fire("Game Created!", "Your game is scheduled.", "success");
        await updateWalletUI(user.id);
        await fetchUserGameCount(user.id);
        await fetchAndDisplayGames();
        resetForm();
        document.getElementById('createBtn').textContent = 'Create Game';
    }

    function openTransactionModal(action) {
      currentAction = action;
      document.getElementById("transactionTitle").innerText = action === 'add' ? 'Add Funds' : 'Withdraw Funds';
      document.getElementById("amountInput").value = '';
      document.getElementById("transactionModalOverlay").style.display = 'flex';
    }

    async function processTransaction() {
      const amount = parseFloat(document.getElementById("amountInput").value);
      if (isNaN(amount) || amount <= 0) return Swal.fire("Error", "Please enter a valid amount.", "error");
      
      const currentBalance = currentWalletData?.wallet ?? 0;
      const newBalance = currentAction === 'add' ? currentBalance + amount : currentBalance - amount;

      if (currentAction === 'withdraw') {
        if (amount > currentBalance) return Swal.fire("Error", "Insufficient funds.", "error");
        if (!currentWalletData.payment_type) return Swal.fire("Error", "Please set a payment method in Settings first.", "error");
        Swal.fire("Processing", "Withdrawal is being processed.", "info");
      }

      const { error } = await supabaseClient.from('users').update({ wallet: newBalance }).eq('id', currentUserId);
      if (error) return Swal.fire("Error", "Transaction failed: " + error.message, "error");

      Swal.fire("Success", "Your wallet has been updated!", "success");
      closeModal('transactionModalOverlay');
      updateWalletUI(currentUserId);
    }
    
    function openPaymentModal() {
      const type = currentWalletData?.payment_type || 'paypal';
      document.querySelector(`[name="paymentMethod"][value=${type}]`).checked = true;
      togglePaymentInput(type);
      document.getElementById('paypalEmail').value = currentWalletData?.paypal_username || '';
      document.getElementById('mobileNumber').value = currentWalletData?.mobile_number || '';
      document.getElementById('paypalEmailConfirm').value = '';
      document.getElementById('mobileNumberConfirm').value = '';
      document.getElementById("paymentModalOverlay").style.display = 'flex';
    }
    
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }
    function togglePaymentInput(method) {
      document.getElementById('paypalInputGroup').style.display = method === 'paypal' ? 'block' : 'none';
      document.getElementById('mobileInputGroup').style.display = method === 'mobile' ? 'block' : 'none';
    }

    document.addEventListener('DOMContentLoaded', async () => {
      const user = await verifySession(); 
      if (!user) return; 
      currentUserId = user.id;
      
      const { data: userData } = await supabaseClient.from('users').select('username').eq('id', currentUserId).single();
      if (userData) document.getElementById('headerUsername').textContent = userData.username;

      mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
      map = new mapboxgl.Map({ container: 'map', style: 'mapbox://styles/mapbox/dark-v11', center: [-73.78, 41.03], zoom: 11 });

      map.on('load', async () => {
          map.resize();
          await fetchAndDisplayGames();
          await fetchUserGameCount(currentUserId);
          await updateWalletUI(currentUserId);
          
          document.getElementById('createBtn').addEventListener('click', () => createGame(user));
          document.getElementById('panelHeader').addEventListener('click', () => {
              if (selectedCoords) document.getElementById('formPanelWrapper').classList.toggle('expanded');
          });
          document.getElementById('startDateTime').addEventListener('change', () => {
              let selectedDate = new Date(document.getElementById('startDateTime').value);
              if (selectedDate.getMinutes() !== 0) {
                selectedDate.setMinutes(0, 0, 0);
                const toLocalISOString = (d) => `${d.getFullYear()}-${(d.getMonth()+1).toString().padStart(2,'0')}-${d.getDate().toString().padStart(2,'0')}T${d.getHours().toString().padStart(2,'0')}:00`;
                document.getElementById('startDateTime').value = toLocalISOString(selectedDate);
              }
              validateSlot();
          });
          map.on('dragstart', () => { document.getElementById('formPanelWrapper').classList.remove('expanded'); });
          
          document.getElementById('cancelBtn').addEventListener('click', resetForm);
          document.getElementById('walletBtn').addEventListener('click', openPaymentModal); // Open settings modal
          
          document.querySelectorAll('[name="paymentMethod"]').forEach(r => r.addEventListener('change', e => togglePaymentInput(e.target.value)));
          document.getElementById("paymentForm").addEventListener('submit', async (e) => {
              e.preventDefault();
              const method = document.querySelector('[name="paymentMethod"]:checked').value;
              const email1 = document.getElementById("paypalEmail").value.trim();
              const email2 = document.getElementById("paypalEmailConfirm").value.trim();
              const mobile1 = document.getElementById("mobileNumber").value.trim();
              const mobile2 = document.getElementById("mobileNumberConfirm").value.trim();
              if (method === 'paypal' && email1 !== email2) return Swal.fire("Error", "Emails do not match.", "error");
              if (method === 'mobile' && mobile1 !== mobile2) return Swal.fire("Error", "Mobile numbers do not match.", "error");
              
              const { error } = await supabaseClient.from('users').update({
                payment_type: method,
                paypal_username: method === 'paypal' ? email1 : null,
                mobile_number: method === 'mobile' ? mobile1 : null
              }).eq('id', currentUserId);

              if (error) { Swal.fire("Error", "Failed to update: " + error.message, "error"); }
              else {
                Swal.fire("Success", "Payment method updated.", "success");
                closeModal('paymentModalOverlay');
                updateWalletUI(currentUserId);
              }
          });
      });

      map.on('click', async (e) => {
          selectedCoords = e.lngLat;
          if (mapMarker) { mapMarker.setLngLat(selectedCoords); } 
          else { mapMarker = new mapboxgl.Marker({ color: '#17a2b8', scale: 1.2 }).setLngLat(selectedCoords).addTo(map); }
          
          document.getElementById('formPanelWrapper').classList.add('expanded');
          validateSlot();
          
          const locTextElement = document.getElementById('locText');
          locTextElement.textContent = `Fetching address...`;
          try {
              const response = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${selectedCoords.lng},${selectedCoords.lat}.json?types=address&access_token=${mapboxgl.accessToken}`);
              const data = await response.json();
              if (data?.features?.length > 0) {
                  const address = data.features[0].place_name;
                  locTextElement.textContent = address;
                  const streetAddress = address.split(',')[0].trim();
                  const nameSuffixes = ['Quest', 'Hunt', 'Challenge', 'Trek', 'Mystery'];
                  document.getElementById('gameTitle').value = `${streetAddress} ${nameSuffixes[Math.floor(Math.random() * nameSuffixes.length)]}`;
              } else { throw new Error('No address found'); }
          } catch (error) {
              locTextElement.textContent = `Lng: ${selectedCoords.lng.toFixed(4)}, Lat: ${e.lngLat.lat.toFixed(4)}`;
          }
      });
      
      resetForm();
    });
  </script>