<style>
    html, body {
      margin: 0; height: 100%; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: #fff; overflow: hidden;
    }
    #map { position: absolute; top: 0; bottom: 0; width: 100%; }
    .main-container { display: flex; flex-direction: column; height: 100vh; }
    header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 10px 15px; background: rgba(0, 0, 0, 0.25);
    }
    .header-link { color: #fff; text-decoration: none; font-weight: bold; }
    .header-info { display: flex; gap: 8px; font-size: 14px; align-items: center; }
    #formPanelWrapper {
      position: absolute; bottom: 0; left: 0; right: 0;
      background: rgba(25,25,25,0.85); border-top: 1px solid rgba(255,255,255,0.2);
      max-height: 85px;
      overflow: hidden; transition: max-height 0.4s ease-in-out; z-index: 10;
    }
    #formPanelWrapper.expanded { max-height: 75vh; overflow-y: auto; }
    #panelHeader {
      display: flex; justify-content: space-between; align-items: flex-start;
      padding: 15px 20px; cursor: pointer;
    }
    #locationInfo p {
      margin: 4px 0 0; font-size: 14px; color: #ccc; max-width: 200px;
    }
    #gamesInfo { text-align: right; flex-shrink: 0; }
    #gamesInfo a {
      display: block; margin-top: 4px; font-size: 14px; color: #66bfff; text-decoration: none;
    }
    #formFields { padding: 0 20px 20px; }
    label { display: block; margin-top: 15px; margin-bottom: 5px; font-size: 14px; color: #ccc; }
    input, button {
      padding: 12px; width: 100%; box-sizing: border-box; font-size: 16px; border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.3); background: rgba(255,255,255,0.15); color: white;
    }
    button { cursor: pointer; margin-top: 10px; border: none; font-weight: bold; }
    #createBtn { background: #28a745; }
    #createBtn:disabled { background: #555; cursor: not-allowed; }
    #closeFormBtn { background: #dc3545; }
    #walletInfo { margin-top: 15px; }

    /* Slot status styles */
    .status-message {
      font-size: 13px; font-weight: bold; margin-top: 6px; height: 16px; text-align: center;
    }
    .status-message.loading { color: #ffc107; }
    .status-message.invalid { color: #ff8a8a; }
    .status-message.valid { color: #8dff8a; }
    #startDateTime.invalid-slot { border-color: #dc3545 !important; }
    #startDateTime.valid-slot { border-color: #28a745 !important; }

    /* Styles for the fixed info bubbles */
    .mapboxgl-popup { z-index: 5; }
    .mapboxgl-popup-content {
      background: rgba(0, 0, 0, 0.75); backdrop-filter: blur(4px);
      color: white; border-radius: 8px; padding: 6px 10px;
      font-size: 12px; box-shadow: none; border: 1px solid rgba(255, 255, 255, 0.2);
    }
    .mapboxgl-popup-anchor-bottom .mapboxgl-popup-tip { border-top-color: rgba(0, 0, 0, 0.75); }
    .fixed-bubble { text-align: center; max-width: 180px; }
    .fixed-bubble strong {
        font-size: 13px; color: #ffc107; white-space: nowrap;
        overflow: hidden; text-overflow: ellipsis; display: block;
    }
    .fixed-bubble p { margin: 3px 0 0; line-height: 1.3; color: #ddd; font-size: 11px; }
  </style>
<body>
<header>
<a class="header-link" href="map.html">← Exit</a>
<div class="header-info">
<span id="headerUsername">Loading...</span>
<span>|</span>
<span id="headerGameCount">Games: 0</span>
</div>
</header>
<div class="main-container">
<div id="map"></div>
<div id="formPanelWrapper">
<div id="panelHeader">
<div id="locationInfo">
<label>Selected Location</label>
<p id="locText">Click map to select...</p>
</div>
<div id="gamesInfo">
<span id="gameCount">Active Games: 0</span>
<a href="creatorsactivities.html">View All</a>
</div>
</div>
<div id="formFields">
<label for="gameTitle">Game Title</label>
<input id="gameTitle" type="text"/>
<label for="startDateTime">Start Date &amp; Time</label>
<input id="startDateTime" step="3600" type="datetime-local"/>
<div class="status-message" id="slotStatus"></div>
<label for="treasures">Number of Hidden Treasures</label>
<input id="treasures" min="1" type="number"/>
<label for="value">Total Prize Value ($)</label>
<input id="value" min="1" type="number"/>
<div id="walletInfo"><span id="walletBalance">Wallet: $0.00</span><button onclick="addToWallet()">Add Money</button></div>
<button disabled="" id="createBtn">Create Game</button>
<button id="closeFormBtn">Cancel</button>
</div>
</div>
</div>
<script>
    const SUPABASE_URL = 'https://mgtilfgygzymxiyixjit.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1ndGlsZmd5Z3p5bXhpeWl4aml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE3MjQwMjMsImV4cCI6MjA2NzMwMDAyM30.0Kx5Lfd65QVcnQMOvnxzSnRcoyu2smuUFijzUFu8n_g';
    const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    let map, selectedCoords = null;
    let mapMarker = null; 
    let gameMarkers = {}; 
    let activePopup = null, currentUserWallet = 0;

    function setDateTimeConstraints() {
      const startDateTimeInput = document.getElementById('startDateTime');
      const minDate = new Date();
      minDate.setHours(minDate.getHours() + 1, 0, 0, 0); 
      const localMinDateTime = `${minDate.getFullYear()}-${(minDate.getMonth() + 1).toString().padStart(2, '0')}-${minDate.getDate().toString().padStart(2, '0')}T${minDate.getHours().toString().padStart(2, '0')}:00`;
      
      const maxDate = new Date();
      maxDate.setDate(maxDate.getDate() + 7);
      const localMaxDateTime = `${maxDate.getFullYear()}-${(maxDate.getMonth() + 1).toString().padStart(2, '0')}-${maxDate.getDate().toString().padStart(2, '0')}T23:00`;

      startDateTimeInput.min = localMinDateTime;
      startDateTimeInput.max = localMaxDateTime;
      startDateTimeInput.value = localMinDateTime;
    }
    
    function triggerValidation() {
        const timeValue = document.getElementById('startDateTime').value;
        if (selectedCoords && timeValue) {
            const isoString = new Date(timeValue).toISOString();
            validateSlotAndLocation(isoString, selectedCoords);
        }
    }

    async function validateSlotAndLocation(isoDateTimeString, coords) {
        const statusEl = document.getElementById('slotStatus');
        const inputEl = document.getElementById('startDateTime');
        const createBtn = document.getElementById('createBtn');

        statusEl.textContent = 'Checking...';
        statusEl.className = 'status-message loading';
        inputEl.classList.remove('valid-slot', 'invalid-slot');
        createBtn.disabled = true;

        try {
            const { data: validationResult, error } = await supabaseClient.rpc('check_geo_slot', {
                start_time_input: isoDateTimeString,
                location_input: `POINT(${coords.lng} ${coords.lat})`
            });

            if (error) throw error;

            if (validationResult === 'OK') {
                statusEl.textContent = 'Slot is available!';
                statusEl.className = 'status-message valid';
                inputEl.classList.add('valid-slot');
                createBtn.disabled = false;
            } else {
                statusEl.textContent = validationResult;
                statusEl.className = 'status-message invalid';
                inputEl.classList.add('invalid-slot');
                createBtn.disabled = true;
            }
        } catch (err) {
            console.error('Error checking slot:', err);
            statusEl.textContent = 'Error checking slot.';
            statusEl.className = 'status-message invalid';
            createBtn.disabled = true;
        }
    }

    document.addEventListener('DOMContentLoaded', async () => {
      const { data: { session } } = await supabaseClient.auth.getSession();
      if (!session) return (window.location.href = "login.html");
      const user = session.user;
      
      const { data: userData } = await supabaseClient.from('users').select('username').eq('id', user.id).single();
      if (userData) document.getElementById('headerUsername').textContent = userData.username;

      mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
      map = new mapboxgl.Map({ container: 'map', style: 'mapbox://styles/mapbox/dark-v11', center: [-73.78, 41.03], zoom: 12 });

      map.on('load', () => {
        fetchAndDisplayGames(); 
        map.resize();
        document.getElementById('createBtn').addEventListener('click', () => createGame(user));
        document.getElementById('closeFormBtn').addEventListener('click', () => document.getElementById('formPanelWrapper').classList.remove('expanded'));
        document.getElementById('panelHeader').addEventListener('click', () => {
            if (selectedCoords) document.getElementById('formPanelWrapper').classList.toggle('expanded');
        });
      });

      map.on('click', async (e) => {
        selectedCoords = e.lngLat;
        if (mapMarker) {
            mapMarker.setLngLat(selectedCoords);
        } else {
            mapMarker = new mapboxgl.Marker({ color: '#17a2b8' }).setLngLat(selectedCoords).addTo(map);
        }
        document.getElementById('formPanelWrapper').classList.add('expanded');
        
        triggerValidation();
        
        const locTextElement = document.getElementById('locText');
        const gameTitleInput = document.getElementById('gameTitle');
        locTextElement.textContent = 'Fetching address...';
        gameTitleInput.value = '';

        try {
            const geocodeUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${selectedCoords.lng},${selectedCoords.lat}.json?types=address&access_token=${mapboxgl.accessToken}`;
            const response = await fetch(geocodeUrl);
            const data = await response.json();
            if (data && data.features && data.features.length > 0) {
                const address = data.features[0].place_name;
                locTextElement.textContent = address;

                const nameSuffixes = ['Quest', 'Hunt', 'Challenge', 'Trek', 'Mystery', 'Cache', 'Find'];
                const randomSuffix = nameSuffixes[Math.floor(Math.random() * nameSuffixes.length)];
                const streetAddress = address.split(',')[0].trim();
                const suggestedTitle = /^\d+$/.test(streetAddress) ? `Location ${randomSuffix}` : `${streetAddress} ${randomSuffix}`;
                gameTitleInput.value = suggestedTitle;

            } else {
                locTextElement.textContent = `Lng: ${selectedCoords.lng.toFixed(4)}, Lat: ${selectedCoords.lat.toFixed(4)}`;
            }
        } catch (error) {
            locTextElement.textContent = `Lng: ${selectedCoords.lng.toFixed(4)}, Lat: ${selectedCoords.lat.toFixed(4)}`;
        }
      });

      map.on('dragstart', () => {
        document.getElementById('formPanelWrapper').classList.remove('expanded');
      });

      setDateTimeConstraints();
      await fetchWallet(user.id);
      
      document.getElementById('startDateTime').addEventListener('change', (e) => {
          let selectedDate = new Date(e.target.value);
          if (selectedDate.getMinutes() !== 0) {
              if (selectedDate.getMinutes() >= 30) selectedDate.setHours(selectedDate.getHours() + 1);
              selectedDate.setMinutes(0, 0, 0);
              const year = selectedDate.getFullYear();
              const month = (selectedDate.getMonth() + 1).toString().padStart(2, '0');
              const day = selectedDate.getDate().toString().padStart(2, '0');
              const hours = selectedDate.getHours().toString().padStart(2, '0');
              e.target.value = `${year}-${month}-${day}T${hours}:00`;
          }
          triggerValidation();
      });
    });

    async function fetchWallet(userId) {
      const { data } = await supabaseClient.from('users').select('wallet').eq('id', userId).single();
      if (data) {
        currentUserWallet = data.wallet;
        document.getElementById('walletBalance').textContent = `Wallet: $${currentUserWallet.toFixed(2)}`;
      }
    }

    async function createGame(user) {
      const title = document.getElementById('gameTitle').value.trim();
      const startTime = document.getElementById('startDateTime').value;
      const treasureCount = parseInt(document.getElementById('treasures').value);
      const totalValue = parseFloat(document.getElementById('value').value);
      if (!title || !startTime || !treasureCount || isNaN(totalValue) || !selectedCoords)
        return Swal.fire("Validation Error", "Please complete all fields and select a location.", "warning");
      if (currentUserWallet < totalValue)
        return Swal.fire("Insufficient Funds", "Not enough money in your wallet.", "error");

      const { error } = await supabaseClient.rpc('create_game_with_slot_check', {
        creator_id_input: user.id,
        title_input: title,
        start_time_input: new Date(startTime).toISOString(),
        treasure_count_input: treasureCount,
        total_value_input: totalValue,
        latitude_input: selectedCoords.lat,
        longitude_input: selectedCoords.lng
      });

      if (error) { return Swal.fire("Game Creation Failed", error.message, "error"); }

      await supabaseClient.from('users').update({ wallet: currentUserWallet - totalValue }).eq('id', user.id);
      await fetchWallet(user.id);
      Swal.fire("Game Created!", "Your game is now live or pending.", "success");
      document.getElementById('formPanelWrapper').classList.remove('expanded');
      setDateTimeConstraints();
      fetchAndDisplayGames();
    }

    function addToWallet() {
      window.location.href = 'wallet.html';
    }
  
    async function fetchAndDisplayGames() {
      const { data: games, error } = await supabaseClient.rpc('get_all_active_games_with_details');
      if (error) { console.error("Error fetching games:", error); return; }
      
      document.getElementById('headerGameCount').textContent = `Games: ${games?.length || 0}`;

      const activeGameIds = new Set(games ? games.map(g => g.game_id) : []);
      Object.keys(gameMarkers).forEach(id => {
          if (!activeGameIds.has(parseInt(id))) {
              if (gameMarkers[id].marker) gameMarkers[id].marker.remove();
              if (gameMarkers[id].popup) gameMarkers[id].popup.remove();
              delete gameMarkers[id];
          }
      });
      
      if (!games) return;

      games.forEach(game => {
          const gameId = game.game_id;
          if (!game.location?.coordinates || gameMarkers[gameId]) return;

          const markerEl = document.createElement('div');
          // **CHANGE:** Updated style for a visible dot marker
          markerEl.style.cssText = 'background-color: #ffc107; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 7px rgba(0,0,0,0.5);';
          
          const marker = new mapboxgl.Marker(markerEl).setLngLat(game.location.coordinates).addTo(map);
          let timeInfoHTML = '';
          if (game.status === 'pending') {
              timeInfoHTML = `Starts: ${new Date(game.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
          } else if (game.status === 'in_progress') {
              timeInfoHTML = `Live! Ends: ${new Date(game.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
          }
        
          const popupContent = `<div class="fixed-bubble"><strong>${game.title}</strong><p>$${game.total_value} Prize | by ${game.creator_username}</p><p>${timeInfoHTML}</p></div>`;
          const popup = new mapboxgl.Popup({ closeButton: false, closeOnClick: false, anchor: 'bottom', offset: 25 }).setLngLat(game.location.coordinates).setHTML(popupContent).addTo(map);

          gameMarkers[gameId] = { marker: marker, popup: popup };
      });
    }
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/@turf/turf@6/turf.min.js"></script>
<script>
    const SUPABASE_URL = 'https://mgtilfgygzymxiyixjit.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1ndGlsZmd5Z3p5bXhpeWl4aml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE3MjQwMjMsImV4cCI6MjA2NzMwMDAyM30.0Kx5Lfd65QVcnQMOvnxzSnRcoyu2smuUFijzUFu8n_g';
    const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    let map, selectedCoords = null;
    let mapMarker = null; 
    let gameMarkers = {}; 
    let activePopup = null, currentUserWallet = 0;

    function setDateTimeConstraints() {
      const startDateTimeInput = document.getElementById('startDateTime');
      const minDate = new Date();
      minDate.setHours(minDate.getHours() + 1, 0, 0, 0); 
      const localMinDateTime = `${minDate.getFullYear()}-${(minDate.getMonth() + 1).toString().padStart(2, '0')}-${minDate.getDate().toString().padStart(2, '0')}T${minDate.getHours().toString().padStart(2, '0')}:00`;
      
      const maxDate = new Date();
      maxDate.setDate(maxDate.getDate() + 7);
      const localMaxDateTime = `${maxDate.getFullYear()}-${(maxDate.getMonth() + 1).toString().padStart(2, '0')}-${maxDate.getDate().toString().padStart(2, '0')}T23:00`;

      startDateTimeInput.min = localMinDateTime;
      startDateTimeInput.max = localMaxDateTime;
      startDateTimeInput.value = localMinDateTime;
    }
    
    function triggerValidation() {
        const timeValue = document.getElementById('startDateTime').value;
        if (selectedCoords && timeValue) {
            const isoString = new Date(timeValue).toISOString();
            validateSlotAndLocation(isoString, selectedCoords);
        }
    }

    async function validateSlotAndLocation(isoDateTimeString, coords) {
        const statusEl = document.getElementById('slotStatus');
        const inputEl = document.getElementById('startDateTime');
        const createBtn = document.getElementById('createBtn');

        statusEl.textContent = 'Checking...';
        statusEl.className = 'status-message loading';
        inputEl.classList.remove('valid-slot', 'invalid-slot');
        createBtn.disabled = true;

        try {
            const { data: validationResult, error } = await supabaseClient.rpc('check_geo_slot', {
                start_time_input: isoDateTimeString,
                location_input: `POINT(${coords.lng} ${coords.lat})`
            });

            if (error) throw error;

            if (validationResult === 'OK') {
                statusEl.textContent = 'Slot is available!';
                statusEl.className = 'status-message valid';
                inputEl.classList.add('valid-slot');
                createBtn.disabled = false;
            } else {
                statusEl.textContent = validationResult;
                statusEl.className = 'status-message invalid';
                inputEl.classList.add('invalid-slot');
                createBtn.disabled = true;
            }
        } catch (err) {
            console.error('Error checking slot:', err);
            statusEl.textContent = 'Error checking slot.';
            statusEl.className = 'status-message invalid';
            createBtn.disabled = true;
        }
    }

    document.addEventListener('DOMContentLoaded', async () => {
      const { data: { session } } = await supabaseClient.auth.getSession();
      if (!session) return (window.location.href = "login.html");
      const user = session.user;
      
      const { data: userData } = await supabaseClient.from('users').select('username').eq('id', user.id).single();
      if (userData) document.getElementById('headerUsername').textContent = userData.username;

      mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
      map = new mapboxgl.Map({ container: 'map', style: 'mapbox://styles/mapbox/dark-v11', center: [-73.78, 41.03], zoom: 12 });

      map.on('load', () => {
        fetchAndDisplayGames(); 
        map.resize();
        document.getElementById('createBtn').addEventListener('click', () => createGame(user));
        document.getElementById('closeFormBtn').addEventListener('click', () => document.getElementById('formPanelWrapper').classList.remove('expanded'));
        document.getElementById('panelHeader').addEventListener('click', () => {
            if (selectedCoords) document.getElementById('formPanelWrapper').classList.toggle('expanded');
        });
      });

      map.on('click', async (e) => {
        selectedCoords = e.lngLat;
        if (mapMarker) {
            mapMarker.setLngLat(selectedCoords);
        } else {
            mapMarker = new mapboxgl.Marker({ color: '#17a2b8' }).setLngLat(selectedCoords).addTo(map);
        }
        document.getElementById('formPanelWrapper').classList.add('expanded');
        
        triggerValidation();
        
        const locTextElement = document.getElementById('locText');
        const gameTitleInput = document.getElementById('gameTitle');
        locTextElement.textContent = 'Fetching address...';
        gameTitleInput.value = '';

        try {
            const geocodeUrl = `https://api.mapbox.com/geocoding/v5/mapbox.places/${selectedCoords.lng},${selectedCoords.lat}.json?types=address&access_token=${mapboxgl.accessToken}`;
            const response = await fetch(geocodeUrl);
            const data = await response.json();
            if (data && data.features && data.features.length > 0) {
                const address = data.features[0].place_name;
                locTextElement.textContent = address;

                const nameSuffixes = ['Quest', 'Hunt', 'Challenge', 'Trek', 'Mystery', 'Cache', 'Find'];
                const randomSuffix = nameSuffixes[Math.floor(Math.random() * nameSuffixes.length)];
                const streetAddress = address.split(',')[0].trim();
                const suggestedTitle = /^\d+$/.test(streetAddress) ? `Location ${randomSuffix}` : `${streetAddress} ${randomSuffix}`;
                gameTitleInput.value = suggestedTitle;

            } else {
                locTextElement.textContent = `Lng: ${selectedCoords.lng.toFixed(4)}, Lat: ${selectedCoords.lat.toFixed(4)}`;
            }
        } catch (error) {
            locTextElement.textContent = `Lng: ${selectedCoords.lng.toFixed(4)}, Lat: ${selectedCoords.lat.toFixed(4)}`;
        }
      });

      map.on('dragstart', () => {
        document.getElementById('formPanelWrapper').classList.remove('expanded');
      });

      setDateTimeConstraints();
      await fetchWallet(user.id);
      
      document.getElementById('startDateTime').addEventListener('change', (e) => {
          let selectedDate = new Date(e.target.value);
          if (selectedDate.getMinutes() !== 0) {
              if (selectedDate.getMinutes() >= 30) selectedDate.setHours(selectedDate.getHours() + 1);
              selectedDate.setMinutes(0, 0, 0);
              const year = selectedDate.getFullYear();
              const month = (selectedDate.getMonth() + 1).toString().padStart(2, '0');
              const day = selectedDate.getDate().toString().padStart(2, '0');
              const hours = selectedDate.getHours().toString().padStart(2, '0');
              e.target.value = `${year}-${month}-${day}T${hours}:00`;
          }
          triggerValidation();
      });
    });

    async function fetchWallet(userId) {
      const { data } = await supabaseClient.from('users').select('wallet').eq('id', userId).single();
      if (data) {
        currentUserWallet = data.wallet;
        document.getElementById('walletBalance').textContent = `Wallet: $${currentUserWallet.toFixed(2)}`;
      }
    }

    async function createGame(user) {
      const title = document.getElementById('gameTitle').value.trim();
      const startTime = document.getElementById('startDateTime').value;
      const treasureCount = parseInt(document.getElementById('treasures').value);
      const totalValue = parseFloat(document.getElementById('value').value);
      if (!title || !startTime || !treasureCount || isNaN(totalValue) || !selectedCoords)
        return Swal.fire("Validation Error", "Please complete all fields and select a location.", "warning");
      if (currentUserWallet < totalValue)
        return Swal.fire("Insufficient Funds", "Not enough money in your wallet.", "error");

      const { error } = await supabaseClient.rpc('create_game_with_slot_check', {
        creator_id_input: user.id,
        title_input: title,
        start_time_input: new Date(startTime).toISOString(),
        treasure_count_input: treasureCount,
        total_value_input: totalValue,
        latitude_input: selectedCoords.lat,
        longitude_input: selectedCoords.lng
      });

      if (error) { return Swal.fire("Game Creation Failed", error.message, "error"); }

      await supabaseClient.from('users').update({ wallet: currentUserWallet - totalValue }).eq('id', user.id);
      await fetchWallet(user.id);
      Swal.fire("Game Created!", "Your game is now live or pending.", "success");
      document.getElementById('formPanelWrapper').classList.remove('expanded');
      setDateTimeConstraints();
      fetchAndDisplayGames();
    }

    function addToWallet() {
      window.location.href = 'wallet.html';
    }
  
    async function fetchAndDisplayGames() {
      const { data: games, error } = await supabaseClient.rpc('get_all_active_games_with_details');
      if (error) { console.error("Error fetching games:", error); return; }
      
      document.getElementById('headerGameCount').textContent = `Games: ${games?.length || 0}`;

      const activeGameIds = new Set(games ? games.map(g => g.game_id) : []);
      Object.keys(gameMarkers).forEach(id => {
          if (!activeGameIds.has(parseInt(id))) {
              if (gameMarkers[id].marker) gameMarkers[id].marker.remove();
              if (gameMarkers[id].popup) gameMarkers[id].popup.remove();
              delete gameMarkers[id];
          }
      });
      
      if (!games) return;

      games.forEach(game => {
          const gameId = game.game_id;
          if (!game.location?.coordinates || gameMarkers[gameId]) return;

          const markerEl = document.createElement('div');
          // **CHANGE:** Updated style for a visible dot marker
          markerEl.style.cssText = 'background-color: #ffc107; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 7px rgba(0,0,0,0.5);';
          
          const marker = new mapboxgl.Marker(markerEl).setLngLat(game.location.coordinates).addTo(map);
          let timeInfoHTML = '';
          if (game.status === 'pending') {
              timeInfoHTML = `Starts: ${new Date(game.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
          } else if (game.status === 'in_progress') {
              timeInfoHTML = `Live! Ends: ${new Date(game.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
          }
        
          const popupContent = `<div class="fixed-bubble"><strong>${game.title}</strong><p>$${game.total_value} Prize | by ${game.creator_username}</p><p>${timeInfoHTML}</p></div>`;
          const popup = new mapboxgl.Popup({ closeButton: false, closeOnClick: false, anchor: 'bottom', offset: 25 }).setLngLat(game.location.coordinates).setHTML(popupContent).addTo(map);

          gameMarkers[gameId] = { marker: marker, popup: popup };
      });
    }
  </script>