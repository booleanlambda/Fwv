<style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background-color: #1a1a2e;
      background-image:
        linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
      background-size: 30px 30px;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
    }
    .edit-profile-card {
      position: relative;
      background: rgba(20, 20, 30, 0.75);
      backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      width: 100%;
      max-width: 420px;
    }
    .back-link {
        position: absolute;
        top: 20px;
        left: 24px;
        color: rgba(255, 255, 255, 0.7);
        text-decoration: none;
        font-size: 14px;
        font-weight: 500;
        transition: color 0.2s;
    }
    .back-link:hover {
        color: #fff;
    }
    .back-link i {
        margin-right: 6px;
    }
    h2 {
      text-align: center;
      margin-top: 20px; /* Adjusted for back link */
      margin-bottom: 25px;
      color: #fff;
    }
    label {
      display: block;
      margin-top: 15px;
      margin-bottom: 5px;
      font-weight: bold;
      color: rgba(255, 255, 255, 0.9);
    }
    input, select {
      width: 100%;
      padding: 12px;
      border-radius: 8px;
      border: 1px solid rgba(255, 255, 255, 0.3);
      background: rgba(255, 255, 255, 0.15);
      color: #fff;
      box-sizing: border-box;
      font-size: 16px;
    }
    input::placeholder {
      color: rgba(255, 255, 255, 0.6);
    }
    button {
      margin-top: 25px;
      width: 100%;
      padding: 12px;
      background: #28a745;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    button:hover {
      background: #218838;
    }
    button:disabled {
      background: #555;
      cursor: not-allowed;
    }
    .status-message {
      font-size: 13px;
      font-weight: bold;
      margin-top: 6px;
      height: 16px;
      text-align: left;
    }
    .status-message.invalid { color: #ff8a8a; }
    .status-message.valid { color: #8dff8a; }
  </style>
<body>
<div class="edit-profile-card">
<a class="back-link" href="profile.html"><i class="fas fa-arrow-left"></i> Back to Profile</a>
<h2>Edit Your Profile</h2>
<form id="editProfileForm">
<label for="usernameEdit">Username</label>
<input id="usernameEdit" name="usernameEdit" required="" type="text"/>
<div class="status-message" id="usernameStatus"></div>
<label for="firstName">First Name</label>
<input id="firstName" name="firstName" required="" type="text"/>
<label for="lastName">Last Name</label>
<input id="lastName" name="lastName" required="" type="text"/>
<label for="gender">Gender</label>
<select id="gender" name="gender" required="">
<option disabled="" selected="" value="">Select your gender</option>
<option value="male">Male</option>
<option value="female">Female</option>
<option value="other">Other</option>
</select>
<label for="country">Country</label>
<select id="country" name="country" required="">
<option disabled="" selected="" value="">Select your country</option>
<option value="Ghana">Ghana</option>
<option value="United States">United States</option>
<option value="United Kingdom">United Kingdom</option>
<option value="Canada">Canada</option>
</select>
<label for="phoneNumber">Phone Number</label>
<input id="phoneNumber" name="phoneNumber" placeholder="e.g., +12125551234" required="" type="tel"/>
<button id="saveBtn" type="submit">Save Changes</button>
</form>
</div>
<script>
  const usernameEditInput = document.getElementById('usernameEdit');
  const usernameStatusEl = document.getElementById('usernameStatus');
  const saveBtn = document.getElementById('saveBtn');
  let originalUsername = '';
  let usernameChangeCount = 0;
  let debounceTimer;

  function validateNameField() {
    // Basic validation example: prevent numbers in name fields
    if (/\d/.test(this.value)) {
      this.value = this.value.replace(/\d/g, '');
    }
  }

  async function checkUsernameAvailability() {
    const newUsername = usernameEditInput.value.trim();
    usernameStatusEl.textContent = '';
    usernameStatusEl.className = 'status-message';
    saveBtn.disabled = false; // Enable by default

    if (newUsername === originalUsername) return;
    if (newUsername.length < 3) {
      usernameStatusEl.textContent = 'Username must be at least 3 characters.';
      usernameStatusEl.classList.add('invalid');
      saveBtn.disabled = true;
      return;
    }
    
    const { data, error } = await supabaseClient.from('users').select('id').eq('username', newUsername).single();
    
    if (data) {
      usernameStatusEl.textContent = 'Username is already taken.';
      usernameStatusEl.classList.add('invalid');
      saveBtn.disabled = true;
    } else if (error && error.code !== 'PGRST116') { // PGRST116 = row not found, which is good
      usernameStatusEl.textContent = 'Error checking username.';
      usernameStatusEl.classList.add('invalid');
      saveBtn.disabled = true;
    } else {
      usernameStatusEl.textContent = 'Username is available!';
      usernameStatusEl.classList.add('valid');
    }
  }

  async function loadProfileData(user) {
    originalUsername = user.user_metadata?.username || '';
    usernameEditInput.value = originalUsername;

    const { data: profile } = await supabaseClient.from("users").select("*").eq("id", user.id).single();
    if (profile) {
      document.getElementById("firstName").value = profile.first_name || '';
      document.getElementById("lastName").value = profile.last_name || '';
      document.getElementById("gender").value = profile.gender || '';
      document.getElementById("country").value = profile.country || '';
      document.getElementById("phoneNumber").value = profile.phone_number || '';
      usernameChangeCount = profile.username_change_count || 0;
    }
  }

  document.getElementById("editProfileForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    saveBtn.disabled = true;
    saveBtn.textContent = 'Saving...';
    
    const { data: { user } } = await supabaseClient.auth.getUser();
    const newUsername = usernameEditInput.value.trim();

    if (usernameStatusEl.classList.contains('invalid')) {
      alert('This username is not available.');
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save Changes';
      return;
    }

    let updateMeta = false;
    if (newUsername !== originalUsername) {
      if (usernameChangeCount >= 3) {
        alert("You have reached the limit of 3 username changes.");
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save Changes';
        return;
      }
      const { error: authError } = await supabaseClient.auth.updateUser({ data: { username: newUsername } });
      if (authError) {
        alert("Failed to update username: " + authError.message);
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save Changes';
        return;
      }
      usernameChangeCount++;
      updateMeta = true;
    }

    const updates = {
      id: user.id,
      username: newUsername,
      first_name: document.getElementById("firstName").value.trim(),
      last_name: document.getElementById("lastName").value.trim(),
      gender: document.getElementById("gender").value,
      country: document.getElementById("country").value,
      phone_number: document.getElementById("phoneNumber").value.trim(),
      ...(updateMeta && { username_change_count: usernameChangeCount })
    };

    const { error } = await supabaseClient.from("users").upsert(updates);
    if (error) {
      alert("Profile update failed: " + error.message);
    } else {
      alert("Profile updated successfully!");
      originalUsername = newUsername; // Update the original username after successful save
    }
    saveBtn.disabled = false;
    saveBtn.textContent = 'Save Changes';
  });

  async function initializePage() {
    const user = await verifySession();
    if (user) {
      await loadProfileData(user);
      
      usernameEditInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(checkUsernameAvailability, 500); // Debounce check
      });
      document.getElementById("firstName").addEventListener('input', validateNameField);
      document.getElementById("lastName").addEventListener('input', validateNameField);
    } else {
      document.body.innerHTML = `<div class="edit-profile-card" style="text-align:center;"><h1>Please Log In</h1><a class="btn" href="login.html" style="display:inline-block; margin-top:10px;">Go to Login</a></div>`;
    }
  }

  initializePage();
</script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="session.js"></script>
<script>
  const usernameEditInput = document.getElementById('usernameEdit');
  const usernameStatusEl = document.getElementById('usernameStatus');
  const saveBtn = document.getElementById('saveBtn');
  let originalUsername = '';
  let usernameChangeCount = 0;
  let debounceTimer;

  function validateNameField() {
    // Basic validation example: prevent numbers in name fields
    if (/\d/.test(this.value)) {
      this.value = this.value.replace(/\d/g, '');
    }
  }

  async function checkUsernameAvailability() {
    const newUsername = usernameEditInput.value.trim();
    usernameStatusEl.textContent = '';
    usernameStatusEl.className = 'status-message';
    saveBtn.disabled = false; // Enable by default

    if (newUsername === originalUsername) return;
    if (newUsername.length < 3) {
      usernameStatusEl.textContent = 'Username must be at least 3 characters.';
      usernameStatusEl.classList.add('invalid');
      saveBtn.disabled = true;
      return;
    }
    
    const { data, error } = await supabaseClient.from('users').select('id').eq('username', newUsername).single();
    
    if (data) {
      usernameStatusEl.textContent = 'Username is already taken.';
      usernameStatusEl.classList.add('invalid');
      saveBtn.disabled = true;
    } else if (error && error.code !== 'PGRST116') { // PGRST116 = row not found, which is good
      usernameStatusEl.textContent = 'Error checking username.';
      usernameStatusEl.classList.add('invalid');
      saveBtn.disabled = true;
    } else {
      usernameStatusEl.textContent = 'Username is available!';
      usernameStatusEl.classList.add('valid');
    }
  }

  async function loadProfileData(user) {
    originalUsername = user.user_metadata?.username || '';
    usernameEditInput.value = originalUsername;

    const { data: profile } = await supabaseClient.from("users").select("*").eq("id", user.id).single();
    if (profile) {
      document.getElementById("firstName").value = profile.first_name || '';
      document.getElementById("lastName").value = profile.last_name || '';
      document.getElementById("gender").value = profile.gender || '';
      document.getElementById("country").value = profile.country || '';
      document.getElementById("phoneNumber").value = profile.phone_number || '';
      usernameChangeCount = profile.username_change_count || 0;
    }
  }

  document.getElementById("editProfileForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    saveBtn.disabled = true;
    saveBtn.textContent = 'Saving...';
    
    const { data: { user } } = await supabaseClient.auth.getUser();
    const newUsername = usernameEditInput.value.trim();

    if (usernameStatusEl.classList.contains('invalid')) {
      alert('This username is not available.');
      saveBtn.disabled = false;
      saveBtn.textContent = 'Save Changes';
      return;
    }

    let updateMeta = false;
    if (newUsername !== originalUsername) {
      if (usernameChangeCount >= 3) {
        alert("You have reached the limit of 3 username changes.");
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save Changes';
        return;
      }
      const { error: authError } = await supabaseClient.auth.updateUser({ data: { username: newUsername } });
      if (authError) {
        alert("Failed to update username: " + authError.message);
        saveBtn.disabled = false;
        saveBtn.textContent = 'Save Changes';
        return;
      }
      usernameChangeCount++;
      updateMeta = true;
    }

    const updates = {
      id: user.id,
      username: newUsername,
      first_name: document.getElementById("firstName").value.trim(),
      last_name: document.getElementById("lastName").value.trim(),
      gender: document.getElementById("gender").value,
      country: document.getElementById("country").value,
      phone_number: document.getElementById("phoneNumber").value.trim(),
      ...(updateMeta && { username_change_count: usernameChangeCount })
    };

    const { error } = await supabaseClient.from("users").upsert(updates);
    if (error) {
      alert("Profile update failed: " + error.message);
    } else {
      alert("Profile updated successfully!");
      originalUsername = newUsername; // Update the original username after successful save
    }
    saveBtn.disabled = false;
    saveBtn.textContent = 'Save Changes';
  });

  async function initializePage() {
    const user = await verifySession();
    if (user) {
      await loadProfileData(user);
      
      usernameEditInput.addEventListener('input', () => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(checkUsernameAvailability, 500); // Debounce check
      });
      document.getElementById("firstName").addEventListener('input', validateNameField);
      document.getElementById("lastName").addEventListener('input', validateNameField);
    } else {
      document.body.innerHTML = `<div class="edit-profile-card" style="text-align:center;"><h1>Please Log In</h1><a class="btn" href="login.html" style="display:inline-block; margin-top:10px;">Go to Login</a></div>`;
    }
  }

  initializePage();
</script>