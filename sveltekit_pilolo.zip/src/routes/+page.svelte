<style>
    :root {
      --primary-highlight: #ffc107;
      --text-color: #ffffff;
      --animation-duration: 0.6s;
    }

    html, body {
      margin: 0;
      height: 100%;
      overflow: hidden;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background-color: #1a1a2e;
      background-image:
        linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
      background-size: 30px 30px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    #splash-container {
      position: relative;
      display: flex;
      flex-direction: column;
      align-items: center;
      transition: opacity 0.5s ease-out;
    }

    #splash-container.hidden {
      opacity: 0;
    }
    
    #title-line {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    #piloloText {
      display: flex;
      font-size: 72px;
      font-weight: 700;
      color: var(--text-color);
    }

    .letter {
      opacity: 0;
      transform: translateY(50px);
      animation: slideIn var(--animation-duration) cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
    }

    .letter:nth-child(1) { animation-delay: 0s; }
    .letter:nth-child(2) { animation-delay: 0.1s; }
    .letter:nth-child(3) { animation-delay: 0.2s; }
    .letter:nth-child(4) { animation-delay: 0.3s; }
    .letter:nth-child(5) { animation-delay: 0.4s; }
    .letter:nth-child(6) { animation-delay: 0.5s; }
    
    @keyframes slideIn { 
        to { 
            opacity: 1; 
            transform: translateY(0); 
        } 
    }

    .tagline {
        font-size: 18px;
        color: rgba(255, 255, 255, 0.7);
        margin-top: -10px;
        opacity: 0;
        animation: fadeIn 0.8s ease-out forwards;
        animation-delay: 1.2s;
    }

    @keyframes fadeIn {
        to {
            opacity: 1;
        }
    }

    .splash-icon {
        position: absolute;
        width: 50px;
        height: 50px;
        fill: var(--primary-highlight);
        filter: drop-shadow(0 0 8px rgba(255, 193, 7, 0.5));
        opacity: 0;
        transform: scale(0.5);
        animation: popIn var(--animation-duration) cubic-bezier(0.2, 0.8, 0.2, 1) forwards;
    }

    #locationIcon {
        position: relative;
        width: 50px;
        height: 50px;
        animation-delay: 0.8s;
    }
    
    #treasureChestIcon {
        bottom: -25px;
        right: -60px;
        transform: rotate(15deg);
        animation-delay: 1.0s;
    }

    #starIcon {
        top: -25px;
        left: -60px;
        transform: rotate(-15deg);
        animation-delay: 1.1s;
    }

    @keyframes popIn {
        to { 
            opacity: 1; 
            transform: scale(1) rotate(0deg); 
        } 
    }
  </style>
<body>
<div id="splash-container">
<div id="title-line">
<div id="piloloText">
<span class="letter">P</span><span class="letter">i</span><span class="letter">l</span><span class="letter">o</span><span class="letter">l</span><span class="letter">o</span>
</div>
<svg class="splash-icon" id="locationIcon" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 0C7.589 0 4 3.589 4 8c0 4.411 8 16 8 16s8-11.589 8-16c0-4.411-3.589-8-8-8zm0 12c-2.211 0-4-1.789-4-4s1.789-4 4-4 4 1.789 4 4-1.789 4-4 4z"></path></svg>
</div>
<p class="tagline">Dig First or Dig Dirt</p>
<svg class="splash-icon" id="treasureChestIcon" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M20 6h-2.812l-1.423-3.13c-.365-.804-1.209-1.325-2.113-1.325H10.348c-.904 0-1.748.521-2.113 1.325L6.812 6H4c-1.103 0-2 .897-2 2v12c0 1.103.897 2 2 2h16c1.103 0 2-.897 2-2V8c0-1.103-.897-2-2-2zm-8 12.5c-2.481 0-4.5-2.019-4.5-4.5S9.519 9.5 12 9.5s4.5 2.019 4.5 4.5-2.019 4.5-4.5 4.5zM15 6H9V4h6v2z"></path></svg>
<svg class="splash-icon" id="starIcon" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 .587l3.668 7.568 8.332 1.151-6.064 5.828 1.48 8.279L12 19.444l-7.416 4.969 1.48-8.279-6.064-5.828 8.332-1.151z"></path></svg>
</div>
<script>
    async function startApp() {
        // This function from session.js checks for a user.
        // If none is found, it automatically redirects to login.html.
       // const user = await verifySession();

        
            const splashDuration = 2800; // in milliseconds

            setTimeout(() => {
                const splashContainer = document.getElementById('splash-container');
                splashContainer.classList.add('hidden');
                
                // Redirect after the fade-out animation completes
                setTimeout(() => {
                    window.location.href = 'map.html';
                }, 500); // This delay should match the transition duration in CSS
            }, splashDuration);
      
    }

    startApp();
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script defer="" src="session.js"></script>
<script>
    async function startApp() {
        // This function from session.js checks for a user.
        // If none is found, it automatically redirects to login.html.
       // const user = await verifySession();

        
            const splashDuration = 2800; // in milliseconds

            setTimeout(() => {
                const splashContainer = document.getElementById('splash-container');
                splashContainer.classList.add('hidden');
                
                // Redirect after the fade-out animation completes
                setTimeout(() => {
                    window.location.href = 'map.html';
                }, 500); // This delay should match the transition duration in CSS
            }, splashDuration);
      
    }

    startApp();
  </script>