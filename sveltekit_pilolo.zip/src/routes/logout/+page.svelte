<style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background-color: #1a1a2e;
      background-image:
        linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
      background-size: 30px 30px;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
      text-align: center;
    }
    .logout-card {
      background: rgba(20, 20, 30, 0.75);
      backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 16px;
      padding: 40px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      width: 100%;
      max-width: 400px;
    }
    h1 {
      font-size: 28px;
      margin-top: 0;
      margin-bottom: 15px;
    }
    p {
      color: rgba(255, 255, 255, 0.7);
      margin-bottom: 30px;
    }
    .loader {
      margin: 0 auto;
      width: 40px;
      height: 40px;
      border: 4px solid rgba(255, 255, 255, 0.2);
      border-top-color: #fff;
      border-radius: 50%;
      animation: spin 0.8s linear infinite;
    }
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
  </style>
<body>
<div class="logout-card">
<h1 id="logout-title">Logging Out...</h1>
<p id="logout-message">Please wait while we securely sign you out.</p>
<div class="loader"></div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', async () => {
      // Ensure the logout function from session.js is called
    await logout

      // Update the UI to confirm logout
      document.getElementById('logout-title').textContent = 'Logged Out! 👋';
      document.getElementById('logout-message').textContent = 'You have been successfully signed out.';
      
      // Hide the loader
      document.querySelector('.loader').style.display = 'none';
      
      // Redirect to the login page after a short delay
      setTimeout(() => {
        window.location.href = 'login.html';
      }, 2000); // 2-second delay
    });
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="session.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', async () => {
      // Ensure the logout function from session.js is called
    await logout

      // Update the UI to confirm logout
      document.getElementById('logout-title').textContent = 'Logged Out! 👋';
      document.getElementById('logout-message').textContent = 'You have been successfully signed out.';
      
      // Hide the loader
      document.querySelector('.loader').style.display = 'none';
      
      // Redirect to the login page after a short delay
      setTimeout(() => {
        window.location.href = 'login.html';
      }, 2000); // 2-second delay
    });
  </script>