<style>
    body {
      margin: 0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      background: #121212;
      color: #f0f0f0;
      padding: 20px;
    }
    h1 {
      margin-bottom: 20px;
      color: #fff;
    }
    .game-list {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }
    .game-card {
      background: #1e1e1e;
      padding: 15px;
      border-radius: 8px;
      border-left: 5px solid #ffc107; /* Default 'pending' color */
      box-shadow: 0 2px 8px rgba(0,0,0,0.4);
      transition: transform 0.2s ease;
    }
    .game-card:hover {
        transform: translateY(-3px);
    }
    /* Other styles are unchanged */
    .game-card[data-status="live"], .game-card[data-status="in_progress"] { border-left-color: #28a745; }
    .game-card[data-status="completed"] { border-left-color: #6c757d; }
    .game-title { font-size: 18px; font-weight: bold; margin-bottom: 8px; }
    .game-meta { font-size: 14px; color: #ccc; line-height: 1.6; }
    .game-meta strong { color: #f0f0f0; }
    .status-badge { display: inline-block; padding: 4px 8px; border-radius: 12px; font-size: 12px; font-weight: bold; text-transform: capitalize; background-color: #ffc107; color: #121212; }
    .status-badge.live, .status-badge.in_progress { background-color: #28a745; color: #fff; }
    .status-badge.completed { background-color: #6c757d; color: #fff; }
    a.back-link { color: #00aaff; display: inline-block; margin-bottom: 20px; text-decoration: none; font-weight: bold; }
    a.back-link:hover { text-decoration: underline; }
  </style>
<body>
<a class="back-link" href="creategame.html">← Back to Game Creator</a>
<h1>Your Created Games</h1>
<div class="game-list" id="gameList">
<p>Loading your games...</p>
</div>
<script>
    // ✅ Initialize Supabase Client directly in this script
    const SUPABASE_URL = 'https://mgtilfgygzymxiyixjit.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1ndGlsZmd5Z3p5bXhpeWl4aml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE3MjQwMjMsImV4cCI6MjA2NzMwMDAyM30.0Kx5Lfd65QVcnQMOvnxzSnRcoyu2smuUFijzUFu8n_g';
    const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    async function fetchGames() {
      const { data: { session } } = await supabaseClient.auth.getSession();
      const container = document.getElementById('gameList');
  
      if (!session) {
        container.innerHTML = '<p>You must be logged in to view this page.</p>';
        return;
      }
     
      const userId = session.user.id;
      
      const { data, error } = await supabaseClient.rpc('get_creator_dashboard', {
        user_id_input: userId
      });
     
      container.innerHTML = ''; // Clear loading message

      if (error) {
        console.error('Error fetching games:', error);
        container.innerHTML = `<p>Could not load your games. Error: ${error.message}</p>`;
        return;
      }

      if (!data || data.length === 0) {
        container.innerHTML = '<p>You have not created any games yet.</p>';
        return;
      }

      data.forEach(game => {
        const startTime = new Date(game.start_time).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
        const card = document.createElement('div');
        const status = game.status || 'pending';
        card.className = 'game-card';
        card.setAttribute('data-status', status); 
        
        card.innerHTML = `
          <div class="game-title">${game.title || 'Untitled Game'}</div>
          <div class="game-meta">
            📅 <strong>Start:</strong> ${startTime}<br>
            🪙 <strong>Prize:</strong> $${game.total_value || 0}<br>
            🏆 <strong>Treasures:</strong> ${game.treasure_count || 0}<br>
            📈 <strong>Players:</strong> ${game.active_players || 0}<br>
            🌍 <strong>Status:</strong> <span class="status-badge ${status}">${status.replace('_', ' ')}</span>
          </div>
        `;
        container.appendChild(card);
      });
    }

    document.addEventListener('DOMContentLoaded', fetchGames);
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script>
    // ✅ Initialize Supabase Client directly in this script
    const SUPABASE_URL = 'https://mgtilfgygzymxiyixjit.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1ndGlsZmd5Z3p5bXhpeWl4aml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE3MjQwMjMsImV4cCI6MjA2NzMwMDAyM30.0Kx5Lfd65QVcnQMOvnxzSnRcoyu2smuUFijzUFu8n_g';
    const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    async function fetchGames() {
      const { data: { session } } = await supabaseClient.auth.getSession();
      const container = document.getElementById('gameList');
  
      if (!session) {
        container.innerHTML = '<p>You must be logged in to view this page.</p>';
        return;
      }
     
      const userId = session.user.id;
      
      const { data, error } = await supabaseClient.rpc('get_creator_dashboard', {
        user_id_input: userId
      });
     
      container.innerHTML = ''; // Clear loading message

      if (error) {
        console.error('Error fetching games:', error);
        container.innerHTML = `<p>Could not load your games. Error: ${error.message}</p>`;
        return;
      }

      if (!data || data.length === 0) {
        container.innerHTML = '<p>You have not created any games yet.</p>';
        return;
      }

      data.forEach(game => {
        const startTime = new Date(game.start_time).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
        const card = document.createElement('div');
        const status = game.status || 'pending';
        card.className = 'game-card';
        card.setAttribute('data-status', status); 
        
        card.innerHTML = `
          <div class="game-title">${game.title || 'Untitled Game'}</div>
          <div class="game-meta">
            📅 <strong>Start:</strong> ${startTime}<br>
            🪙 <strong>Prize:</strong> $${game.total_value || 0}<br>
            🏆 <strong>Treasures:</strong> ${game.treasure_count || 0}<br>
            📈 <strong>Players:</strong> ${game.active_players || 0}<br>
            🌍 <strong>Status:</strong> <span class="status-badge ${status}">${status.replace('_', ' ')}</span>
          </div>
        `;
        container.appendChild(card);
      });
    }

    document.addEventListener('DOMContentLoaded', fetchGames);
  </script>