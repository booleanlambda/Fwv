<style>
    :root {
      --primary-action-color: #28a745;
      --primary-action-hover: #218838;
      --error-color: #ff8a8a;
    }
    html {
        box-sizing: border-box;
    }
    *, *:before, *:after {
        box-sizing: inherit;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      background-color: #1a1a2e;
      background-image:
        linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px);
      background-size: 30px 30px;
      color: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
    }
    .container {
      background: rgba(20, 20, 30, 0.75);
      backdrop-filter: blur(15px); -webkit-backdrop-filter: blur(15px);
      border: 1px solid rgba(255, 255, 255, 0.15);
      padding: 30px;
      border-radius: 16px;
      box-shadow: 0 8px 32px rgba(0,0,0,0.3);
      width: 100%;
      max-width: 400px;
    }
    .title-container {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 12px;
        margin-bottom: 20px;
    }
    .game-title {
        font-size: 28px;
        text-align: center;
        font-weight: bold;
        color: #fff;
        margin: 0;
        letter-spacing: 1px;
    }
    .title-icon {
        width: 32px;
        height: 32px;
        filter: drop-shadow(0 0 5px rgba(255, 200, 0, 0.7));
    }
    h2 {
        text-align: center;
        margin-top: 0;
        margin-bottom: 30px;
        color: rgba(255, 255, 255, 0.7);
        font-weight: 500;
    }
    label {
        font-weight: 500;
        margin-top: 15px;
        display: block;
        font-size: 14px;
        color: rgba(255, 255, 255, 0.8);
    }
    input[type="text"], input[type="email"], input[type="password"] {
        width: 100%;
        padding: 12px;
        margin-top: 8px;
        border-radius: 8px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        background: rgba(255, 255, 255, 0.1);
        color: #fff;
        font-size: 16px;
        transition: border-color 0.2s, box-shadow 0.2s;
    }
    input:focus {
        outline: none;
        border-color: var(--primary-action-color);
        box-shadow: 0 0 0 3px rgba(40, 167, 69, 0.3);
    }
    input::placeholder {
      color: rgba(255, 255, 255, 0.5);
    }
    input:disabled {
        background-color: rgba(255, 255, 255, 0.05);
        cursor: not-allowed;
    }
    .btn {
        margin-top: 25px;
        width: 100%;
        padding: 12px;
        background-color: var(--primary-action-color);
        color: white;
        font-size: 16px;
        font-weight: bold;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.2s;
        display: flex;
        justify-content: center;
        align-items: center;
        position: relative;
        min-height: 44px;
    }
    .btn:hover:not(:disabled) {
        background-color: var(--primary-action-hover);
    }
    .btn:disabled {
        background-color: #555;
        cursor: wait;
    }
    .btn .loader {
        width: 20px;
        height: 20px;
        border: 3px solid rgba(255, 255, 255, 0.5);
        border-top-color: #fff;
        border-radius: 50%;
        animation: spin 0.6s linear infinite;
        display: none;
    }
    .btn.loading .loader { display: block; }
    .btn.loading .btn-text { visibility: hidden; }
    .switch { text-align: center; margin-top: 20px; font-size: 14px; color: rgba(255, 255, 255, 0.7);}
    .switch a { color: #66bfff; text-decoration: none; cursor: pointer; font-weight: 600; }
    .switch a:hover { text-decoration: underline; }
    .password-toggle { display: flex; align-items: center; gap: 8px; margin-top: 10px; font-size: 14px; color: rgba(255, 255, 255, 0.7);}
    .error { color: var(--error-color); font-size: 14px; margin-top: 12px; text-align: center; min-height: 20px; font-weight: 500;}
    @keyframes spin { to { transform: rotate(360deg); } }
  </style>
<body>
<div class="container">
<div id="loginSection">
<div class="title-container">
<svg class="title-icon" fill="#ffc107" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"></path></svg>
<h1 class="game-title">Pilolo</h1>
</div>
<h2>Welcome Back</h2>
<form id="loginForm">
<label for="loginEmail">Email</label>
<input id="loginEmail" placeholder="Enter your email" required="" type="email"/>
<label for="loginPassword">Password</label>
<input id="loginPassword" placeholder="Enter your password" required="" type="password"/>
<div class="password-toggle"><input id="showLoginPass" type="checkbox"/><label for="showLoginPass">Show Password</label></div>
<div class="error" id="loginError"></div>
<button class="btn" id="loginBtn">
<span class="btn-text">Login</span>
<div class="loader"></div>
</button>
</form>
<div class="switch">Don't have an account? <a id="switchToRegister">Register</a></div>
</div>
<div id="registerSection" style="display: none;">
<div class="title-container">
<svg class="title-icon" fill="#ffc107" viewbox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"></path></svg>
<h1 class="game-title">Pilolo</h1>
</div>
<h2>Create Account</h2>
<form id="registerForm">
<label for="regUsername">Username</label>
<input disabled="" id="regUsername" type="text"/>
<label for="regEmail">Email</label>
<input id="regEmail" placeholder="your@email.com" required="" type="email"/>
<label for="regPassword">Password</label>
<input id="regPassword" placeholder="At least 6 characters" required="" type="password"/>
<label for="regPasswordConfirm">Confirm Password</label>
<input id="regPasswordConfirm" placeholder="Repeat password" required="" type="password"/>
<div class="password-toggle"><input id="showRegPass" type="checkbox"/><label for="showRegPass">Show Password</label></div>
<div class="error" id="regError"></div>
<button class="btn" id="registerBtn">
<span class="btn-text">Register</span>
<div class="loader"></div>
</button>
</form>
<div class="switch">Already have an account? <a id="switchToLogin">Login</a></div>
</div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Local client is removed. We now use the global 'supabaseClient' from session.js

        const el = id => document.getElementById(id);

        const toggleButtonLoading = (button, isLoading) => {
            button.disabled = isLoading;
            button.classList.toggle('loading', isLoading);
        };

        const generateUniqueUsername = () => `user_${Math.random().toString(36).substring(2, 9)}`;
        
        el('switchToRegister').addEventListener('click', () => {
            el('loginSection').style.display = 'none';
            el('registerSection').style.display = 'block';
            el('regUsername').value = generateUniqueUsername();
        });

        el('switchToLogin').addEventListener('click', () => {
            el('registerSection').style.display = 'none';
            el('loginSection').style.display = 'block';
        });

        el('showLoginPass').addEventListener('change', () => { el('loginPassword').type = el('showLoginPass').checked ? 'text' : 'password'; });
        el('showRegPass').addEventListener('change', () => {
            const newType = el('showRegPass').checked ? 'text' : 'password';
            el('regPassword').type = newType;
            el('regPasswordConfirm').type = newType;
        });

        el('loginForm').addEventListener('submit', handleLogin);
        el('registerForm').addEventListener('submit', handleRegister);
        
        async function handleLogin(e) {
            e.preventDefault();
            const email = el('loginEmail').value.trim().toLowerCase();
            const password = el('loginPassword').value.trim();
            const errorEl = el('loginError');
            const button = el('loginBtn');
            errorEl.textContent = ''; 

            if (!email || !password) {
                errorEl.textContent = 'Email and password are required.';
                return;
            }
            toggleButtonLoading(button, true);
            try {
                // Use the global supabaseClient
                const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
                if (error) throw new Error('Invalid login credentials.');

                // **AMENDMENT:** Cache the user data in sessionStorage for faster page loads
                sessionStorage.setItem('piloloUser', JSON.stringify(data.user));

                // Redirect to the splash screen for a consistent user experience
                window.location.href = 'index.html'; 

            } catch (error) {
                errorEl.textContent = error.message;
            } finally {
                toggleButtonLoading(button, false);
            }
        }

        async function handleRegister(e) {
            e.preventDefault();
            const username = el('regUsername').value.trim();
            const email = el('regEmail').value.trim().toLowerCase();
            const password = el('regPassword').value.trim();
            const passwordConfirm = el('regPasswordConfirm').value.trim();
            const errorEl = el('regError');
            const button = el('registerBtn');
            errorEl.textContent = '';

            if (!/^\S+@\S+\.\S+$/.test(email)) { errorEl.textContent = 'Please enter a valid email.'; return; }
            if (password.length < 6) { errorEl.textContent = 'Password must be at least 6 characters.'; return; }
            if (password !== passwordConfirm) { errorEl.textContent = 'Passwords do not match.'; return; }

            toggleButtonLoading(button, true);

            try {
                // Use the global supabaseClient
                const { error } = await supabaseClient.auth.signUp({
                    email, password, options: { data: { username } }
                });

                if (error) {
                    throw new Error(error.message.includes('User already registered') ? 'This email is already in use.' : 'Signup failed. Please try again.');
                }
                
                alert('Signup successful! Please check your email to verify your account before logging in.');
                el('switchToLogin').click();
            } catch (error) {
                errorEl.textContent = error.message;
            } finally {
                toggleButtonLoading(button, false);
            }
        }
    });
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="session.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        // Local client is removed. We now use the global 'supabaseClient' from session.js

        const el = id => document.getElementById(id);

        const toggleButtonLoading = (button, isLoading) => {
            button.disabled = isLoading;
            button.classList.toggle('loading', isLoading);
        };

        const generateUniqueUsername = () => `user_${Math.random().toString(36).substring(2, 9)}`;
        
        el('switchToRegister').addEventListener('click', () => {
            el('loginSection').style.display = 'none';
            el('registerSection').style.display = 'block';
            el('regUsername').value = generateUniqueUsername();
        });

        el('switchToLogin').addEventListener('click', () => {
            el('registerSection').style.display = 'none';
            el('loginSection').style.display = 'block';
        });

        el('showLoginPass').addEventListener('change', () => { el('loginPassword').type = el('showLoginPass').checked ? 'text' : 'password'; });
        el('showRegPass').addEventListener('change', () => {
            const newType = el('showRegPass').checked ? 'text' : 'password';
            el('regPassword').type = newType;
            el('regPasswordConfirm').type = newType;
        });

        el('loginForm').addEventListener('submit', handleLogin);
        el('registerForm').addEventListener('submit', handleRegister);
        
        async function handleLogin(e) {
            e.preventDefault();
            const email = el('loginEmail').value.trim().toLowerCase();
            const password = el('loginPassword').value.trim();
            const errorEl = el('loginError');
            const button = el('loginBtn');
            errorEl.textContent = ''; 

            if (!email || !password) {
                errorEl.textContent = 'Email and password are required.';
                return;
            }
            toggleButtonLoading(button, true);
            try {
                // Use the global supabaseClient
                const { data, error } = await supabaseClient.auth.signInWithPassword({ email, password });
                if (error) throw new Error('Invalid login credentials.');

                // **AMENDMENT:** Cache the user data in sessionStorage for faster page loads
                sessionStorage.setItem('piloloUser', JSON.stringify(data.user));

                // Redirect to the splash screen for a consistent user experience
                window.location.href = 'index.html'; 

            } catch (error) {
                errorEl.textContent = error.message;
            } finally {
                toggleButtonLoading(button, false);
            }
        }

        async function handleRegister(e) {
            e.preventDefault();
            const username = el('regUsername').value.trim();
            const email = el('regEmail').value.trim().toLowerCase();
            const password = el('regPassword').value.trim();
            const passwordConfirm = el('regPasswordConfirm').value.trim();
            const errorEl = el('regError');
            const button = el('registerBtn');
            errorEl.textContent = '';

            if (!/^\S+@\S+\.\S+$/.test(email)) { errorEl.textContent = 'Please enter a valid email.'; return; }
            if (password.length < 6) { errorEl.textContent = 'Password must be at least 6 characters.'; return; }
            if (password !== passwordConfirm) { errorEl.textContent = 'Passwords do not match.'; return; }

            toggleButtonLoading(button, true);

            try {
                // Use the global supabaseClient
                const { error } = await supabaseClient.auth.signUp({
                    email, password, options: { data: { username } }
                });

                if (error) {
                    throw new Error(error.message.includes('User already registered') ? 'This email is already in use.' : 'Signup failed. Please try again.');
                }
                
                alert('Signup successful! Please check your email to verify your account before logging in.');
                el('switchToLogin').click();
            } catch (error) {
                errorEl.textContent = error.message;
            } finally {
                toggleButtonLoading(button, false);
            }
        }
    });
  </script>