<style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      margin: 0;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: #fff;
    }
    header {
      display: flex; justify-content: space-between; align-items: center;
      padding: 10px 15px; background: rgba(0, 0, 0, 0.25);
    }
    header h1 { margin: 0; font-size: 18px; }
    header a { color: #fff; text-decoration: none; font-weight: bold; }
    .container {
      width: 100%; max-width: 420px; padding: 20px; box-sizing: border-box;
      margin: 0 auto;
    }
    .wallet-box {
      background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px);
      padding: 25px; border-radius: 16px; margin-top: 20px;
    }
    .wallet-section {
      margin-bottom: 25px; padding-bottom: 15px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.2);
    }
    .wallet-section:last-of-type { border-bottom: none; }
    .label {
      font-weight: bold; font-size: 14px;
      color: rgba(255, 255, 255, 0.8); margin-bottom: 8px; display: block;
    }
    .value { font-size: 28px; font-weight: bold; margin-bottom: 4px; }
    .button-group { display: flex; flex-direction: column; gap: 12px; }
    button {
      width: 100%; padding: 12px; background: rgba(255, 255, 255, 0.2);
      color: white; border: none; border-radius: 8px; cursor: pointer;
      font-weight: bold; transition: background-color 0.2s, opacity 0.2s;
    }
    button:hover:not(:disabled) { background: rgba(255, 255, 255, 0.3); }
    button:disabled { cursor: not-allowed; opacity: 0.6; }#paymentModalOverlay, #transactionModalOverlay {
  display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%;
  background: rgba(0, 0, 0, 0.6); justify-content: center; align-items: center; z-index: 1000;
}
.modal {
  background: linear-gradient(135deg, #4e54c8, #8f94fb);
  padding: 25px; border-radius: 16px; width: 90%; max-width: 400px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.3); color: white;
}
.modal h2 { margin-top: 0; }
.modal-buttons { display: flex; gap: 10px; margin-top: 20px; }
.modal-buttons button:first-child { background: #6c757d; }
.modal-buttons button:last-child { background: #28a745; }
.input-group input {
  width: 100%; padding: 10px; border-radius: 6px; margin-top: 8px;
  background: rgba(255,255,255,0.2); border: 1px solid #ccc; color: white;
}

  </style>
<body>
<header>
<h1>My Wallet</h1>
<a href="profile.html" id="exitBtn">Exit</a>
</header>
<div class="container">
<div class="wallet-box">
<div class="wallet-section">
<span class="label">Current Balance</span>
<div class="value" id="walletBalance">Loading...</div>
</div>
<div class="wallet-section">
<span class="label">Default Payment Method</span>
<div class="value" id="paymentType">Loading...</div>
<div id="paymentDetails"></div>
</div>
<div class="button-group">
<button onclick="openTransactionModal('add')">Add Money</button>
<button onclick="openTransactionModal('withdraw')">Withdraw Money</button>
<button onclick="openPaymentModal()">Change Payment Method</button>
</div>
</div>
</div> <!-- Payment Method Modal --> <div id="paymentModalOverlay">
<div class="modal">
<h2>Change Payment Method</h2>
<form id="paymentForm">
<div>
<label><input checked="" name="paymentMethod" type="radio" value="paypal"/> PayPal</label>
<label><input name="paymentMethod" type="radio" value="mobile"/> Mobile Money</label>
</div>
<div class="input-group" id="paypalInputGroup">
<label>Email</label>
<input id="paypalEmail" placeholder="email" type="email"/>
<input id="paypalEmailConfirm" placeholder="Confirm email" type="email"/>
</div>
<div class="input-group" id="mobileInputGroup" style="display:none;">
<label>Mobile Number</label>
<input id="mobileNumber" placeholder="number" type="tel"/>
<input id="mobileNumberConfirm" placeholder="Confirm number" type="tel"/>
</div>
<div class="modal-buttons">
<button onclick="closeModal('paymentModalOverlay')" type="button">Cancel</button>
<button type="submit">Save</button>
</div>
</form>
</div>
</div> <!-- Add/Withdraw Modal --> <div id="transactionModalOverlay">
<div class="modal">
<h2 id="transactionTitle">Amount</h2>
<div class="input-group">
<input id="amountInput" min="0.01" placeholder="Enter amount" step="0.01" type="number"/>
</div>
<div class="modal-buttons">
<button onclick="closeModal('transactionModalOverlay')">Cancel</button>
<button onclick="processTransaction()">Confirm</button>
</div>
</div>
</div> <script>
    let currentWalletData = null;
    let currentAction = null;

    async function loadWallet() {
      const user = await verifySession();
      if (!user) return;
      const username = user.user_metadata?.username;
      const balanceEl = document.getElementById("walletBalance");
      const typeEl = document.getElementById("paymentType");
      const detailEl = document.getElementById("paymentDetails");

      let { data, error } = await supabaseClient
        .from('users')
        .select('wallet, payment_type, paypal_username, mobile_number')
        .eq('id', user.id)
        .maybeSingle();

      if (!data) {
        await supabaseClient.from('users').insert({
          id: user.id,
          username: username,
          email: user.email,
          wallet: 0
        });
        ({ data } = await supabaseClient
          .from('users')
          .select('wallet, payment_type, paypal_username, mobile_number')
          .eq('id', user.id)
          .maybeSingle());
      }

      currentWalletData = data;
      balanceEl.textContent = `$${(data.wallet ?? 0).toFixed(2)}`;
      typeEl.textContent = data.payment_type ? data.payment_type.toUpperCase() : "None";
      detailEl.textContent = data.payment_type === 'paypal'
        ? `Account: ${data.paypal_username || 'Not set'}`
        : data.payment_type === 'mobile'
          ? `Number: ${data.mobile_number || 'Not set'}`
          : "No payment method set.";
    }

    function openTransactionModal(action) {
      currentAction = action;
      document.getElementById("transactionTitle").innerText = action === 'add' ? 'Add Funds' : 'Withdraw Funds';
      document.getElementById("transactionModalOverlay").style.display = 'flex';
    }

    async function processTransaction() {
      const amount = parseFloat(document.getElementById("amountInput").value);
      if (isNaN(amount) || amount <= 0) return alert("Invalid amount.");
      const user = await verifySession();
      if (!user) return;

      const current = currentWalletData?.wallet ?? 0;
      const newBalance = currentAction === 'add' ? current + amount : current - amount;

      if (currentAction === 'withdraw') {
        if (amount > current) return alert("Insufficient funds.");
        if (!currentWalletData.payment_type) return alert("Set a payment method first.");

        if (currentWalletData.payment_type === 'paypal') {
          const email = currentWalletData.paypal_username;
          if (!email) return alert("No PayPal email set.");
          alert(`\uD83D\uDCB8 Transferring $${amount.toFixed(2)} to PayPal: ${email}`);
        } else if (currentWalletData.payment_type === 'mobile') {
          const mobile = currentWalletData.mobile_number;
          if (!mobile) return alert("No mobile number set.");
          alert(`\uD83D\uDCB2 Sending $${amount.toFixed(2)} to Mobile Money number: ${mobile}`);
        } else return alert("Unsupported payment method.");
      }

      const { error } = await supabaseClient
        .from('users')
        .update({ wallet: newBalance })
        .eq('id', user.id);

      if (error) debugAlert(error, "wallet update");
      else alert("✅ Transaction successful!");

      closeModal('transactionModalOverlay');
      loadWallet();
    }

    function openPaymentModal() {
      const type = currentWalletData?.payment_type || 'paypal';
      document.querySelector(`[value=${type}]`).checked = true;
      togglePaymentInput(type);
      document.getElementById("paymentModalOverlay").style.display = 'flex';
    }

    function closeModal(id) {
      document.getElementById(id).style.display = 'none';
    }

    function togglePaymentInput(method) {
      document.getElementById('paypalInputGroup').style.display = method === 'paypal' ? 'block' : 'none';
      document.getElementById('mobileInputGroup').style.display = method === 'mobile' ? 'block' : 'none';
    }

    document.querySelectorAll('[name="paymentMethod"]').forEach(r => {
      r.addEventListener('change', e => togglePaymentInput(e.target.value));
    });

    document.getElementById("paymentForm").addEventListener('submit', async (e) => {
      e.preventDefault();
      const method = document.querySelector('[name="paymentMethod"]:checked').value;
      const email = document.getElementById("paypalEmail").value.trim();
      const email2 = document.getElementById("paypalEmailConfirm").value.trim();
      const mobile = document.getElementById("mobileNumber").value.trim();
      const mobile2 = document.getElementById("mobileNumberConfirm").value.trim();
      if (method === 'paypal' && email !== email2) return alert("Emails don't match.");
      if (method === 'mobile' && mobile !== mobile2) return alert("Numbers don't match.");
      const user = await verifySession();
      const { error } = await supabaseClient.from('users').update({
        payment_type: method,
        paypal_username: method === 'paypal' ? email : null,
        mobile_number: method === 'mobile' ? mobile : null
      }).eq('id', user.id);
      if (error) alert("Failed: " + error.message);
      else {
        alert("Payment method updated.");
        closeModal('paymentModalOverlay');
        loadWallet();
      }
    });

    document.addEventListener('DOMContentLoaded', () => {
      const from = new URLSearchParams(location.search).get("from");
      document.getElementById("exitBtn").href = from === "creategame" ? "creategame.html" : "profile.html";
      loadWallet();
    });
  </script></body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="session.js"></script>
<script src="debug.js"></script>
<script>
    let currentWalletData = null;
    let currentAction = null;

    async function loadWallet() {
      const user = await verifySession();
      if (!user) return;
      const username = user.user_metadata?.username;
      const balanceEl = document.getElementById("walletBalance");
      const typeEl = document.getElementById("paymentType");
      const detailEl = document.getElementById("paymentDetails");

      let { data, error } = await supabaseClient
        .from('users')
        .select('wallet, payment_type, paypal_username, mobile_number')
        .eq('id', user.id)
        .maybeSingle();

      if (!data) {
        await supabaseClient.from('users').insert({
          id: user.id,
          username: username,
          email: user.email,
          wallet: 0
        });
        ({ data } = await supabaseClient
          .from('users')
          .select('wallet, payment_type, paypal_username, mobile_number')
          .eq('id', user.id)
          .maybeSingle());
      }

      currentWalletData = data;
      balanceEl.textContent = `$${(data.wallet ?? 0).toFixed(2)}`;
      typeEl.textContent = data.payment_type ? data.payment_type.toUpperCase() : "None";
      detailEl.textContent = data.payment_type === 'paypal'
        ? `Account: ${data.paypal_username || 'Not set'}`
        : data.payment_type === 'mobile'
          ? `Number: ${data.mobile_number || 'Not set'}`
          : "No payment method set.";
    }

    function openTransactionModal(action) {
      currentAction = action;
      document.getElementById("transactionTitle").innerText = action === 'add' ? 'Add Funds' : 'Withdraw Funds';
      document.getElementById("transactionModalOverlay").style.display = 'flex';
    }

    async function processTransaction() {
      const amount = parseFloat(document.getElementById("amountInput").value);
      if (isNaN(amount) || amount <= 0) return alert("Invalid amount.");
      const user = await verifySession();
      if (!user) return;

      const current = currentWalletData?.wallet ?? 0;
      const newBalance = currentAction === 'add' ? current + amount : current - amount;

      if (currentAction === 'withdraw') {
        if (amount > current) return alert("Insufficient funds.");
        if (!currentWalletData.payment_type) return alert("Set a payment method first.");

        if (currentWalletData.payment_type === 'paypal') {
          const email = currentWalletData.paypal_username;
          if (!email) return alert("No PayPal email set.");
          alert(`\uD83D\uDCB8 Transferring $${amount.toFixed(2)} to PayPal: ${email}`);
        } else if (currentWalletData.payment_type === 'mobile') {
          const mobile = currentWalletData.mobile_number;
          if (!mobile) return alert("No mobile number set.");
          alert(`\uD83D\uDCB2 Sending $${amount.toFixed(2)} to Mobile Money number: ${mobile}`);
        } else return alert("Unsupported payment method.");
      }

      const { error } = await supabaseClient
        .from('users')
        .update({ wallet: newBalance })
        .eq('id', user.id);

      if (error) debugAlert(error, "wallet update");
      else alert("✅ Transaction successful!");

      closeModal('transactionModalOverlay');
      loadWallet();
    }

    function openPaymentModal() {
      const type = currentWalletData?.payment_type || 'paypal';
      document.querySelector(`[value=${type}]`).checked = true;
      togglePaymentInput(type);
      document.getElementById("paymentModalOverlay").style.display = 'flex';
    }

    function closeModal(id) {
      document.getElementById(id).style.display = 'none';
    }

    function togglePaymentInput(method) {
      document.getElementById('paypalInputGroup').style.display = method === 'paypal' ? 'block' : 'none';
      document.getElementById('mobileInputGroup').style.display = method === 'mobile' ? 'block' : 'none';
    }

    document.querySelectorAll('[name="paymentMethod"]').forEach(r => {
      r.addEventListener('change', e => togglePaymentInput(e.target.value));
    });

    document.getElementById("paymentForm").addEventListener('submit', async (e) => {
      e.preventDefault();
      const method = document.querySelector('[name="paymentMethod"]:checked').value;
      const email = document.getElementById("paypalEmail").value.trim();
      const email2 = document.getElementById("paypalEmailConfirm").value.trim();
      const mobile = document.getElementById("mobileNumber").value.trim();
      const mobile2 = document.getElementById("mobileNumberConfirm").value.trim();
      if (method === 'paypal' && email !== email2) return alert("Emails don't match.");
      if (method === 'mobile' && mobile !== mobile2) return alert("Numbers don't match.");
      const user = await verifySession();
      const { error } = await supabaseClient.from('users').update({
        payment_type: method,
        paypal_username: method === 'paypal' ? email : null,
        mobile_number: method === 'mobile' ? mobile : null
      }).eq('id', user.id);
      if (error) alert("Failed: " + error.message);
      else {
        alert("Payment method updated.");
        closeModal('paymentModalOverlay');
        loadWallet();
      }
    });

    document.addEventListener('DOMContentLoaded', () => {
      const from = new URLSearchParams(location.search).get("from");
      document.getElementById("exitBtn").href = from === "creategame" ? "creategame.html" : "profile.html";
      loadWallet();
    });
  </script>