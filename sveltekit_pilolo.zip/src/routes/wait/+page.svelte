<style>
        body { background-color: #1a1a1a; color: white; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; text-align: center; }
        .container { max-width: 400px; }
        h1 { font-size: 24px; color: #ffcc00; }
        p { font-size: 16px; color: #ccc; }
    </style>
<body>
<div class="container">
<h1>Setting Up Games...</h1>
<p>We are starting new games and ending others. Please wait a moment. You will be redirected automatically.</p>
</div>
</body>
<script defer="" src="clock.js"></script>