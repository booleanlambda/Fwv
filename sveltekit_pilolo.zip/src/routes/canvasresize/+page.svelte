<style>
    body { font-family: sans-serif; text-align: center; padding: 20px; }
    video, canvas { display: none; }
    #progressContainer {
      width: 80%;
      margin: 20px auto;
      background: #eee;
      height: 20px;
      border-radius: 10px;
      overflow: hidden;
      display: none;
    }
    #progressBar {
      height: 100%;
      width: 0%;
      background: #4caf50;
      transition: width 0.2s ease;
    }
    #startBtn {
      display: none;
      margin-top: 15px;
      padding: 10px 20px;
      font-size: 16px;
      background: #007bff;
      color: white;
      border: none;
      border-radius: 6px;
    }
  </style>
<body>
<h2>Resize Entire Video to 10% (with Audio)</h2>
<input accept="video/*" id="upload" type="file"/>
<button id="startBtn">Start Processing</button>
<div id="progressContainer">
<div id="progressBar"></div>
</div>
<video controls="" id="sourceVideo"></video>
<canvas id="canvas"></canvas>
<script>
    const upload = document.getElementById('upload');
    const startBtn = document.getElementById('startBtn');
    const video = document.getElementById('sourceVideo');
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    const progressBar = document.getElementById('progressBar');
    const progressContainer = document.getElementById('progressContainer');

    let fileURL = null;

    upload.addEventListener('change', function () {
      const file = this.files[0];
      if (!file) return;

      if (fileURL) URL.revokeObjectURL(fileURL);

      fileURL = URL.createObjectURL(file);
      video.src = fileURL;
      video.muted = true; // required for autoplay on mobile
      startBtn.style.display = 'inline-block';
      progressContainer.style.display = 'none';
    });

    startBtn.addEventListener('click', async function () {
      startBtn.style.display = 'none';
      progressBar.style.width = '0%';
      progressContainer.style.display = 'block';

      try {
        await video.play();
      } catch (err) {
        alert("Please tap the video to play first.");
        return;
      }

      // Resize to 10%
      const scale = 0.1;
      canvas.width = video.videoWidth * scale;
      canvas.height = video.videoHeight * scale;

      const canvasStream = canvas.captureStream();
      const videoAudioStream = video.captureStream();
      const audioTracks = videoAudioStream.getAudioTracks();
      audioTracks.forEach(track => canvasStream.addTrack(track));

      const chunks = [];
      const recorder = new MediaRecorder(canvasStream, { mimeType: 'video/webm' });

      recorder.ondataavailable = e => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const blobUrl = URL.createObjectURL(blob);

        // Auto-download
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = 'resized-10percent.webm';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(blobUrl);

        progressContainer.style.display = 'none';
        video.pause();
      };

      recorder.start();

      const totalDuration = video.duration * 1000;
      const startTime = performance.now();

      function drawFrame() {
        const now = performance.now();
        const elapsed = now - startTime;

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const progress = Math.min((elapsed / totalDuration) * 100, 100);
        progressBar.style.width = `${progress}%`;

        if (!video.ended) {
          requestAnimationFrame(drawFrame);
        } else {
          recorder.stop();
          URL.revokeObjectURL(fileURL);
        }
      }

      drawFrame();
    });
  </script>
</body>
<script>
    const upload = document.getElementById('upload');
    const startBtn = document.getElementById('startBtn');
    const video = document.getElementById('sourceVideo');
    const canvas = document.getElementById('canvas');
    const ctx = canvas.getContext('2d');
    const progressBar = document.getElementById('progressBar');
    const progressContainer = document.getElementById('progressContainer');

    let fileURL = null;

    upload.addEventListener('change', function () {
      const file = this.files[0];
      if (!file) return;

      if (fileURL) URL.revokeObjectURL(fileURL);

      fileURL = URL.createObjectURL(file);
      video.src = fileURL;
      video.muted = true; // required for autoplay on mobile
      startBtn.style.display = 'inline-block';
      progressContainer.style.display = 'none';
    });

    startBtn.addEventListener('click', async function () {
      startBtn.style.display = 'none';
      progressBar.style.width = '0%';
      progressContainer.style.display = 'block';

      try {
        await video.play();
      } catch (err) {
        alert("Please tap the video to play first.");
        return;
      }

      // Resize to 10%
      const scale = 0.1;
      canvas.width = video.videoWidth * scale;
      canvas.height = video.videoHeight * scale;

      const canvasStream = canvas.captureStream();
      const videoAudioStream = video.captureStream();
      const audioTracks = videoAudioStream.getAudioTracks();
      audioTracks.forEach(track => canvasStream.addTrack(track));

      const chunks = [];
      const recorder = new MediaRecorder(canvasStream, { mimeType: 'video/webm' });

      recorder.ondataavailable = e => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        const blobUrl = URL.createObjectURL(blob);

        // Auto-download
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = 'resized-10percent.webm';
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(blobUrl);

        progressContainer.style.display = 'none';
        video.pause();
      };

      recorder.start();

      const totalDuration = video.duration * 1000;
      const startTime = performance.now();

      function drawFrame() {
        const now = performance.now();
        const elapsed = now - startTime;

        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const progress = Math.min((elapsed / totalDuration) * 100, 100);
        progressBar.style.width = `${progress}%`;

        if (!video.ended) {
          requestAnimationFrame(drawFrame);
        } else {
          recorder.stop();
          URL.revokeObjectURL(fileURL);
        }
      }

      drawFrame();
    });
  </script>