<style>
    body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; overflow: hidden; }
    #map { position: absolute; top: 0; bottom: 0; width: 100%; }
    .ui-panel {
      position: absolute; z-index: 2;
      background: rgba(20, 20, 30, 0.75);
      backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
      color: white; border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
    }
    #header {
      top: 10px; left: 10px; right: 10px; padding: 8px 12px;
      border-radius: 12px; display: flex; justify-content: space-between; align-items: center;
    }
    #header h2 { margin: 0; font-size: 16px; }
    #profileBtn { padding: 8px; background: rgba(255,255,255,0.2); border-radius: 50%; display: flex; cursor: pointer; }
    #bottom-bar {
      bottom: 20px; left: 50%; transform: translateX(-50%); padding: 10px;
      border-radius: 50px; display: flex; align-items: center; gap: 10px;
    }
    #digButton {
      padding: 12px 24px; font-size: 18px; font-weight: bold; color: white; border: none; border-radius: 30px;
      background-color: #555; cursor: pointer; transition: background-color 0.2s;
    }
    #digButton.enabled { background-color: #ffcc00; color: #111; }
    #chatBtn { background: none; border: none; color: white; cursor: pointer; padding: 8px; }
    #distance-info {
        position: absolute; bottom: 100px; left: 50%; transform: translateX(-50%);
        background: rgba(0,0,0,0.6); color: #ffc107; padding: 8px 16px;
        border-radius: 20px; font-size: 14px; font-weight: bold; z-index: 2; display: none;
    }
    #chatBox {
      position: absolute; bottom: 90px; right: 10px; z-index: 3; width: 90%;
      max-width: 300px; height: 350px; border-radius: 16px; display: none;
      flex-direction: column; overflow: hidden;
    }
    #chatMessages { flex: 1; padding: 10px; overflow-y: auto; font-size: 14px; }
    #chatMessages div { margin-bottom: 8px; line-height: 1.4; }
    #chatMessages b { color: #ffc107; }
    .chat-timestamp { font-size: 11px; color: #888; margin-left: 8px; }
    #chatInput { display: flex; border-top: 1px solid rgba(255, 255, 255, 0.1); }
    #chatInput input { flex: 1; padding: 12px; border: none; background: transparent; color: white; }
    #chatInput button { background: #ffcc00; color: #111; border: none; padding: 0 15px; font-weight: bold; cursor: pointer; }
    .mapboxgl-popup-content {
      background: rgba(20, 20, 30, 0.85); backdrop-filter: blur(10px);
      color: white; border-radius: 12px; padding: 15px; max-width: 240px;
    }
    .game-popup h3 { margin: 0 0 5px; }
    .game-popup p { margin: 0 0 10px; font-size: 14px; color: #ccc; }
    .game-popup .game-creator { font-size: 12px; color: #ccc; margin-top: -5px; margin-bottom: 15px; }
    .game-popup .time-info { font-weight: bold; color: #ffc107; margin-bottom: 15px;}
    .game-popup button {
      width: 100%; padding: 10px; border: none; border-radius: 8px;
      font-weight: bold; color: #fff; background-color: #28a745; cursor: pointer;
    }
    .game-popup .button-group { display: flex; gap: 10px; }
    .game-popup .chat-btn { background-color: #0d6efd; }
    .game-popup .exit-btn { background-color: #dc3545; }
  </style>
<body>
<div id="map"></div>
<div class="ui-panel" id="header">
<h2 id="gameTitle">Explore Games</h2>
<div id="profileBtn" onclick="window.location.href='profile.html'">
<svg fill="white" height="24" viewbox="0 0 24 24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M12 2a5 5 0 110 10 5 5 0 010-10zm0 12c-3.33 0-10 1.67-10 5v3h20v-3c0-3.33-6.67-5-10-5z"></path></svg>
</div>
</div>
<div id="distance-info"></div>
<div class="ui-panel" id="bottom-bar">
<button id="digButton">DIG</button>
<button id="chatBtn" onclick="toggleChat()">
<svg fill="white" height="28" viewbox="0 0 24 24" width="28" xmlns="http://www.w3.org/2000/svg"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"></path></svg>
</button>
</div>
<div class="ui-panel" id="chatBox">
<div id="chatMessages"><div>No game selected.</div></div>
<form id="chatForm">
<div id="chatInput">
<input autocomplete="off" id="chatText" placeholder="Say something..." type="text"/>
<button type="submit">Send</button>
</div>
</form>
</div>
<script>
    const SUPABASE_URL = 'https://mgtilfgygzymxiyixjit.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1ndGlsZmd5Z3p5bXhpeWl4aml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE3MjQwMjMsImV4cCI6MjA2NzMwMDAyM30.0Kx5Lfd65QVcnQMOvnxzSnRcoyu2smuUFijzUFu8n_g';
    const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    let map, currentUser, playerLocation, selectedGame = null, chatChannel = null, userMarker = null;
    let gameMarkers = {};
    const digButton = document.getElementById('digButton');
    const distanceInfo = document.getElementById('distance-info');
    const gameTitleEl = document.getElementById('gameTitle');
    const chatBox = document.getElementById('chatBox');
    const chatMessagesEl = document.getElementById('chatMessages');
    const chatForm = document.getElementById('chatForm');

    async function verifySession() {
        try {
            const { data: { session } } = await supabaseClient.auth.getSession();
            if (!session) { window.location.href = 'login.html'; return null; }
            return session.user;
        } catch (e) {
            console.error("Session verification failed:", e);
            window.location.href = 'login.html';
            return null;
        }
    }
    
    async function handleGameInteraction(gameId, gameCoords) {
        if (!currentUser) return Swal.fire('Error', 'You must be logged in.', 'error');

        // The client-side distance check is still here for good user experience.
        if (!playerLocation) return Swal.fire('Location Error', 'Could not get your location.', 'warning');
        const distance = turf.distance(turf.point(playerLocation), turf.point(gameCoords), { units: 'meters' });
        if (distance > 30.5) return Swal.fire('Too Far', `You are ${Math.round(distance * 3.28)} feet away. Get closer to join!`, 'warning');

        // We now pass the player's location to the backend function.
        const { data: response, error } = await supabaseClient.rpc('join_game', {
            user_id_input: currentUser.id,
            game_id_input: gameId,
            player_lon: playerLocation[0], // Player's longitude
            player_lat: playerLocation[1]  // Player's latitude
        });
        
        if (error || (response && !response.includes('Successfully joined'))) {
            // Use the detailed error message from the backend if it exists
            return Swal.fire('Could Not Join', response || error.message, 'info');
        }
        
        // A simpler success flow:
        Swal.fire('Let\'s Go!', 'You have joined the game!', 'success');
        // Refresh all game data to reflect the new state.
        // We also need to re-establish which game is the 'selectedGame'.
        const { data: game } = await supabaseClient.rpc('get_game_details', { game_id_input: gameId }).single();
        if (game) {
            selectGame(game);
        }
        fetchAndDisplayGames();
    }
    
    async function exitGame() {
        if (!currentUser || !selectedGame) return;
        const gameId = selectedGame.id;
        
        // This could be moved to a backend function as well for consistency.
        await supabaseClient
            .from('user_groups')
            .update({ status: 'exited', is_active: false })
            .eq('user_id', currentUser.id)
            .eq('game_id', gameId);
        
        const originalGameData = gameMarkers[gameId]?.gameData;
        selectedGame = null;
        gameTitleEl.textContent = 'Explore Games';
        if (chatChannel) supabaseClient.removeChannel(chatChannel);
        chatMessagesEl.innerHTML = '<div>No game selected.</div>';
        
        Swal.fire('Exited', 'You have left the game.', 'info');
        if (originalGameData) updateGameMarkerPopup(gameId, originalGameData);
        checkProximity();
    }

    async function fetchAndDisplayGames() {
      // This RPC should ideally select from a view that joins games and creators.
      const { data: games, error } = await supabaseClient.rpc('get_all_active_games_with_details');
      if (error) { console.error("Error fetching games:", error); return; }
      
      const gameIdsOnMap = new Set(games ? games.map(g => g.game_id) : []);
      Object.keys(gameMarkers).forEach(id => {
          if (!gameIdsOnMap.has(id)) {
              if (gameMarkers[id]) gameMarkers[id].remove();
              delete gameMarkers[id];
          }
      });
      
      if (!games) return;

      games.forEach(game => {
          const gameId = game.game_id;
          if (!game.location?.coordinates) return;
          
          if (gameMarkers[gameId]) {
            gameMarkers[gameId].gameData = game;
            updateGameMarkerPopup(gameId, game);
          } else {
            const markerEl = document.createElement('div');
            markerEl.style.cssText = 'background-image: url(https://cdn-icons-png.flaticon.com/512/8913/8913819.png); width: 32px; height: 32px; background-size: cover; cursor: pointer;';
            const marker = new mapboxgl.Marker(markerEl).setLngLat(game.location.coordinates).addTo(map);
            marker.gameData = game;
            gameMarkers[gameId] = marker;
            updateGameMarkerPopup(gameId, game);
          }
      });
    }
    
    function updateGameMarkerPopup(gameId, gameData) {
        const marker = gameMarkers[gameId];
        if (!marker || !gameData) return;

        let timeInfoHTML = '';
        if (gameData.status === 'pending') {
            timeInfoHTML = `<p class="time-info">Starts at: ${new Date(gameData.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>`;
        } else if (gameData.status === 'in_progress') {
            timeInfoHTML = `<p class="time-info">Live! Ends at: ${new Date(gameData.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>`;
        }
        
        let buttonHTML = `<button onclick="handleGameInteraction('${gameData.game_id}', [${gameData.location.coordinates[0]}, ${gameData.location.coordinates[1]}])">Join Game</button>`;
        // Check if the current user is active in this game to show the correct buttons
        if (selectedGame?.id === gameId) {
             buttonHTML = `<div class="button-group"><button class="chat-btn" onclick="openChatForGame()">Chat</button><button class="exit-btn" onclick="exitGame()">Exit</button></div>`;
        }

        const popupContent = `
            <div class="game-popup">
                <h3>${gameData.title}</h3>
                <p>Prize: $${gameData.total_value} | Treasures: ${gameData.treasure_count}</p>
                <p class="game-creator">by ${gameData.creator_username}</p>
                ${timeInfoHTML}
                ${buttonHTML}
            </div>`;
        const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(popupContent);
        marker.setPopup(popup);
    }
    
    async function openChatForGame() {
        if (!selectedGame) return;
        subscribeToChat(selectedGame.id);
        toggleChat(true); // Force chat to open
    }

    async function selectGame(game) {
      selectedGame = game;
      gameTitleEl.textContent = `Playing: ${game.title}`;
      // This will ensure the popup for the selected game shows "Chat" and "Exit"
      Object.keys(gameMarkers).forEach(id => updateGameMarkerPopup(id, gameMarkers[id].gameData));
      subscribeToChat(game.id);
      checkProximity();
    }
    
    async function digForTreasure() {
        if (!currentUser || !playerLocation) return;
        if (!selectedGame) return Swal.fire('Cannot Dig', 'You must be playing a game to dig.', 'info');
        
        const { data: result, error } = await supabaseClient.rpc('dig_treasure', {
            user_id_input: currentUser.id,
            dig_location: `POINT(${playerLocation[0]} ${playerLocation[1]})`
        });

        if (error) { console.error("Dig error:", error); return Swal.fire('Error', 'An error occurred while digging.', 'error'); }
        
        if (!result || result.length === 0) {
            Swal.fire("Keep Trying!", "No treasure found at this exact spot.", "warning");
            sendChatMessage("dug and found nothing.");
        } else {
            const foundTreasure = result[0];
            Swal.fire("Congratulations!", `You found a treasure worth $${foundTreasure.found_treasure_value}!`, "success");
            sendChatMessage(`dug and found a treasure worth $${foundTreasure.found_treasure_value}! 🎉`);
        }
    }

    function checkProximity() {
        if (!playerLocation || !selectedGame?.location?.coordinates) {
            digButton.classList.remove('enabled');
            distanceInfo.style.display = 'none';
            return;
        }
        
        const gameCenterCoords = selectedGame.location.coordinates;
        const distanceToGameCenter = turf.distance(turf.point(playerLocation), turf.point(gameCenterCoords), { units: 'meters' });
        const isInsideGameRadius = distanceToGameCenter <= 30.5;
        digButton.classList.toggle('enabled', isInsideGameRadius);
        if (!isInsideGameRadius) {
            const distanceInFeet = Math.round(distanceToGameCenter * 3.28);
            distanceInfo.textContent = `${distanceInFeet} feet from game area`;
            distanceInfo.style.display = 'block';
        } else {
            distanceInfo.style.display = 'none';
        }
    }

    function setupPlayerLocator() {
        if (!navigator.geolocation) return Swal.fire('Geolocation Not Supported', 'Your browser does not support this feature.', 'error');
        
        map.addControl(new mapboxgl.GeolocateControl({
            positionOptions: { enableHighAccuracy: true },
            trackUserLocation: true,
            showUserHeading: true
        }));

        navigator.geolocation.watchPosition(
            (position) => {
                playerLocation = [position.coords.longitude, position.coords.latitude];
                if (!userMarker) {
                    const el = document.createElement('div');
                    el.style.cssText = `background: #00ffcc; border: 2px solid white; width: 14px; height: 14px; border-radius: 50%; box-shadow: 0 0 10px #00ffff;`;
                    userMarker = new mapboxgl.Marker(el).setLngLat(playerLocation).addTo(map);
                } else {
                    userMarker.setLngLat(playerLocation);
                }
                checkProximity();
            },
            (error) => console.error(`Geolocation Error (Code ${error.code}): ${error.message}`),
            { enableHighAccuracy: true, maximumAge: 3000, timeout: 27000 }
        );
    }
    
    function toggleChat(forceOpen = false) {
      if (!selectedGame) return Swal.fire('Info', "You must be playing a game to chat.", 'info');
      
      if (forceOpen) {
          chatBox.style.display = 'flex';
      } else {
          chatBox.style.display = chatBox.style.display === 'flex' ? 'none' : 'flex';
      }
    }

    async function sendChatMessage(msg) {
        if (!msg || !selectedGame) return;
        await supabaseClient.from('chat_messages').insert({ message: msg, user_id: currentUser.id, game_id: selectedGame.id });
    }

    async function displayNewMessage(message) {
        const { data: user } = await supabaseClient.from('users').select('username').eq('id', message.user_id).single();
        const username = user ? user.username : 'A User';
        const timestamp = new Date(message.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit'});
        const div = document.createElement('div');
        div.innerHTML = `<b>${username}</b> ${message.message} <span class="chat-timestamp">${timestamp}</span>`;
        chatMessagesEl.appendChild(div);
        chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
    }

    async function handleSendMessage(e) {
        e.preventDefault();
        const text = e.target.chatText.value.trim();
        if(text) await sendChatMessage(text);
        e.target.reset();
    }

    function subscribeToChat(gameId) {
      if (chatChannel) supabaseClient.removeChannel(chatChannel);
      chatMessagesEl.innerHTML = `<div>Joined chat for <b>${selectedGame.title}</b></div>`;
      chatChannel = supabaseClient.channel(`game-chat-${gameId}`)
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `game_id=eq.${gameId}` }, (payload) => displayNewMessage(payload.new)).subscribe();
    }

    async function main() {
      currentUser = await verifySession();
      if (!currentUser) return;
      
      // Check if user is already in an active game on page load
      const { data: activeGameGroup } = await supabaseClient
        .from('user_groups')
        .select('game_id')
        .eq('user_id', currentUser.id)
        .eq('is_active', true)
        .single();
        
      if (activeGameGroup) {
          const { data: game } = await supabaseClient.rpc('get_game_details', { game_id_input: activeGameGroup.game_id }).single();
          if(game) selectGame(game);
      }
      
      mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
      map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/navigation-night-v1',
        center: [-73.7284, 40.9728],
        zoom: 12
      });

      map.on('load', () => {
        setupPlayerLocator();
        fetchAndDisplayGames();
        setInterval(fetchAndDisplayGames, 30000); // Refresh games every 30 seconds
      });
    }

    document.addEventListener('DOMContentLoaded', main);
    digButton.addEventListener('click', digForTreasure);
    chatForm.addEventListener('submit', handleSendMessage);
  </script>
</body>
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js"></script>
<script src="https://npmcdn.com/@turf/turf/turf.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    const SUPABASE_URL = 'https://mgtilfgygzymxiyixjit.supabase.co';
    const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1ndGlsZmd5Z3p5bXhpeWl4aml0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTE3MjQwMjMsImV4cCI6MjA2NzMwMDAyM30.0Kx5Lfd65QVcnQMOvnxzSnRcoyu2smuUFijzUFu8n_g';
    const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    let map, currentUser, playerLocation, selectedGame = null, chatChannel = null, userMarker = null;
    let gameMarkers = {};
    const digButton = document.getElementById('digButton');
    const distanceInfo = document.getElementById('distance-info');
    const gameTitleEl = document.getElementById('gameTitle');
    const chatBox = document.getElementById('chatBox');
    const chatMessagesEl = document.getElementById('chatMessages');
    const chatForm = document.getElementById('chatForm');

    async function verifySession() {
        try {
            const { data: { session } } = await supabaseClient.auth.getSession();
            if (!session) { window.location.href = 'login.html'; return null; }
            return session.user;
        } catch (e) {
            console.error("Session verification failed:", e);
            window.location.href = 'login.html';
            return null;
        }
    }
    
    async function handleGameInteraction(gameId, gameCoords) {
        if (!currentUser) return Swal.fire('Error', 'You must be logged in.', 'error');

        // The client-side distance check is still here for good user experience.
        if (!playerLocation) return Swal.fire('Location Error', 'Could not get your location.', 'warning');
        const distance = turf.distance(turf.point(playerLocation), turf.point(gameCoords), { units: 'meters' });
        if (distance > 30.5) return Swal.fire('Too Far', `You are ${Math.round(distance * 3.28)} feet away. Get closer to join!`, 'warning');

        // We now pass the player's location to the backend function.
        const { data: response, error } = await supabaseClient.rpc('join_game', {
            user_id_input: currentUser.id,
            game_id_input: gameId,
            player_lon: playerLocation[0], // Player's longitude
            player_lat: playerLocation[1]  // Player's latitude
        });
        
        if (error || (response && !response.includes('Successfully joined'))) {
            // Use the detailed error message from the backend if it exists
            return Swal.fire('Could Not Join', response || error.message, 'info');
        }
        
        // A simpler success flow:
        Swal.fire('Let\'s Go!', 'You have joined the game!', 'success');
        // Refresh all game data to reflect the new state.
        // We also need to re-establish which game is the 'selectedGame'.
        const { data: game } = await supabaseClient.rpc('get_game_details', { game_id_input: gameId }).single();
        if (game) {
            selectGame(game);
        }
        fetchAndDisplayGames();
    }
    
    async function exitGame() {
        if (!currentUser || !selectedGame) return;
        const gameId = selectedGame.id;
        
        // This could be moved to a backend function as well for consistency.
        await supabaseClient
            .from('user_groups')
            .update({ status: 'exited', is_active: false })
            .eq('user_id', currentUser.id)
            .eq('game_id', gameId);
        
        const originalGameData = gameMarkers[gameId]?.gameData;
        selectedGame = null;
        gameTitleEl.textContent = 'Explore Games';
        if (chatChannel) supabaseClient.removeChannel(chatChannel);
        chatMessagesEl.innerHTML = '<div>No game selected.</div>';
        
        Swal.fire('Exited', 'You have left the game.', 'info');
        if (originalGameData) updateGameMarkerPopup(gameId, originalGameData);
        checkProximity();
    }

    async function fetchAndDisplayGames() {
      // This RPC should ideally select from a view that joins games and creators.
      const { data: games, error } = await supabaseClient.rpc('get_all_active_games_with_details');
      if (error) { console.error("Error fetching games:", error); return; }
      
      const gameIdsOnMap = new Set(games ? games.map(g => g.game_id) : []);
      Object.keys(gameMarkers).forEach(id => {
          if (!gameIdsOnMap.has(id)) {
              if (gameMarkers[id]) gameMarkers[id].remove();
              delete gameMarkers[id];
          }
      });
      
      if (!games) return;

      games.forEach(game => {
          const gameId = game.game_id;
          if (!game.location?.coordinates) return;
          
          if (gameMarkers[gameId]) {
            gameMarkers[gameId].gameData = game;
            updateGameMarkerPopup(gameId, game);
          } else {
            const markerEl = document.createElement('div');
            markerEl.style.cssText = 'background-image: url(https://cdn-icons-png.flaticon.com/512/8913/8913819.png); width: 32px; height: 32px; background-size: cover; cursor: pointer;';
            const marker = new mapboxgl.Marker(markerEl).setLngLat(game.location.coordinates).addTo(map);
            marker.gameData = game;
            gameMarkers[gameId] = marker;
            updateGameMarkerPopup(gameId, game);
          }
      });
    }
    
    function updateGameMarkerPopup(gameId, gameData) {
        const marker = gameMarkers[gameId];
        if (!marker || !gameData) return;

        let timeInfoHTML = '';
        if (gameData.status === 'pending') {
            timeInfoHTML = `<p class="time-info">Starts at: ${new Date(gameData.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>`;
        } else if (gameData.status === 'in_progress') {
            timeInfoHTML = `<p class="time-info">Live! Ends at: ${new Date(gameData.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>`;
        }
        
        let buttonHTML = `<button onclick="handleGameInteraction('${gameData.game_id}', [${gameData.location.coordinates[0]}, ${gameData.location.coordinates[1]}])">Join Game</button>`;
        // Check if the current user is active in this game to show the correct buttons
        if (selectedGame?.id === gameId) {
             buttonHTML = `<div class="button-group"><button class="chat-btn" onclick="openChatForGame()">Chat</button><button class="exit-btn" onclick="exitGame()">Exit</button></div>`;
        }

        const popupContent = `
            <div class="game-popup">
                <h3>${gameData.title}</h3>
                <p>Prize: $${gameData.total_value} | Treasures: ${gameData.treasure_count}</p>
                <p class="game-creator">by ${gameData.creator_username}</p>
                ${timeInfoHTML}
                ${buttonHTML}
            </div>`;
        const popup = new mapboxgl.Popup({ offset: 25 }).setHTML(popupContent);
        marker.setPopup(popup);
    }
    
    async function openChatForGame() {
        if (!selectedGame) return;
        subscribeToChat(selectedGame.id);
        toggleChat(true); // Force chat to open
    }

    async function selectGame(game) {
      selectedGame = game;
      gameTitleEl.textContent = `Playing: ${game.title}`;
      // This will ensure the popup for the selected game shows "Chat" and "Exit"
      Object.keys(gameMarkers).forEach(id => updateGameMarkerPopup(id, gameMarkers[id].gameData));
      subscribeToChat(game.id);
      checkProximity();
    }
    
    async function digForTreasure() {
        if (!currentUser || !playerLocation) return;
        if (!selectedGame) return Swal.fire('Cannot Dig', 'You must be playing a game to dig.', 'info');
        
        const { data: result, error } = await supabaseClient.rpc('dig_treasure', {
            user_id_input: currentUser.id,
            dig_location: `POINT(${playerLocation[0]} ${playerLocation[1]})`
        });

        if (error) { console.error("Dig error:", error); return Swal.fire('Error', 'An error occurred while digging.', 'error'); }
        
        if (!result || result.length === 0) {
            Swal.fire("Keep Trying!", "No treasure found at this exact spot.", "warning");
            sendChatMessage("dug and found nothing.");
        } else {
            const foundTreasure = result[0];
            Swal.fire("Congratulations!", `You found a treasure worth $${foundTreasure.found_treasure_value}!`, "success");
            sendChatMessage(`dug and found a treasure worth $${foundTreasure.found_treasure_value}! 🎉`);
        }
    }

    function checkProximity() {
        if (!playerLocation || !selectedGame?.location?.coordinates) {
            digButton.classList.remove('enabled');
            distanceInfo.style.display = 'none';
            return;
        }
        
        const gameCenterCoords = selectedGame.location.coordinates;
        const distanceToGameCenter = turf.distance(turf.point(playerLocation), turf.point(gameCenterCoords), { units: 'meters' });
        const isInsideGameRadius = distanceToGameCenter <= 30.5;
        digButton.classList.toggle('enabled', isInsideGameRadius);
        if (!isInsideGameRadius) {
            const distanceInFeet = Math.round(distanceToGameCenter * 3.28);
            distanceInfo.textContent = `${distanceInFeet} feet from game area`;
            distanceInfo.style.display = 'block';
        } else {
            distanceInfo.style.display = 'none';
        }
    }

    function setupPlayerLocator() {
        if (!navigator.geolocation) return Swal.fire('Geolocation Not Supported', 'Your browser does not support this feature.', 'error');
        
        map.addControl(new mapboxgl.GeolocateControl({
            positionOptions: { enableHighAccuracy: true },
            trackUserLocation: true,
            showUserHeading: true
        }));

        navigator.geolocation.watchPosition(
            (position) => {
                playerLocation = [position.coords.longitude, position.coords.latitude];
                if (!userMarker) {
                    const el = document.createElement('div');
                    el.style.cssText = `background: #00ffcc; border: 2px solid white; width: 14px; height: 14px; border-radius: 50%; box-shadow: 0 0 10px #00ffff;`;
                    userMarker = new mapboxgl.Marker(el).setLngLat(playerLocation).addTo(map);
                } else {
                    userMarker.setLngLat(playerLocation);
                }
                checkProximity();
            },
            (error) => console.error(`Geolocation Error (Code ${error.code}): ${error.message}`),
            { enableHighAccuracy: true, maximumAge: 3000, timeout: 27000 }
        );
    }
    
    function toggleChat(forceOpen = false) {
      if (!selectedGame) return Swal.fire('Info', "You must be playing a game to chat.", 'info');
      
      if (forceOpen) {
          chatBox.style.display = 'flex';
      } else {
          chatBox.style.display = chatBox.style.display === 'flex' ? 'none' : 'flex';
      }
    }

    async function sendChatMessage(msg) {
        if (!msg || !selectedGame) return;
        await supabaseClient.from('chat_messages').insert({ message: msg, user_id: currentUser.id, game_id: selectedGame.id });
    }

    async function displayNewMessage(message) {
        const { data: user } = await supabaseClient.from('users').select('username').eq('id', message.user_id).single();
        const username = user ? user.username : 'A User';
        const timestamp = new Date(message.created_at).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit'});
        const div = document.createElement('div');
        div.innerHTML = `<b>${username}</b> ${message.message} <span class="chat-timestamp">${timestamp}</span>`;
        chatMessagesEl.appendChild(div);
        chatMessagesEl.scrollTop = chatMessagesEl.scrollHeight;
    }

    async function handleSendMessage(e) {
        e.preventDefault();
        const text = e.target.chatText.value.trim();
        if(text) await sendChatMessage(text);
        e.target.reset();
    }

    function subscribeToChat(gameId) {
      if (chatChannel) supabaseClient.removeChannel(chatChannel);
      chatMessagesEl.innerHTML = `<div>Joined chat for <b>${selectedGame.title}</b></div>`;
      chatChannel = supabaseClient.channel(`game-chat-${gameId}`)
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: `game_id=eq.${gameId}` }, (payload) => displayNewMessage(payload.new)).subscribe();
    }

    async function main() {
      currentUser = await verifySession();
      if (!currentUser) return;
      
      // Check if user is already in an active game on page load
      const { data: activeGameGroup } = await supabaseClient
        .from('user_groups')
        .select('game_id')
        .eq('user_id', currentUser.id)
        .eq('is_active', true)
        .single();
        
      if (activeGameGroup) {
          const { data: game } = await supabaseClient.rpc('get_game_details', { game_id_input: activeGameGroup.game_id }).single();
          if(game) selectGame(game);
      }
      
      mapboxgl.accessToken = 'pk.eyJ1Ijoid2VtYXB6IiwiYSI6ImNtY3J0MDlqYjBwdXcyanExcTRsaG5pZXUifQ.gBtrb0P7o0ukM8HtyBcTrw';
      map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/navigation-night-v1',
        center: [-73.7284, 40.9728],
        zoom: 12
      });

      map.on('load', () => {
        setupPlayerLocator();
        fetchAndDisplayGames();
        setInterval(fetchAndDisplayGames, 30000); // Refresh games every 30 seconds
      });
    }

    document.addEventListener('DOMContentLoaded', main);
    digButton.addEventListener('click', digForTreasure);
    chatForm.addEventListener('submit', handleSendMessage);
  </script>